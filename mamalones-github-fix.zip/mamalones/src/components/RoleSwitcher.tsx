"use client";

import { useRole } from "@/hooks/useRole";
import { Truck, Package } from "lucide-react";

export function RoleSwitcher() {
 const { role, setRole, isClient } = useRole();
 
 if (!isClient) return null;

 return (
  <div className="flex items-center gap-1 p-1 bg-[#111113] border border-[#1E1E21] rounded-full">
   <button
    onClick={() => setRole("cliente")}
    className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-[12px] font-medium tracking-[-0.01em] transition-all ${
     role === "cliente"
      ? "bg-[#FAFAFA] text-[#0A0A0B] shadow-sm"
      : "text-[#71717B] hover:text-[#FAFAFA]"
    }`}
   >
    <Package className="w-3.5 h-3.5" />
    Cliente
   </button>
   <button
    onClick={() => setRole("transportista")}
    className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-[12px] font-medium tracking-[-0.01em] transition-all ${
     role === "transportista"
      ? "bg-[#FAFAFA] text-[#0A0A0B] shadow-sm"
      : "text-[#71717B] hover:text-[#FAFAFA]"
    }`}
   >
    <Truck className="w-3.5 h-3.5" />
    Transportista
   </button>
  </div>
 );
}

export function SecurityTierBadge({ tier }: { tier: "verificado" | "oro" | "diamante" }) {
 return (
  <span className={`text-[10px] font-medium px-2.5 py-1 rounded-[8px] border tracking-[0.02em] ${
   tier === "verificado" ? "bg-[#0F1512] text-[#4ADE80] border-[#1A2E1F]" :
   tier === "oro" ? "bg-[#1A160F] text-[#FBBF24] border-[#2E251A]" :
   "bg-[#FAFAFA] text-[#0A0A0B] border-[#FAFAFA] font-semibold"
  }`}>
   {tier === "verificado" ? "Verificado SCT" : tier === "oro" ? "Nivel Oro" : "Nivel Diamante"}
  </span>
 );
}
