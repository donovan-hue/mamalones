"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { 
 Search, Truck, MapPin, Scale, QrCode, 
 ShieldCheck, AlertTriangle, FileText, Utensils, 
 Plus, Settings, LayoutGrid, X, Bell, Wallet, User, ChevronRight, Activity,
 Package, Building, Navigation, Camera, ClipboardList
} from "lucide-react";
import { RoleSwitcher } from "./RoleSwitcher";
import { useRole } from "@/hooks/useRole";

const SECCIONES_ALL = [
 { nombre: "Bolsa de carga", ruta: "/cargas", icono: Package, badge: "12 en vivo", desc: "Materia prima disponible por cercanía y costo por kilómetro", roles: ["cliente","transportista"] },
 { nombre: "Publicar carga", ruta: "/publicar", icono: Plus, badge: "Nuevo", desc: "Material, peso, ruta exacta, tarifa y custodia", roles: ["cliente"] },
 { nombre: "Mis cargas", ruta: "/mis-cargas", icono: ClipboardList, badge: "3 activas", desc: "Seguimiento de cargas publicadas y ofertas recibidas", roles: ["cliente"] },
 { nombre: "Mis viajes", ruta: "/mis-viajes", icono: Navigation, badge: "3 en curso", desc: "Ofertas enviadas, check-in báscula y seguimiento", roles: ["transportista"] },
 { nombre: "Check-in báscula", ruta: "/check-in", icono: Camera, badge: "GPS", desc: "Foto ticket báscula para activar rastreo satelital", roles: ["transportista"] },
 { nombre: "Dashboard", ruta: "/dashboard", icono: Activity, badge: null, desc: "Centro de mando y KPIs operativos", roles: ["cliente","transportista"] },
 { nombre: "Rastreo GPS", ruta: "/rastreo", icono: MapPin, badge: "Encriptado", desc: "Telemetría privada con alertas de ruta", roles: ["cliente","transportista"] },
 { nombre: "Perfil empresa", ruta: "/empresa", icono: Building, badge: "Verificada", desc: "Validación SCT/SAT y flotilla verificada", roles: ["cliente","transportista"] },
 { nombre: "Báscula y diésel", ruta: "/bascula", icono: Scale, badge: null, desc: "Control de peso y rendimiento de combustible", roles: ["transportista"] },
 { nombre: "Casetas QR", ruta: "/caseta", icono: QrCode, badge: "4,850 MXN", desc: "Wallet IAVE y QR dinámico", roles: ["transportista"] },
 { nombre: "Entrega y custodia", ruta: "/entrega", icono: ShieldCheck, badge: "Escrow", desc: "Evidencia POD y liberación de pago", roles: ["transportista"] },
 { nombre: "Incidentes SOS", ruta: "/incidentes", icono: AlertTriangle, badge: "Offline", desc: "Reporte y botón de pánico con geolocalización", roles: ["transportista"] },
 { nombre: "Carta Porte SAT", ruta: "/fiscal", icono: FileText, badge: "SAT 3.1", desc: "Timbrado fiscal XML y PDF", roles: ["cliente","transportista"] },
 { nombre: "Servicios en ruta", ruta: "/sushi", icono: Utensils, badge: null, desc: "Talleres, estaciones y servicios verificados", roles: ["transportista"] },
 { nombre: "Configuración", ruta: "/configuracion", icono: Settings, badge: null, desc: "Flotilla, operadores y documentación", roles: ["cliente","transportista"] },
];

export function Navbar() {
 const [open, setOpen] = useState(false);
 const [search, setSearch] = useState("");
 const [notifications] = useState(5);
 const pathname = usePathname();
 const { role } = useRole();

 const SECCIONES = SECCIONES_ALL.filter(s => s.roles.includes(role));
 const seccionesFiltradas = SECCIONES.filter((s) =>
  s.nombre.toLowerCase().includes(search.toLowerCase()) ||
  s.desc.toLowerCase().includes(search.toLowerCase())
 );

 useEffect(() => {
  const handleKeyDown = (e: KeyboardEvent) => {
   if ((e.metaKey || e.ctrlKey) && e.key === "k") {
    e.preventDefault();
    setOpen(true);
   }
   if (e.key === "Escape") setOpen(false);
  };
  window.addEventListener("keydown", handleKeyDown);
  return () => window.removeEventListener("keydown", handleKeyDown);
 }, []);

 return (
  <>
   <header className="sticky top-0 z-40 bg-[#0A0A0B]/80 backdrop-blur-xl border-b border-[#1E1E21] max-w-md mx-auto">
    <div className="flex items-center justify-between gap-3 p-4">
     <Link href="/" className="flex items-center gap-3 font-bold text-xs text-white shrink-0 group">
      <div className="p-2.5 bg-[#FAFAFA] text-[#0A0A0B] rounded-[12px] group-hover:scale-[0.98] transition-transform">
       <Truck className="w-4 h-4" />
      </div>
      <div className="leading-none">
       <span className="tracking-[-0.02em] font-semibold text-[14px] block">MAMALONES</span>
       <span className="text-[10px] font-medium text-[#71717B] tracking-[0.06em] uppercase">Logistics v3.1</span>
      </div>
     </Link>

     <div className="flex items-center gap-2">
      <RoleSwitcher />
      <button className="relative p-2.5 bg-[#111113] border border-[#1E1E21] rounded-[12px] text-[#71717B] hover:text-[#FAFAFA] hover:border-[#2A2A2E] transition-colors">
       <Bell className="w-4 h-4" />
       {notifications > 0 && (
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#FAFAFA] text-[#0A0A0B] text-[10px] font-semibold rounded-full flex items-center justify-center">
         {notifications}
        </span>
       )}
      </button>
     </div>
    </div>

    <div className="px-4 pb-4 space-y-3">
     <div className="relative group">
      <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#52525B] group-focus-within:text-[#FAFAFA] transition-colors" />
      <input
       type="text"
       placeholder={`Buscar como ${role}... (⌘K)`}
       value={search}
       onChange={(e) => setSearch(e.target.value)}
       onFocus={() => setOpen(true)}
       className="w-full bg-[#111113] border border-[#1E1E21] group-hover:border-[#2A2A2E] focus:border-[#3F3F47] focus:bg-[#151518] rounded-[12px] py-3 pl-10 pr-12 text-[13px] text-[#FAFAFA] outline-none placeholder:text-[#52525B] transition-all"
      />
      <div className="absolute right-2.5 top-1/2 -translate-y-1/2">
       <span className="text-[10px] font-medium bg-[#18181B] border border-[#27272A] text-[#71717B] px-2 py-1 rounded-[8px]">⌘K</span>
      </div>
     </div>

     <div className="flex gap-2">
      <div className="flex-1 bg-[#111113] border border-[#1E1E21] rounded-[10px] px-3 py-2.5 flex items-center justify-between">
       <span className="text-[10px] font-medium text-[#71717B] uppercase tracking-[0.06em]">{role === "cliente" ? "Escrow retenido" : "Balance disponible"}</span>
       <span className="text-[13px] font-semibold text-[#FAFAFA]">38,500 MXN</span>
      </div>
      <div className="flex-1 bg-[#111113] border border-[#1E1E21] rounded-[10px] px-3 py-2.5 flex items-center justify-between">
       <span className="text-[10px] font-medium text-[#71717B] uppercase tracking-[0.06em]">{role === "cliente" ? "Cargas activas" : "Viajes en curso"}</span>
       <span className="text-[13px] font-semibold text-[#FAFAFA]">{role === "cliente" ? "3" : "3"}</span>
      </div>
      <Link href={role === "cliente" ? "/mis-cargas" : "/mis-viajes"} className="p-2.5 bg-[#FAFAFA] text-[#0A0A0B] rounded-[10px] flex items-center justify-center hover:bg-[#E4E4E7] transition-colors">
       <Wallet className="w-4 h-4" />
      </Link>
     </div>
    </div>
   </header>

   {open && (
    <div className="fixed inset-0 z-50 bg-[#0A0A0B]/90 backdrop-blur-xl max-w-md mx-auto flex flex-col p-4">
     <div className="bg-[#111113] border border-[#1E1E21] rounded-[16px] shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
      <div className="p-4 border-b border-[#1E1E21] flex items-center gap-3">
       <div className="flex-1 relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#52525B]" />
        <input autoFocus type="text" placeholder={`Buscar como ${role}...`} value={search} onChange={(e) => setSearch(e.target.value)} className="w-full bg-[#0A0A0B] border border-[#1E1E21] rounded-[12px] py-3 pl-10 text-[14px] text-[#FAFAFA] outline-none focus:border-[#2A2A2E]" />
       </div>
       <button onClick={() => { setOpen(false); setSearch(""); }} className="p-2.5 bg-[#18181B] border border-[#27272A] rounded-[12px] text-[#71717B] hover:text-[#FAFAFA]"><X className="w-4 h-4" /></button>
      </div>

      <div className="p-3 border-b border-[#1E1E21] bg-[#0F0F11]">
       <RoleSwitcher />
       <p className="text-[11px] text-[#71717B] mt-2 leading-[1.5]">Modo {role === "cliente" ? "cliente: publicación de carga con custodia y validación de operadores" : "transportista: bolsa de carga, contraofertas con unidad y tiempos de arribo/entrega"}</p>
      </div>

      <div className="overflow-y-auto flex-1 p-2 space-y-1">
       <div className="px-3 py-2 text-[10px] font-medium text-[#52525B] uppercase tracking-[0.08em]">
        Módulos disponibles ({seccionesFiltradas.length})
       </div>
       
       {seccionesFiltradas.map((sec) => {
        const Icon = sec.icono;
        const isActive = pathname === sec.ruta;
        return (
         <Link key={sec.ruta} href={sec.ruta} onClick={() => { setOpen(false); setSearch(""); }} className={`group flex items-center gap-3 p-3 rounded-[12px] border transition-all ${isActive ? "bg-[#FAFAFA] text-[#0A0A0B] border-[#FAFAFA]" : "bg-[#0F0F11] border-[#1E1E21] hover:bg-[#151518] hover:border-[#2A2A2E] text-[#FAFAFA]"}`}>
          <div className={`p-2.5 rounded-[10px] ${isActive ? "bg-[#0A0A0B] text-[#FAFAFA]" : "bg-[#18181B] border border-[#1E1E21] text-[#71717B] group-hover:text-[#FAFAFA]"}`}><Icon className="w-4 h-4" /></div>
          <div className="flex-1 min-w-0">
           <div className="flex items-center gap-2"><span className="text-[13px] font-medium truncate tracking-[-0.01em]">{sec.nombre}</span>{sec.badge && <span className={`text-[10px] px-2 py-0.5 rounded-[8px] border ${isActive ? "bg-[#0A0A0B] text-[#FAFAFA] border-[#0A0A0B]" : "bg-[#18181B] text-[#71717B] border-[#27272A]"}`}>{sec.badge}</span>}</div>
           <span className={`text-[11px] truncate block leading-[1.4] ${isActive ? "text-[#0A0A0B]/70" : "text-[#71717B]"}`}>{sec.desc}</span>
          </div>
          <ChevronRight className={`w-4 h-4 ${isActive ? "text-[#0A0A0B]" : "text-[#52525B] group-hover:text-[#FAFAFA]"}`} />
         </Link>
        );
       })}
      </div>

      <div className="p-3 border-t border-[#1E1E21] bg-[#0F0F11] flex items-center justify-between text-[11px] text-[#52525B]">
       <span>Navegación con teclado</span>
       <span className="flex items-center gap-1.5"><span className="w-1 h-1 bg-[#22C55E] rounded-full" /> Sistema operativo</span>
      </div>
     </div>
    </div>
   )}

   <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50">
    <div className="flex items-center gap-1.5 p-1.5 bg-[#111113]/90 backdrop-blur-xl border border-[#1E1E21] rounded-full shadow-2xl">
     <button onClick={() => setOpen(!open)} className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-[13px] font-medium transition-all ${open ? "bg-[#FAFAFA] text-[#0A0A0B]" : "bg-[#18181B] text-[#FAFAFA] hover:bg-[#27272A] border border-[#27272A]"}`}>
      {open ? <X className="w-4 h-4" /> : <LayoutGrid className="w-4 h-4" />}
      <span>{open ? "Cerrar" : "Menú"}</span>
     </button>
     <div className="w-px h-5 bg-[#1E1E21]" />
     <Link href="/cargas" className="p-2.5 bg-[#FAFAFA] text-[#0A0A0B] rounded-full hover:bg-[#E4E4E7] transition-colors"><Truck className="w-4 h-4" /></Link>
     <Link href={role === "cliente" ? "/publicar" : "/mis-viajes"} className="p-2.5 bg-[#18181B] border border-[#27272A] text-[#FAFAFA] rounded-full hover:bg-[#27272A]"><Plus className="w-4 h-4" /></Link>
     <Link href="/mis-cargas" className="p-2.5 bg-[#18181B] border border-[#27272A] text-[#71717B] hover:text-[#FAFAFA] rounded-full"><User className="w-4 h-4" /></Link>
    </div>
   </div>
  </>
 );
}
