"use client";
import { MessageCircle, Truck } from "lucide-react";
import Link from "next/link";

export function FooterCTA() {
 const waLink = "https://wa.me/523332222222?text=Hola%20vengo%20de%20MAMALONES%20quiero%20info%20de%20fletes";
 
 return (
  <div className="max-w-md mx-auto p-4 pt-2">
   <div className="bg-gradient-to-br from-[#12151c] to-[#0a0b0d] border border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-3">
    <div className="flex items-center gap-3">
     <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center">
      <Truck className="w-5 h-5 text-black" />
     </div>
     <div>
      <p className="text-xs font-bold text-white">¿Eres fletero o tienes carga?</p>
      <p className="text-[10px] font-mono text-slate-400">Escríbenos directo, respuesta en 5 min</p>
     </div>
    </div>
    <a href={waLink} target="_blank" className="bg-[#25D366] text-black p-2.5 rounded-xl hover:scale-105 transition-transform">
     <MessageCircle className="w-5 h-5" />
    </a>
   </div>
  </div>
 );
}
