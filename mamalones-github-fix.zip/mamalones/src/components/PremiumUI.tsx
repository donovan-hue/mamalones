"use client";
import React from "react";

export function PremiumButton({
 children,
 variant = "primary",
 size = "md",
 className = "",
 ...props
}: {
 children: React.ReactNode;
 variant?: "primary" | "secondary" | "ghost" | "danger" | "success" | "outline";
 size?: "sm" | "md" | "lg";
 className?: string;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
 const variants = {
  primary: "bg-[#FAFAFA] text-[#0A0A0B] hover:bg-[#E4E4E7] font-semibold",
  secondary: "bg-[#18181B] text-[#FAFAFA] border border-[#27272A] hover:bg-[#27272A] hover:border-[#3F3F47]",
  ghost: "bg-transparent text-[#A1A1AA] hover:text-[#FAFAFA] hover:bg-[#111113]",
  danger: "bg-[#1A1010] text-[#F87171] border border-[#2E1A1A] hover:bg-[#2A1515]",
  success: "bg-[#0F1A13] text-[#4ADE80] border border-[#1A2E1F] hover:bg-[#132A1A]",
  outline: "bg-transparent border border-[#1E1E21] text-[#A1A1AA] hover:border-[#2A2A2E] hover:text-[#FAFAFA]",
 };
 const sizes = {
  sm: "px-3 py-2 text-[13px] rounded-[10px]",
  md: "px-4 py-2.5 text-[13px] rounded-[12px]",
  lg: "px-5 py-3.5 text-[14px] rounded-[12px]",
 };
 return (
  <button className={`transition-all duration-150 active:scale-[0.98] font-medium tracking-[-0.01em] flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed ${variants[variant]} ${sizes[size]} ${className}`} {...props}>
   {children}
  </button>
 );
}

export function PremiumInput({
 label,
 icon,
 error,
 ...props
}: {
 label?: string;
 icon?: React.ReactNode;
 error?: string;
} & React.InputHTMLAttributes<HTMLInputElement>) {
 return (
  <div className="space-y-2">
   {label && <label className="text-[11px] font-medium text-[#A1A1AA] tracking-[0.02em] block">{label}</label>}
   <div className="relative group">
    {icon && <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#52525B] group-focus-within:text-[#FAFAFA] transition-colors">{icon}</div>}
    <input
     className={`
      w-full bg-[#111113] border border-[#1E1E21] rounded-[12px] py-3 text-[14px] text-[#FAFAFA] outline-none
      focus:bg-[#151518] focus:border-[#2A2A2E] transition-all placeholder:text-[#52525B]
      ${icon ? "pl-10" : "px-3.5"}
      ${error ? "border-[#7F1D1D] bg-[#1A1010]" : ""}
     `}
     {...props}
    />
   </div>
   {error && <span className="text-[11px] text-[#F87171]">{error}</span>}
  </div>
 );
}

export function PremiumSelect({
 label,
 children,
 ...props
}: {
 label?: string;
 children: React.ReactNode;
} & React.SelectHTMLAttributes<HTMLSelectElement>) {
 return (
  <div className="space-y-2">
   {label && <label className="text-[11px] font-medium text-[#A1A1AA] tracking-[0.02em] block">{label}</label>}
   <select className="w-full bg-[#111113] border border-[#1E1E21] rounded-[12px] px-3.5 py-3 text-[14px] text-[#FAFAFA] outline-none focus:bg-[#151518] focus:border-[#2A2A2E] transition-all" {...props}>
    {children}
   </select>
  </div>
 );
}

export function Skeleton({ className = "" }: { className?: string }) {
 return <div className={`animate-pulse bg-[#111113] border border-[#1E1E21] rounded-[12px] ${className}`} />;
}

export function EmptyState({
 icon,
 title,
 description,
 action,
}: {
 icon?: React.ReactNode;
 title: string;
 description: string;
 action?: React.ReactNode;
}) {
 return (
  <div className="py-16 text-center space-y-4 bg-[#0F0F11] border border-dashed border-[#1E1E21] rounded-[16px]">
   {icon && <div className="mx-auto w-12 h-12 bg-[#111113] border border-[#1E1E21] rounded-[12px] flex items-center justify-center text-[#52525B]">{icon}</div>}
   <div className="space-y-1.5">
    <p className="text-[15px] font-semibold tracking-[-0.01em] text-[#FAFAFA]">{title}</p>
    <p className="text-[13px] text-[#71717B] leading-[1.5] max-w-[300px] mx-auto">{description}</p>
   </div>
   {action && <div className="pt-2">{action}</div>}
  </div>
 );
}
