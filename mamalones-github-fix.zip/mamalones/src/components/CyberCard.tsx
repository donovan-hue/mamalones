import React from "react";

interface CyberCardProps {
  children: React.ReactNode;
  className?: string;
  badgeText?: string;
  variant?: "default" | "subtle" | "success" | "warning" | "danger" | "enterprise" | "glow" | "emerald" | "amber" | "glass";
  hover?: boolean;
  padding?: "sm" | "md" | "lg" | "none";
}

const variantStyles: Record<string, string> = {
  default: "bg-[#111113] border-[#1E1E21]",
  subtle: "bg-[#0F0F11] border-[#1C1C1F]",
  success: "bg-[#0F1210] border-[#1C2620]",
  warning: "bg-[#12110F] border-[#26231C]",
  danger: "bg-[#121011] border-[#261C1C]",
  enterprise: "bg-[#111113] border-[#242428]",
  // legacy aliases mapped to serious palette
  glow: "bg-[#111113] border-[#1E1E21]",
  emerald: "bg-[#0F1210] border-[#1C2620]",
  amber: "bg-[#12110F] border-[#26231C]",
  glass: "bg-[#111113] border-[#1E1E21] backdrop-blur-sm",
};

const paddingStyles = {
  none: "p-0",
  sm: "p-3.5",
  md: "p-4",
  lg: "p-5",
};

export function CyberCard({ 
  children, 
  className = "", 
  badgeText,
  variant = "default",
  hover = true,
  padding = "md"
}: CyberCardProps) {
  return (
    <div className={`
      rounded-[12px] w-full border
      ${variantStyles[variant] || variantStyles.default}
      ${paddingStyles[padding]}
      ${hover ? "hover:bg-[#151518] hover:border-[#2A2A2E]" : ""}
      transition-all duration-200
      ${className}
    `}>
      {badgeText && (
        <div className="flex items-center justify-between mb-3.5 pb-3 border-b border-[#1E1E21]">
          <span className="text-[10px] font-medium tracking-[0.08em] text-[#71717B] uppercase">
            {badgeText}
          </span>
          <div className="flex items-center gap-1">
            <span className="w-1 h-1 rounded-full bg-[#27272A]" />
            <span className="w-1 h-1 rounded-full bg-[#3F3F47]" />
          </div>
        </div>
      )}
      <div className="space-y-3">{children}</div>
    </div>
  );
}

export function PremiumStat({
  label,
  value,
  subvalue,
  icon,
  trend,
}: {
  label: string;
  value: string;
  subvalue?: string;
  icon?: React.ReactNode;
  trend?: "up" | "down" | "neutral";
}) {
  return (
    <div className="bg-[#111113] border border-[#1E1E21] rounded-[12px] p-4 space-y-2 hover:bg-[#151518] hover:border-[#2A2A2E] transition-all">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-medium tracking-[0.06em] text-[#71717B] uppercase">{label}</span>
        {icon && <span className="text-[#52525B]">{icon}</span>}
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-[22px] font-semibold tracking-[-0.02em] text-[#FAFAFA] leading-none">{value}</span>
        {trend && (
          <span className={`text-[11px] font-medium px-1.5 py-0.5 rounded-[6px] border ${
            trend === "up" ? "bg-[#0F1A13] text-[#4ADE80] border-[#1A2E1F]" :
            trend === "down" ? "bg-[#1A1010] text-[#F87171] border-[#2E1A1A]" :
            "bg-[#151515] text-[#A1A1AA] border-[#232323]"
          }`}>
            {trend === "up" ? "↑ 12%" : trend === "down" ? "↓ 3%" : "→ 0%"}
          </span>
        )}
      </div>
      {subvalue && <span className="text-[11px] text-[#71717B] block leading-[1.4]">{subvalue}</span>}
    </div>
  );
}

export function PremiumBadge({
  children,
  variant = "default",
}: {
  children: React.ReactNode;
  variant?: "default" | "success" | "warning" | "danger" | "live" | "neutral";
}) {
  const styles = {
    default: "bg-[#18181B] text-[#A1A1AA] border-[#27272A]",
    success: "bg-[#0F1A13] text-[#4ADE80] border-[#1A2E1F]",
    warning: "bg-[#1A160F] text-[#FBBF24] border-[#2E251A]",
    danger: "bg-[#1A1010] text-[#F87171] border-[#2E1A1A]",
    live: "bg-[#FAFAFA] text-[#0A0A0B] border-[#FAFAFA] font-semibold",
    neutral: "bg-[#111113] text-[#71717B] border-[#1E1E21]",
  };
  return (
    <span className={`text-[10px] font-medium px-2 py-1 rounded-[8px] border tracking-[0.02em] ${styles[variant]}`}>
      {children}
    </span>
  );
}
