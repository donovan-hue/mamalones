"use client";

import { ShieldCheck, Lock, AlertTriangle, CheckCircle2, FileText, Eye, UserCheck } from "lucide-react";
import { CyberCard, PremiumBadge } from "./CyberCard";

export function EscrowFlow({ amount, status = "retenido" }: { amount: number, status?: "depositado" | "retenido" | "liberado" }) {
 const steps = [
  { id: "depositado", label: "Depositado", desc: "Cliente deposita", done: true },
  { id: "retenido", label: "En Custodia", desc: "Retenido seguro", done: status !== "depositado", active: status === "retenido" },
  { id: "liberado", label: "Liberado", desc: "Al entregar evidencia", done: status === "liberado", active: false },
 ];

 return (
  <div className="bg-[#070709] border border-[#1e1e1e] rounded-xl p-3 space-y-3">
   <div className="flex items-center justify-between">
    <span className="text-[10px] font-mono font-bold text-[#666] uppercase tracking-widest">Flujo Escrow Pago en Custodia</span>
    <span className="text-xs font-mono font-black text-emerald-400">${amount.toLocaleString()} MXN</span>
   </div>
   <div className="flex gap-2">
    {steps.map((s, i) => (
     <div key={s.id} className="flex-1 flex items-center gap-2">
      <div className={`w-8 h-8 rounded-full border flex items-center justify-center shrink-0 ${s.done ? "bg-emerald-500 border-emerald-500 text-black" : s.active ? "bg-amber-500 border-amber-500 text-black animate-pulse" : "bg-[#1a1a1a] border-[#333] text-[#555]"}`}>
       {s.done ? <CheckCircle2 className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
      </div>
      <div className="flex-1 min-w-0">
       <span className={`text-[11px] font-bold block ${s.done || s.active ? "text-white" : "text-[#555]"}`}>{s.label}</span>
       <span className="text-[9px] font-mono text-[#666] block leading-none">{s.desc}</span>
      </div>
      {i < 2 && <div className={`flex-1 h-px ${s.done ? "bg-emerald-500/50" : "bg-[#222]"}`} />}
     </div>
    ))}
   </div>
   <p className="text-[10px] font-mono text-[#666] text-center"> Retenido seguro Solo se libera con ticket báscula + firma destino</p>
  </div>
 );
}

export function CargoInsuranceCard({ pesoTon, valorPorTon = 7500, activo, onToggle }: { pesoTon: number, valorPorTon?: number, activo: boolean, onToggle: (v:boolean)=>void }) {
 const cobertura = pesoTon * valorPorTon;
 const costo = Math.round(cobertura * 0.025);
 
 return (
  <div className={`border rounded-xl p-3 transition-all ${activo ? "bg-emerald-950/20 border-emerald-900/30" : "bg-[#0a0a0a] border-[#222]"}`}>
   <div className="flex items-center justify-between">
    <div className="flex items-center gap-2.5">
     <div className={`p-2 rounded-xl ${activo ? "bg-emerald-500 text-black" : "bg-[#1a1a1a] text-[#666]"}`}>
      <ShieldCheck className="w-5 h-5" />
     </div>
     <div>
      <p className="text-xs font-bold text-white">Seguro de Carga por Tonelada</p>
      <p className="text-[10px] font-mono text-[#888]">Robo + siniestro Cobertura ${cobertura.toLocaleString()} Costo ${costo.toLocaleString()} (2.5%)</p>
     </div>
    </div>
    <label className="relative inline-flex items-center cursor-pointer">
     <input type="checkbox" checked={activo} onChange={e=>onToggle(e.target.checked)} className="sr-only peer" />
     <div className="w-11 h-6 bg-[#222] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
    </label>
   </div>
   {activo && (
    <div className="mt-2 pt-2 border-t border-emerald-900/20 text-[11px] font-mono text-emerald-300/80 space-y-1">
     <div className="flex justify-between"><span> Toneladas aseguradas</span><span className="font-bold">{pesoTon}T</span></div>
     <div className="flex justify-between"><span> Valor por ton</span><span>${valorPorTon.toLocaleString()}</span></div>
     <div className="flex justify-between"><span> Deducible</span><span>10% Reporte en 24h</span></div>
    </div>
   )}
  </div>
 );
}

export function ValidationChecklist({ type }: { type: "operador" | "empresa" }) {
 const itemsOperador = [
  { label: "Licencia Federal", status: "ok", desc: "FED-8839201-A Vigente hasta 2027" },
  { label: "CURP + Antecedentes", status: "ok", desc: "Sin antecedentes CURP validado RENAPO" },
  { label: "Póliza Seguro Unidad", status: "ok", desc: "GNP-883920-A $2M cobertura" },
  { label: "INE + Biométrico", status: "warning", desc: "Renovar en 12 días Rostro ok" },
 ];
 
 const itemsEmpresa = [
  { label: "RFC + Constancia Fiscal", status: "ok", desc: "CGR990101XYZ Régimen 601" },
  { label: "Historial Pagos", status: "ok", desc: "38 pagos 100% puntual 0 fraudes" },
  { label: "Rating Transportistas", status: "ok", desc: "4.9  127 opiniones" },
  { label: "Solvencia", status: "ok", desc: "Balance verificado $1.2M" },
 ];

 const items = type === "operador" ? itemsOperador : itemsEmpresa;

 return (
  <div className="space-y-2">
   {items.map((item, i) => (
    <div key={i} className={`flex gap-2.5 p-2.5 rounded-xl border ${item.status === "ok" ? "bg-[#070709] border-[#1e1e1e]" : "bg-amber-950/20 border-amber-900/20"}`}>
     <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${item.status === "ok" ? "bg-emerald-500 text-black" : "bg-amber-500 text-black"}`}>
      {item.status === "ok" ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
     </div>
     <div className="flex-1 min-w-0">
      <span className="text-xs font-bold text-white block">{item.label}</span>
      <span className="text-[10px] font-mono text-[#888] block leading-relaxed">{item.desc}</span>
     </div>
    </div>
   ))}
  </div>
 );
}

export function PanicButton() {
 return (
  <button 
   onClick={() => {
    if (confirm(" ¿ACTIVAR BOTÓN DE PÁNICO? Se compartirá ubicación GPS + alerta a central y contactos de emergencia")) {
     alert(" SOS Activado\n Ubicación compartida: KM 142 Tepic\n Llamando a central 24/7\n WhatsApp emergencia enviado a 3 contactos");
    }
   }}
   className="w-full py-4 bg-red-600 hover:bg-red-700 border-2 border-red-400 text-white font-black rounded-xl text-sm flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(239,68,68,0.5)] animate-pulse"
  >
   <AlertTriangle className="w-5 h-5" />
   BOTÓN PÁNICO SOS 24/7
  </button>
 );
}

export function RouteAlert({ type }: { type: "desvio" | "parada_no_programada" | "zona_riesgo" }) {
 const alerts = {
  desvio: { icon: Eye, label: "Desvío detectado", desc: "Ruta desviada 2.3km del plan Verificando...", color: "amber" },
  parada_no_programada: { icon: AlertTriangle, label: "Parada no programada", desc: "Parada 18 min en zona no autorizada ¿Todo bien?", color: "amber" },
  zona_riesgo: { icon: AlertTriangle, label: "Zona de alto riesgo", desc: "Entrando a zona con reportes Mantén velocidad y no pares", color: "red" },
 };
 const a = alerts[type];
 const Icon = a.icon;

 return (
  <div className={`border rounded-xl p-3 flex gap-2.5 ${a.color === "red" ? "bg-red-950/30 border-red-900/30" : "bg-amber-950/30 border-amber-900/30"}`}>
   <Icon className={`w-5 h-5 shrink-0 ${a.color === "red" ? "text-red-400" : "text-amber-400"}`} />
   <div>
    <p className={`text-xs font-bold ${a.color === "red" ? "text-red-300" : "text-amber-300"}`}>{a.label}</p>
    <p className="text-[11px] font-mono text-[#ccc] leading-relaxed">{a.desc}</p>
   </div>
  </div>
 );
}
