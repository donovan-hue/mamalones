"use client";

import { useState, useEffect } from "react";
import { Role } from "@/lib/types";

export function useRole() {
  const [role, setRoleState] = useState<Role>("transportista");
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    const saved = localStorage.getItem("mamalones_role") as Role | null;
    if (saved) setRoleState(saved);
    else {
      // Default según perfil guardado
      const user = localStorage.getItem("mamalones_user");
      if (user) {
        try {
          const parsed = JSON.parse(user);
          if (parsed?.role) setRoleState(parsed.role);
        } catch {}
      }
    }
  }, []);

  const setRole = (newRole: Role) => {
    setRoleState(newRole);
    localStorage.setItem("mamalones_role", newRole);
    // También guardar en user
    const userStr = localStorage.getItem("mamalones_user");
    if (userStr) {
      try {
        const user = JSON.parse(userStr);
        user.role = newRole;
        localStorage.setItem("mamalones_user", JSON.stringify(user));
      } catch {
        localStorage.setItem("mamalones_user", JSON.stringify({ role: newRole }));
      }
    }
  };

  return { role, setRole, isClient };
}
