export type Role = "cliente" | "transportista";

export interface Unidad {
  id: string;
  placas: string;
  tipo: string;
  marca: string;
  capacidadTon: number;
  foto?: string;
  chofer: Chofer;
  status: "disponible" | "en_ruta" | "taller" | "descanso";
  kmActual: number;
  rendimiento: number; // km/L
}

export interface Chofer {
  id: string;
  nombre: string;
  licencia: string;
  telefono: string;
  rating: number;
  viajes: number;
  foto?: string;
}

export interface EmpresaTransporte {
  id: string;
  nombre: string;
  rfc: string;
  logo?: string;
  rating: number;
  viajesCompletados: number;
  verificado: boolean;
  flotilla: Unidad[];
  descripcion?: string;
}

export interface Carga {
  id: string;
  origen: string;
  destino: string;
  origenLat?: number;
  origenLng?: number;
  destinoLat?: number;
  destinoLng?: number;
  distanciaKm: number;
  producto: string;
  tipoProducto: "trigo" | "maiz" | "soya" | "sorgo" | "otros";
  pesoKg: number;
  pesoTon: number;
  volumenM3?: number;
  valorMercancia?: number;
  fechaRecogida: string;
  fechaEntregaLimite: string;
  urgencia: "normal" | "urgente" | "express";
  clienteId: string;
  clienteNombre: string;
  clienteRating: number;
  montoOfrecidoCliente: number;
  montoAceptado?: number;
  precioPorKm?: number;
  escrowActivo: boolean;
  seguroActivo: boolean;
  estatus: "buscando" | "con_ofertas" | "asignada" | "en_transito" | "entregada" | "cancelada";
  unidadRequerida: string;
  descripcion?: string;
  fotos?: string[];
  createdAt: string;
  ofertasCount?: number;
  // Transportista asignado
  empresaAsignada?: EmpresaTransporte;
  unidadAsignada?: Unidad;
  choferAsignado?: Chofer;
  etaRecogida?: string;
  etaEntrega?: string;
  precioTransportista?: number;
}

export interface Oferta {
  id: string;
  cargaId: string;
  carga?: Carga;
  empresa: EmpresaTransporte;
  unidad: Unidad;
  chofer: Chofer;
  precioOfertado: number;
  contraOfertaCliente?: number;
  etaRecogida: string; // "En 2 horas", "Mañana 8:00 AM"
  etaEntrega: string; // "Mañana 8:00 PM", "24h"
  tiempoRecogidaHoras: number;
  tiempoEntregaHoras: number;
  distanciaRecogidaKm?: number; // distancia de unidad a origen
  comentario?: string;
  incluyeCasetas: boolean;
  incluyeDiesel: boolean;
  estatus: "pendiente" | "aceptada" | "rechazada" | "contraoferta";
  createdAt: string;
  // Tracking después de aceptada
  tracking?: {
    status: "camino_a_recoger" | "en_bodega" | "en_transito" | "en_destino" | "entregado";
    progreso: number;
    ubicacionActual?: string;
  }
}

export const PRODUCTOS_GRANOS = [
  { value: "trigo", label: "Trigo Comercial", claveSAT: "10151500", precioRefKg: 7.2 },
  { value: "maiz", label: "Maíz Blanco / Amarillo", claveSAT: "10151600", precioRefKg: 6.8 },
  { value: "soya", label: "Soya Premium", claveSAT: "10151900", precioRefKg: 12.5 },
  { value: "sorgo", label: "Sorgo", claveSAT: "10151700", precioRefKg: 6.5 },
  { value: "otros", label: "Otros Granos", claveSAT: "10151800", precioRefKg: 8.0 },
] as const;

export const RUTAS_ESTANDAR = [
  { origen: "Guadalajara, JAL", destino: "Culiacán, SIN", km: 720, casetas: 815, horas: 10.5 },
  { origen: "Tlaquepaque, JAL", destino: "Mazatlán, SIN", km: 310, casetas: 425, horas: 4.8 },
  { origen: "Zapopan, JAL", destino: "Tepic, NAY", km: 180, casetas: 195, horas: 2.8 },
  { origen: "El Salto, JAL", destino: "Los Mochis, SIN", km: 890, casetas: 1240, horas: 13.2 },
  { origen: "Guadalajara, JAL", destino: "Hermosillo, SON", km: 1450, casetas: 1850, horas: 18.5 },
];

export function calcularDistancia(origen: string, destino: string): number {
  const ruta = RUTAS_ESTANDAR.find(r => origen.toLowerCase().includes(r.origen.split(",")[0].toLowerCase()) && destino.toLowerCase().includes(r.destino.split(",")[0].toLowerCase()));
  if (ruta) return ruta.km;
  // Fallback: random entre 200-900
  return Math.floor(Math.random()*700)+200;
}

export function calcularPrecioSugerido(pesoTon: number, distanciaKm: number, tipoProducto: string): { min: number, optimo: number, max: number, porKm: number } {
  const basePorKmTon = 2.8; // MXN por km por tonelada
  const producto = PRODUCTOS_GRANOS.find(p=>p.value===tipoProducto);
  const factorProducto = producto?.value==="soya" ? 1.2 : producto?.value==="maiz" ? 0.95 : 1.0;
  const optimo = Math.round(distanciaKm * pesoTon * basePorKmTon * factorProducto);
  return {
    min: Math.round(optimo*0.85),
    optimo,
    max: Math.round(optimo*1.25),
    porKm: Math.round(optimo/distanciaKm)
  };
}

export function calcularETAs(distanciaKm: number, horasParaRecoger: number = 2): { recogida: string, entrega: string, horasTransito: number } {
  const velocidadProm = 68; // km/h con paradas
  const horasTransito = distanciaKm / velocidadProm;
  const totalHoras = horasParaRecoger + horasTransito;
  const ahora = new Date();
  const recogida = new Date(ahora.getTime() + horasParaRecoger*3600000);
  const entrega = new Date(ahora.getTime() + totalHoras*3600000);
  return {
    recogida: recogida.toLocaleString("es-MX", { day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit" }),
    entrega: entrega.toLocaleString("es-MX", { day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit" }),
    horasTransito
  };
}
