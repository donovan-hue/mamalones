import { createClient, SupabaseClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

// Evita crashear el build si faltan ENV - retorna null y usamos datos demo
let client: SupabaseClient | null = null;

if (supabaseUrl && supabaseAnonKey && supabaseUrl.startsWith("http")) {
  try {
    client = createClient(supabaseUrl, supabaseAnonKey);
  } catch (e) {
    console.warn("Error creando cliente Supabase:", e);
    client = null;
  }
} else {
  if (typeof window === "undefined") {
    // En build time no tenemos ENV, es normal usar demo
    console.log("Supabase ENV no configurado, usando modo demo");
  }
}

export const supabase = client;

// Helper para saber si estamos en modo demo
export const isDemoMode = !client;
