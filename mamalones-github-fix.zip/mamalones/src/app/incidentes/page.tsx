"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowLeft, WifiOff, AlertTriangle, Camera, Mic, MapPin, Clock, Send, Shield } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton, PremiumInput, PremiumSelect } from "@/components/PremiumUI";

export default function IncidentesPremium() {
 const [tipo, setTipo] = useState("estadía");
 const [horas, setHoras] = useState("");
 const [desc, setDesc] = useState("");
 const [historial, setHistorial] = useState<any[]>([]);

 useEffect(()=>{
  const h = localStorage.getItem("incidentes_hist");
  if (h) setHistorial(JSON.parse(h));
 },[]);

 const reportar = () => {
  const entry={id:Date.now(), tipo, horas, desc, fecha:new Date().toISOString(), status:"Enviado offline se sincroniza al tener señal"};
  const nuevo=[entry,...historial];
  setHistorial(nuevo);
  localStorage.setItem("incidentes_hist",JSON.stringify(nuevo));
  setHoras(""); setDesc("");
  alert("Reporte guardado offline. Se enviará automático al reconectar + WhatsApp SOS si es emergencia.");
 };

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4 space-y-3">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4"/></Link>
     <div><h1 className="text-sm font-black text-white">INCIDENTES & SOS</h1><span className="text-[10px] font-mono text-[#666] uppercase">Offline first Sincronización auto</span></div>
     <PremiumBadge variant="warning">Offline Mode</PremiumBadge>
    </div>
    <div className="bg-[#12151c] border border-[#222] rounded-xl p-3 flex gap-3">
     <WifiOff className="w-5 h-5 text-amber-400 shrink-0" />
     <div><p className="text-xs font-bold text-white">Modo sin cobertura activo</p><p className="text-[11px] font-mono text-[#888]">Reportes se guardan local y se envían al reconectar. SOS comparte ubicación por WhatsApp.</p></div>
    </div>
   </div>

   <div className="p-4 space-y-4">
    <CyberCard badgeText="Nuevo reporte" variant="glass">
     <div className="space-y-4">
      <PremiumSelect label="Tipo incidente *" value={tipo} onChange={e=>setTipo(e.target.value)}>
       <option value="estadía">Estadía / Cobro demora en rampa</option>
       <option value="descompostura">Descompostura mecánica</option>
       <option value="accidente">Accidente vial</option>
       <option value="robo">Intento robo / Extorsión</option>
       <option value="reten">Retén / Revisión excesiva</option>
       <option value="clima">Clima / Cierre carretera</option>
       <option value="otro">Otro</option>
      </PremiumSelect>

      <div className="grid grid-cols-2 gap-3">
       <PremiumInput label="Horas retraso" type="number" placeholder="Ej. 3" value={horas} onChange={e=>setHoras(e.target.value)} icon={<Clock className="w-4 h-4"/>} />
       <PremiumInput label="Ubicación KM" placeholder="Ej. Km 142" icon={<MapPin className="w-4 h-4"/>} />
      </div>

      <div className="space-y-1.5">
       <label className="text-[10px] font-mono font-bold text-[#666] uppercase">Descripción detallada *</label>
       <textarea value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Qué pasó, a qué hora, qué necesitas... Ej: Llevo 4h en rampa bodega Culiacán km 12, no descargan, cobro $500/h estadía" className="w-full bg-[#0a0b0d] border border-slate-800 rounded-xl p-3 text-xs font-mono text-white outline-none min-h-[90px] placeholder:text-[#555] focus:border-[#444]" />
      </div>

      <div className="grid grid-cols-3 gap-2">
       <button className="py-3 bg-[#0a0a0a] border border-[#222] rounded-xl flex flex-col items-center gap-1 hover:border-[#444]"><Camera className="w-5 h-5 text-[#666]"/><span className="text-[10px] font-mono text-[#888]">Foto</span></button>
       <button className="py-3 bg-[#0a0a0a] border border-[#222] rounded-xl flex flex-col items-center gap-1 hover:border-[#444]"><Mic className="w-5 h-5 text-[#666]"/><span className="text-[10px] font-mono text-[#888]">Audio</span></button>
       <button className="py-3 bg-[#0a0a0a] border border-[#222] rounded-xl flex flex-col items-center gap-1 hover:border-[#444]"><MapPin className="w-5 h-5 text-[#666]"/><span className="text-[10px] font-mono text-[#888]">Ubicación</span></button>
      </div>

      <PremiumButton onClick={reportar} variant="primary" className="w-full"><Send className="w-4 h-4"/> Registrar {(tipo==="estadía"?"cobro estadía":`incidente ${tipo}`)}</PremiumButton>

      {tipo!=="estadía" && (
       <button className="w-full py-3 bg-red-950/30 border border-red-900/30 text-red-400 rounded-xl text-xs font-black flex items-center justify-center gap-2"><Shield className="w-4 h-4"/> BOTÓN SOS Compartir ubicación + llamar emergencia</button>
      )}
     </div>
    </CyberCard>

    <CyberCard badgeText={`Historial ${historial.length} reportes offline`} variant="default">
     {historial.length===0 ? (
      <div className="py-8 text-center"><AlertTriangle className="w-8 h-8 text-[#333] mx-auto mb-2"/><p className="text-xs font-bold text-white">Sin reportes</p><p className="text-[11px] font-mono text-[#666]">Tus incidentes quedan guardados localmente</p></div>
     ) : (
      <div className="space-y-2 max-h-[300px] overflow-y-auto">
       {historial.map((h:any)=>(
        <div key={h.id} className="p-3 bg-[#070709] border border-[#1a1a1a] rounded-xl">
         <div className="flex justify-between items-center"><span className="text-xs font-bold text-white uppercase">{h.tipo} {h.horas?`${h.horas}h`:''}</span><span className="text-[10px] font-mono text-[#666]">{new Date(h.fecha).toLocaleTimeString()}</span></div>
         <p className="text-[11px] font-mono text-[#888] mt-1 leading-relaxed">{h.desc}</p>
         <span className="text-[9px] font-mono text-amber-400 bg-amber-950/20 border border-amber-900/20 px-1.5 py-0.5 rounded-full mt-1 inline-block">{h.status}</span>
        </div>
       ))}
      </div>
     )}
    </CyberCard>

    <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-xl p-3">
     <p className="text-[10px] font-mono font-bold text-[#666] uppercase tracking-widest">Tarifas estadía sugeridas SCT</p>
     <div className="grid grid-cols-3 gap-2 mt-2 text-[11px] font-mono">
      <div className="bg-[#12151c] border border-[#222] rounded-lg p-2 text-center"><span className="text-[#666] block text-[9px]">Torton</span><span className="text-white font-bold">$450/h</span></div>
      <div className="bg-[#12151c] border border-[#222] rounded-lg p-2 text-center"><span className="text-[#666] block text-[9px]">Rabón</span><span className="text-white font-bold">$350/h</span></div>
      <div className="bg-[#12151c] border border-[#222] rounded-lg p-2 text-center"><span className="text-[#666] block text-[9px]">Trailer</span><span className="text-white font-bold">$600/h</span></div>
     </div>
    </div>
   </div>
  </div>
 );
}
