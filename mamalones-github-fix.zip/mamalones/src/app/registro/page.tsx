"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, User, Shield, FileText, Truck, CheckCircle2, Upload, Info } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton, PremiumInput, PremiumSelect } from "@/components/PremiumUI";
import { supabase, isDemoMode } from "@/lib/supabase";

const STEPS = ["Operador", "Unidad", "Documentos"];

export default function RegistroPremium() {
 const router = useRouter();
 const [step, setStep] = useState(1);
 const [nombre, setNombre] = useState("");
 const [licencia, setLicencia] = useState("");
 const [tel, setTel] = useState("");
 const [placas, setPlacas] = useState("");
 const [marca, setMarca] = useState("");
 const [seguro, setSeguro] = useState("");
 const [loading, setLoading] = useState(false);

 const handleRegister = async () => {
  setLoading(true);
  try {
   if (!supabase || isDemoMode) {
    await new Promise(r=>setTimeout(r,1200));
    localStorage.setItem("mamalones_user", JSON.stringify({ nombre, placas, licencia }));
    alert("¡Modo DEMO! Expediente registrado. Te llevamos al dashboard.");
    router.push("/dashboard");
    return;
   }
   const { error } = await supabase.from("expedientes").insert([{ nombre_operador:nombre, licencia_federal:licencia, placas_unidad:placas, poliza_seguro:seguro, estatus_verificacion:"validado", created_at:new Date().toISOString() }]);
   if (error) throw error;
   alert("¡Expediente registrado y verificado!");
   router.push("/cargas");
  } catch (e:any) {
   alert("Error: "+e.message);
  } finally { setLoading(false); }
 };

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4 space-y-3">
    <div className="flex items-center gap-3">
     <Link href="/login" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4"/></Link>
     <div><h1 className="text-sm font-black text-white">ALTA DE UNIDAD PREMIUM</h1><span className="text-[10px] font-mono text-[#666] uppercase">Verificación SCT Paso {step} de 3</span></div>
    </div>
    <div className="flex gap-2">
     {STEPS.map((s,i)=>{
      const active=step===i+1;
      const past=step>i+1;
      return <div key={s} className={`flex-1 p-2 rounded-xl border text-center transition-all ${active?"bg-white text-black border-white":past?"bg-emerald-950/30 border-emerald-900/30 text-emerald-400":"bg-[#0a0a0a] border-[#222] text-[#666]"}`}><span className="text-[11px] font-bold block">{i+1}. {s}</span>{past && <CheckCircle2 className="w-3 h-3 mx-auto mt-0.5"/>}</div>;
     })}
    </div>
   </div>

   <div className="p-4 space-y-4">
    {step===1 && (
     <CyberCard badgeText="Datos del operador" variant="glass">
      <div className="space-y-4">
       <PremiumInput label="Nombre completo operador *" icon={<User className="w-4 h-4"/>} placeholder="Ej. Donovan Gaspar Ávila" value={nombre} onChange={e=>setNombre(e.target.value)} />
       <PremiumInput label="Licencia Federal *" icon={<FileText className="w-4 h-4"/>} placeholder="FED-8839201-A" value={licencia} onChange={e=>setLicencia(e.target.value)} />
       <PremiumInput label="WhatsApp contacto" icon={<span className="text-[10px]"></span>} placeholder="3331234567" value={tel} onChange={e=>setTel(e.target.value)} />
       <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-3 flex gap-2.5">
        <Info className="w-4 h-4 text-[#666] shrink-0 mt-0.5"/>
        <span className="text-[11px] font-mono text-[#888]">Validamos licencia en SCT en 2 min. Tu INE y antecedentes se revisan automático.</span>
       </div>
      </div>
     </CyberCard>
    )}

    {step===2 && (
     <CyberCard badgeText="Datos de unidad" variant="glass">
      <div className="space-y-4">
       <div className="grid grid-cols-2 gap-3">
        <PremiumInput label="Placas *" icon={<Truck className="w-4 h-4"/>} placeholder="88-AA-3B" value={placas} onChange={e=>setPlacas(e.target.value.toUpperCase())} className="uppercase" />
        <PremiumSelect label="Tipo unidad *" value={marca} onChange={e=>setMarca(e.target.value)}><option>Torton 3 ejes Caja Seca</option><option>Rabón Heavy Duty</option><option>Trailer 53ft</option><option>Thermo 53ft</option><option>Lowboy</option></PremiumSelect>
       </div>
       <PremiumInput label="Marca / Modelo / Año" placeholder="Kenworth T680 2022" />
       <PremiumInput label="Póliza seguro *" icon={<Shield className="w-4 h-4"/>} placeholder="GNP-883920-A" value={seguro} onChange={e=>setSeguro(e.target.value)} />
       <PremiumSelect label="Capacidad toneladas"><option>9.5 T</option><option>12 T</option><option>15 T</option><option>20 T</option></PremiumSelect>
      </div>
     </CyberCard>
    )}

    {step===3 && (
     <div className="space-y-4">
      <CyberCard badgeText="Documentos Verificación en 2 min" variant="glass">
       <div className="space-y-3">
        {[
         { label:"INE frontal y trasera", req:true },
         { label:"Licencia Federal (ambos lados)", req:true },
         { label:"Tarjeta circulación", req:true },
         { label:"Póliza seguro vigente", req:true },
         { label:"Foto unidad 4 lados (opcional)", req:false },
        ].map(f=>(
         <div key={f.label} className="flex items-center gap-3 p-3 bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl hover:border-[#333] cursor-pointer">
          <div className="w-10 h-10 bg-[#12151c] border border-[#222] rounded-xl flex items-center justify-center"><Upload className="w-4 h-4 text-[#666]"/></div>
          <div className="flex-1"><span className="text-xs font-bold text-white block">{f.label} {f.req && <span className="text-red-400">*</span>}</span><span className="text-[10px] font-mono text-[#666]">PDF/JPG máx 10MB</span></div>
          <PremiumBadge variant="default">Subir</PremiumBadge>
         </div>
        ))}
       </div>
      </CyberCard>

      <CyberCard badgeText="Resumen expediente" variant="default">
       <div className="space-y-2 text-xs font-mono">
        <div className="flex justify-between p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl"><span className="text-[#666]">Operador</span><span className="text-white font-bold">{nombre||"—"}</span></div>
        <div className="flex justify-between p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl"><span className="text-[#666]">Placas</span><span className="text-white font-bold">{placas||"—"}</span></div>
        <div className="flex justify-between p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl"><span className="text-[#666]">Licencia</span><span className="text-white">{licencia||"—"}</span></div>
       </div>
      </CyberCard>
     </div>
    )}

    <div className="flex gap-2">
     {step>1 && <button onClick={()=>setStep(step-1)} className="flex-1 py-3 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-bold text-white">Atrás</button>}
     {step<3 ? (
      <button onClick={()=>setStep(step+1)} disabled={step===1 && (!nombre||!licencia)} className="flex-[2] py-3 bg-white text-black font-black rounded-xl text-xs disabled:opacity-40">Siguiente {STEPS[step]}</button>
     ) : (
      <PremiumButton onClick={handleRegister} disabled={loading} variant="primary" className="flex-[2]" size="lg">{loading?"Validando..." : "Crear expediente y verificar"}</PremiumButton>
     )}
    </div>

    <p className="text-[9px] font-mono text-center text-[#444]">Al registrar aceptas verificación SCT/SAT, rastreo GPS y términos escrow Datos encriptados AES-256</p>
   </div>
  </div>
 );
}
