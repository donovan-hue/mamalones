"use client";

import { useState } from "react";
import Link from "next/link";
import { Truck, DollarSign, MapPin, Activity, TrendingUp, Clock, ShieldCheck, AlertTriangle, Fuel, ArrowUpRight, Package } from "lucide-react";
import { CyberCard, PremiumStat, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton } from "@/components/PremiumUI";

export default function DashboardPremium() {
 const stats = {
  ingresosMes: 124500,
  fletesActivos: 3,
  kmMes: 3420,
  rating: 4.9,
  escrowBalance: 38500,
  postulaciones: 12,
 };

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="p-4 space-y-4">
    <div className="flex items-center justify-between">
     <div>
      <h1 className="text-xl font-black tracking-tighter text-white">DASHBOARD</h1>
      <span className="text-[10px] font-mono text-[#666] uppercase tracking-widest">Centro de mando Kronos Fleet</span>
     </div>
     <div className="flex items-center gap-2">
      <div className="w-8 h-8 bg-white text-black rounded-xl flex items-center justify-center font-black text-xs">DG</div>
     </div>
    </div>

    {/* KPI Grid */}
    <div className="grid grid-cols-2 gap-2.5">
     <CyberCard variant="glow" padding="sm">
      <div className="space-y-1">
       <div className="flex justify-between items-center"><span className="text-[9px] font-mono uppercase text-[#666]">Ingresos Mayo</span><TrendingUp className="w-3.5 h-3.5 text-emerald-400" /></div>
       <span className="text-xl font-black font-mono text-white">${(stats.ingresosMes/1000).toFixed(1)}k</span>
       <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">↗ +23% vs Abril</span>
      </div>
     </CyberCard>
     <CyberCard variant="default" padding="sm">
      <div className="space-y-1">
       <div className="flex justify-between"><span className="text-[9px] font-mono uppercase text-[#666]">En ruta</span><Activity className="w-3.5 h-3.5 text-white animate-pulse" /></div>
       <span className="text-xl font-black font-mono text-white">{stats.fletesActivos}</span>
       <span className="text-[10px] font-mono text-[#888]">720km totales hoy</span>
      </div>
     </CyberCard>
     <PremiumStat label="KM Mes" value={`${stats.kmMes}`} subvalue="124L diesel prom 8.2 km/L" icon={<MapPin className="w-3 h-3 text-[#666]" />} trend="up" />
     <PremiumStat label="Rating" value={`${stats.rating}`} subvalue="38 entregas 100% puntual" icon={<span className="text-amber-400"> </span>} trend="up" />
    </div>

    <div className="grid grid-cols-2 gap-2.5">
     <div className="bg-emerald-950/20 border border-emerald-900/30 rounded-xl p-3 flex items-center justify-between">
      <div><span className="text-[9px] font-mono uppercase text-emerald-400 block">Escrow Balance</span><span className="text-sm font-black font-mono text-emerald-400">${stats.escrowBalance.toLocaleString()}</span></div>
      <ShieldCheck className="w-6 h-6 text-emerald-400" />
     </div>
     <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-3 flex items-center justify-between">
      <div><span className="text-[9px] font-mono uppercase text-[#666] block">Postulaciones</span><span className="text-sm font-black font-mono text-white">{stats.postulaciones} nuevas</span></div>
      <Clock className="w-6 h-6 text-[#666]" />
     </div>
    </div>

    {/* Chart */}
    <CyberCard badgeText="Ingresos últimos 7 días" variant="glass">
     <div className="space-y-3">
      <div className="flex items-end gap-1.5 h-20">
       {[20,35,15,50,30,65,45].map((h,i)=>(
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
         <div className="w-full bg-[#1a1a1a] rounded-full relative overflow-hidden" style={{height:"60px"}}>
          <div className={`absolute bottom-0 w-full rounded-full transition-all ${i===5?"bg-white":"bg-[#333] hover:bg-[#444]"}`} style={{height:`${h}%`}} />
         </div>
         <span className="text-[8px] font-mono text-[#555]">{["L","M","M","J","V","S","D"][i]}</span>
        </div>
       ))}
      </div>
      <div className="flex justify-between text-[10px] font-mono text-[#666] border-t border-[#1a1a1a] pt-2"><span>Promedio: $17k/día</span><span className="text-emerald-400">Mejor día: Sábado $24k</span></div>
     </div>
    </CyberCard>

    <CyberCard badgeText="Fletes activos en vivo" variant="default">
     <div className="space-y-2.5">
      {[
       { id:"9901", ruta:"GDL → CUL", progreso:38, eta:"4h 12m", tarifa:38500, status:"En ruta Diesel" },
       { id:"8802", ruta:"GDL → MZT", progreso:72, eta:"1h 45m", tarifa:24000, status:"Casi llega" },
       { id:"7703", ruta:"ZPN → TEP", progreso:15, eta:"3h 30m", tarifa:18500, status:"Recién salió" },
      ].map(f=>(
       <Link key={f.id} href="/rastreo" className="flex items-center gap-3 p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl hover:border-[#333] transition-colors">
        <div className="w-10 h-10 bg-[#12151c] border border-[#222] rounded-xl flex items-center justify-center text-white font-bold text-xs">{f.id.slice(0,2)}</div>
        <div className="flex-1 min-w-0">
         <div className="flex items-center gap-2"><span className="text-xs font-bold text-white">{f.ruta}</span><PremiumBadge variant="live">{f.progreso}%</PremiumBadge></div>
         <div className="w-full bg-[#1a1a1a] h-1 rounded-full mt-1 overflow-hidden"><div className="h-full bg-emerald-500" style={{width:`${f.progreso}%`}} /></div>
         <span className="text-[10px] font-mono text-[#666]">{f.status} {f.eta} ${f.tarifa.toLocaleString()}</span>
        </div>
        <ArrowUpRight className="w-4 h-4 text-[#444]" />
       </Link>
      ))}
     </div>
    </CyberCard>

    <div className="grid grid-cols-2 gap-2">
     <Link href="/cargas" className="bg-white text-black font-black p-3 rounded-xl text-xs flex items-center justify-center gap-2 hover:bg-zinc-200">
      <Truck className="w-4 h-4"/> Buscar fletes
     </Link>
     <Link href="/publicar" className="bg-[#12151c] border border-slate-800 text-white font-bold p-3 rounded-xl text-xs flex items-center justify-center gap-2">
      <Package className="w-4 h-4"/> Publicar
     </Link>
    </div>

    <CyberCard badgeText="Alertas y acciones" variant="amber">
     <div className="space-y-2">
      <div className="flex gap-2.5 p-2.5 bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl">
       <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
       <div><p className="text-xs font-bold text-white">Documentación vence en 12 días</p><p className="text-[11px] font-mono text-[#888]">Seguro GNP-883920-A y verificación SCT</p></div>
      </div>
      <div className="flex gap-2.5 p-2.5 bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl">
       <Fuel className="w-4 h-4 text-[#666] shrink-0 mt-0.5" />
       <div><p className="text-xs font-bold text-white">Optimiza diesel: -8% en ruta GDL-CUL</p><p className="text-[11px] font-mono text-[#888]">Te sugerimos cargar en Tepic Km 142, $1.2/L más barato</p></div>
      </div>
     </div>
    </CyberCard>
   </div>
  </div>
 );
}
