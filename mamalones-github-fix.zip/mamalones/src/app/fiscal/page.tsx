"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, Download, CheckCircle2, QrCode, FileText, Shield, AlertCircle, Plus, Search } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton, PremiumInput, PremiumSelect } from "@/components/PremiumUI";

export default function FiscalPremium() {
 const [uuid] = useState("4452B1C8-9101-4D1E-883A-12003F99201A");
 const [rfcEmisor, setRfcEmisor] = useState("CGR990101XYZ");
 const [rfcReceptor, setRfcReceptor] = useState("TLA920412AA1");

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4 space-y-3">
    <div className="flex items-center gap-3">
     <Link href="/" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4"/></Link>
     <div><h1 className="text-sm font-black text-white">CARTA PORTE SAT 3.1</h1><span className="text-[10px] font-mono text-[#666] uppercase">Timbrado PAC + XML/PDF</span></div>
     <PremiumBadge variant="success">Timbrado válido</PremiumBadge>
    </div>
   </div>

   <div className="p-4 space-y-4">
    <CyberCard badgeText="Timbre fiscal UUID" variant="emerald">
     <div className="space-y-3 font-mono text-xs">
      <div className="bg-[#070709] border border-emerald-900/20 rounded-xl p-3 space-y-2">
       <span className="text-[10px] text-[#666] uppercase block">UUID / Folio Fiscal SAT</span>
       <span className="text-white font-black text-[11px] break-all tracking-tight">{uuid}</span>
       <div className="flex gap-2 pt-1">
        <span className="text-[10px] bg-emerald-950/30 text-emerald-400 border border-emerald-900/30 px-2 py-0.5 rounded-full">Vigente</span>
        <span className="text-[10px] bg-[#1a1a1a] text-[#888] border border-[#222] px-2 py-0.5 rounded-full">PAC: FINKOK</span>
       </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
       <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-2.5"><span className="text-[9px] text-[#666] uppercase block">Fecha timbrado</span><span className="text-white font-bold text-[11px]">03/08/2026 14:22:05</span></div>
       <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-2.5"><span className="text-[9px] text-[#666] uppercase block">No. Certificado</span><span className="text-white font-bold text-[11px]">0000100000050892</span></div>
      </div>
     </div>
    </CyberCard>

    <div className="grid grid-cols-2 gap-3">
     <button className="p-3 bg-white text-black rounded-xl font-black text-xs flex items-center justify-center gap-2 hover:bg-zinc-200"><Download className="w-4 h-4"/> PDF</button>
     <button className="p-3 bg-[#12151c] border border-slate-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 hover:bg-slate-800"><FileText className="w-4 h-4"/> XML</button>
    </div>

    <CyberCard badgeText="Receptor y emisor" variant="glass">
     <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
       <PremiumInput label="RFC Emisor" value={rfcEmisor} onChange={e=>setRfcEmisor(e.target.value)} />
       <PremiumInput label="RFC Receptor" value={rfcReceptor} onChange={e=>setRfcReceptor(e.target.value)} />
      </div>
      <div className="space-y-2 text-[11px] font-mono">
       <div className="flex justify-between p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl"><span className="text-[#666]">Razón Social</span><span className="text-white font-bold">Granos de Occidente SA</span></div>
       <div className="flex justify-between p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl"><span className="text-[#666]">Régimen</span><span className="text-white">601 General</span></div>
       <div className="flex justify-between p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl"><span className="text-[#666]">Uso CFDI</span><span className="text-white">G03 Gastos generales</span></div>
      </div>
     </div>
    </CyberCard>

    <CyberCard badgeText="Autotransporte federal" variant="default">
     <div className="space-y-2 text-xs font-mono">
      <div className="grid grid-cols-2 gap-2">
       <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-2.5"><span className="text-[9px] text-[#666] uppercase block">Permiso SCT</span><span className="text-white font-bold">SCT-TFR-00492</span></div>
       <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-2.5"><span className="text-[9px] text-[#666] uppercase block">Config vehicular</span><span className="text-white font-bold">C3 Torton</span></div>
      </div>
      <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-3 space-y-1.5">
       <div className="flex justify-between"><span className="text-[#666]">Placas</span><span className="text-emerald-400 font-bold">88-AA-3B (MEX)</span></div>
       <div className="flex justify-between"><span className="text-[#666]">Póliza</span><span className="text-white">GNP-883920-A Vigente</span></div>
       <div className="flex justify-between"><span className="text-[#666]">Operador Lic</span><span className="text-white">FED-8839201-A</span></div>
      </div>
     </div>
    </CyberCard>

    <CyberCard badgeText="Mercancía SAT Clave 10151500 Trigo" variant="default">
     <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-3 space-y-2 font-mono text-[11px]">
      <div className="flex justify-between"><span className="text-[#666]">Peso Bruto</span><span className="text-white font-bold">9,500 KG</span></div>
      <div className="flex justify-between"><span className="text-[#666]">Valor Mercancía</span><span className="text-white font-bold">$120,000 MXN</span></div>
      <div className="flex justify-between"><span className="text-[#666]">Material Peligroso</span><span className="text-emerald-400">NO</span></div>
      <div className="flex justify-between border-t border-[#1a1a1a] pt-2"><span className="text-[#666]">Distancia</span><span className="text-white">720km GDL-CUL</span></div>
     </div>
    </CyberCard>

    <CyberCard badgeText="Verificación SAT rápida" variant="glass">
     <div className="flex gap-4 items-center">
      <div className="p-3 bg-white rounded-xl"><QrCode className="w-16 h-16 text-black" /></div>
      <div className="flex-1 space-y-2">
       <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-mono font-bold"><CheckCircle2 className="w-4 h-4"/> Timbrado válido SAT</div>
       <p className="text-[11px] font-mono text-[#888] leading-relaxed">Escanea para verificar en sat.gob.mx</p>
       <div className="flex gap-2">
        <button className="flex-1 py-2 bg-[#12151c] border border-slate-800 rounded-lg text-[11px] font-mono text-white">Compartir</button>
        <button className="flex-1 py-2 bg-white text-black rounded-lg text-[11px] font-bold">Reenviar cliente</button>
       </div>
      </div>
     </div>
    </CyberCard>

    <div className="flex gap-2">
     <button className="flex-1 py-3 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white flex items-center justify-center gap-2"><Search className="w-4 h-4"/> Historial timbres</button>
     <button className="flex-1 py-3 bg-white text-black rounded-xl text-xs font-black flex items-center justify-center gap-2"><Plus className="w-4 h-4"/> Nueva Carta Porte</button>
    </div>
   </div>
  </div>
 );
}
