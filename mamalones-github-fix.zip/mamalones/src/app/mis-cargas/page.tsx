"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowLeft, Clock, DollarSign, MapPin, Truck, Star, Eye, CheckCircle2, XCircle, MessageCircle } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton, EmptyState } from "@/components/PremiumUI";
import { EscrowFlow } from "@/components/Security";

export default function MisCargasCliente() {
 const [cargas, setCargas] = useState<any[]>([]);
 const [ofertas, setOfertas] = useState<any[]>([]);
 const [selectedCarga, setSelectedCarga] = useState<any>(null);

 useEffect(() => {
  const c = JSON.parse(localStorage.getItem("mis_cargas_cliente") || "[]");
  setCargas(c);
  // Mock ofertas para demo
  if (c.length > 0 && localStorage.getItem("mis_ofertas_transportista")) {
   // no-op
  }
  // Demo ofertas generadas
  const demoOfertas = JSON.parse(localStorage.getItem("ofertas_para_cliente") || "[]");
  if (demoOfertas.length === 0) {
   const demos = [
    { id:"of-1", cargaId: c[0]?.id || "carga-9901-prod", empresa:"Transportes Mamalones JAL", rating:4.9, chofer:"Donovan Ávila FED-8839201", unidad:"88-AA-3B Torton Kenworth", precio:39500, precioCliente:38500, etaRecogida:"En 2 horas", etaEntrega:"Mañana 20:00", comentario:"A 5km de tu bodega, listo en 2h, incluye casetas, 38 viajes sin incidentes", status:"pendiente" },
    { id:"of-2", cargaId: c[0]?.id || "carga-9901-prod", empresa:"Fletes del Pacífico", rating:4.7, chofer:"Jesús M. FED-7728102", unidad:"99-BB-4C Rabón Freightliner", precio:37000, precioCliente:38500, etaRecogida:"En 4 horas", etaEntrega:"Mañana 14:00", comentario:"Unidad disponible Tlaquepaque, puedo recoger hoy", status:"pendiente" },
   ];
   if (c.length > 0) {
    localStorage.setItem("ofertas_para_cliente", JSON.stringify(demos));
    setOfertas(demos);
   }
  } else {
   setOfertas(demoOfertas);
  }
 }, []);

 const aceptarOferta = (oferta:any) => {
  if (confirm(`¿Aceptar oferta de ${oferta.empresa} por $${oferta.precio.toLocaleString()}? Se retiene escrow y se notifica al chofer.`)) {
   const aceptada = { ...oferta, status:"aceptada", aceptadaAt: new Date().toISOString() };
   const nuevas = ofertas.map(o=>o.id===oferta.id? aceptada : {...o, status:"rechazada"});
   localStorage.setItem("ofertas_para_cliente", JSON.stringify(nuevas));
   setOfertas(nuevas);
   alert(` Oferta aceptada! ${oferta.empresa} ${oferta.unidad} Chofer ${oferta.chofer}\n WhatsApp chofer enviado\n Escrow $${(oferta.precio||38500).toLocaleString()} retenido\n Próximo: Chofer hace check-in con ticket báscula`);
  }
 };

 if (cargas.length === 0) {
  return (
   <div className="min-h-screen max-w-md mx-auto p-4 pb-28">
    <div className="flex items-center gap-3 border-b border-[#1a1a1a] pb-3">
     <Link href="/publicar" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4 text-white"/></Link>
     <div><h1 className="text-sm font-black text-white">MIS CARGAS CLIENTE</h1><span className="text-[10px] font-mono text-[#666]">Cargas que publicaste + ofertas transportistas</span></div>
    </div>
    <div className="pt-8">
     <EmptyState title="Aún no publicas cargas" description="Publica tu primera carga de materia prima y recibe ofertas de mamalones verificados en minutos" action={<Link href="/publicar" className="mt-2 inline-block px-4 py-2 bg-white text-black font-bold rounded-xl text-xs">+ Publicar mi primera carga</Link>} />
    </div>
   </div>
  );
 }

 return (
  <div className="min-h-screen max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4 space-y-3">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4 text-white"/></Link>
     <div><h1 className="text-sm font-black text-white">MIS CARGAS CLIENTE</h1><span className="text-[10px] font-mono text-[#666]">{cargas.length} cargas publicadas {ofertas.filter(o=>o.status==="pendiente").length} ofertas pendientes</span></div>
    </div>
   </div>

   <div className="p-4 space-y-4">
    {cargas.map(carga=>(
     <CyberCard key={carga.id} variant="glass" badgeText={`${carga.estatus?.toUpperCase() || "BUSCANDO"} ${carga.distanciaKm || 720}km ${carga.pesoTon || 9.5}T`}>
      <div className="space-y-3">
       <div className="flex justify-between items-start">
        <div><div className="text-xs font-bold text-white flex items-center gap-1"><MapPin className="w-3 h-3"/>{carga.origen || "Guadalajara"} → {carga.destino || "Culiacán"}</div><span className="text-[10px] font-mono text-[#666]">{carga.fechaRecogida || "Hoy"} {carga.unidadRequerida || "Torton"} {carga.pesoTon || 9.5}T</span></div>
        <div className="text-right"><span className="text-sm font-black font-mono text-white">${(carga.montoOfrecido || 38500).toLocaleString()}</span><span className="text-[10px] font-mono text-[#666] block">{carga.permitirContraofertas? "Ofertable":"Fija"}</span></div>
       </div>

       <EscrowFlow amount={carga.montoOfrecido || 38500} status="depositado" />

       <div className="flex gap-2">
        <button onClick={()=>setSelectedCarga(carga)} className="flex-1 py-2.5 bg-white text-black font-black rounded-xl text-xs flex items-center justify-center gap-2"><Eye className="w-4 h-4"/> Ver {ofertas.filter(o=>o.cargaId===carga.id).length || 2} ofertas</button>
        <Link href="/publicar" className="px-3 py-2.5 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white">Editar</Link>
       </div>
      </div>
     </CyberCard>
    ))}

    {selectedCarga && (
     <div className="fixed inset-0 z-[70] bg-black/90 backdrop-blur-xl max-w-md mx-auto p-4 flex flex-col">
      <div className="bg-[#0e0e10] border border-[#222] rounded-2xl flex flex-col max-h-[92vh] overflow-hidden">
       <div className="p-4 border-b border-[#1e1e1e] flex items-center justify-between"><h2 className="text-sm font-black text-white">Ofertas para {selectedCarga.origen} → {selectedCarga.destino}</h2><button onClick={()=>setSelectedCarga(null)} className="p-2 bg-[#1a1a1a] border border-[#222] rounded-xl text-white">No</button></div>
       <div className="overflow-y-auto flex-1 p-4 space-y-3">
        {ofertas.filter(o=>o.cargaId===selectedCarga.id).map(oferta=>(
         <CyberCard key={oferta.id} variant={oferta.status==="aceptada"?"emerald":oferta.status==="pendiente"?"glow":"default"} badgeText={`${oferta.empresa} ${oferta.status.toUpperCase()} ${oferta.rating} `}>
          <div className="space-y-3">
           <div className="flex gap-3">
            <div className="w-10 h-10 bg-[#12151c] border border-[#222] rounded-xl flex items-center justify-center text-white font-bold text-xs">{oferta.empresa.slice(0,2)}</div>
            <div className="flex-1">
             <span className="text-xs font-bold text-white block">{oferta.empresa} <Star className="w-3 h-3 inline text-amber-400 fill-amber-400"/>{oferta.rating}</span>
             <span className="text-[10px] font-mono text-[#888]">{oferta.unidad} {oferta.chofer}</span>
            </div>
            <div className="text-right"><span className="text-sm font-black font-mono text-white">${oferta.precio.toLocaleString()}</span><span className="text-[10px] font-mono text-[#666] block">vs tu ${oferta.precioCliente?.toLocaleString()}</span>{oferta.precio > (oferta.precioCliente||0) ? <PremiumBadge variant="warning">+${(oferta.precio-(oferta.precioCliente||0)).toLocaleString()}</PremiumBadge> : <PremiumBadge variant="success">-${((oferta.precioCliente||0)-oferta.precio).toLocaleString()} ahorro</PremiumBadge>}</div>
           </div>
           <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-2.5 space-y-1 text-[11px] font-mono">
            <div className="flex justify-between"><span className="text-[#666]">ETA Recogida</span><span className="text-white font-bold">{oferta.etaRecogida}</span></div>
            <div className="flex justify-between"><span className="text-[#666]">ETA Entrega</span><span className="text-white font-bold">{oferta.etaEntrega}</span></div>
            <div className="flex justify-between"><span className="text-[#666]">Comentario</span><span className="text-[#aaa] truncate max-w-[180px]">{oferta.comentario}</span></div>
           </div>
           {oferta.status==="pendiente" ? (
            <div className="grid grid-cols-2 gap-2">
             <PremiumButton onClick={()=>aceptarOferta(oferta)} variant="success" size="sm"><CheckCircle2 className="w-4 h-4"/> Aceptar oferta</PremiumButton>
             <button onClick={()=>{const no=ofertas.filter(x=>x.id!==oferta.id); setOfertas(no); localStorage.setItem("ofertas_para_cliente", JSON.stringify(no));}} className="py-2 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white flex items-center justify-center gap-1"><XCircle className="w-3 h-3"/> Rechazar</button>
            </div>
           ) : oferta.status==="aceptada" ? (
            <div className="space-y-2">
             <div className="p-2.5 bg-emerald-950/30 border border-emerald-900/30 rounded-xl text-center"><span className="text-xs font-black text-emerald-400"> Aceptada Chofer en camino a recoger</span><span className="text-[10px] font-mono text-emerald-300/70 block">Escrow retenido Seguimiento activo en /rastreo</span></div>
             <div className="grid grid-cols-2 gap-2"><Link href="/rastreo" className="py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold text-center">Ver rastreo GPS</Link><a href={`https://wa.me/523333333333?text=Hola ${oferta.chofer} voy de cliente`} target="_blank" className="py-2 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white flex items-center justify-center gap-1"><MessageCircle className="w-3 h-3"/> WhatsApp chofer</a></div>
            </div>
           ) : (
            <div className="p-2 bg-[#0a0a0a] border border-[#222] rounded-xl text-center text-[11px] font-mono text-[#666]">Oferta rechazada</div>
           )}
          </div>
         </CyberCard>
        ))}
       </div>
      </div>
     </div>
    )}
   </div>
  </div>
 );
}
