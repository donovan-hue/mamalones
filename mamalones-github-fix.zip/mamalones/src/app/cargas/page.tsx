"use client";
// @ts-nocheck
import { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import { 
 MapPin, ShieldCheck, ChevronRight, Plus, ArrowLeft, Loader2, Lock, 
 Search, Heart, Share2, MessageCircle, Clock, 
 Truck, Fuel, Weight, Star, Copy, Check, Navigation, HardHat, Calculator, DollarSign, Package
} from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton, PremiumSelect, Skeleton, EmptyState } from "@/components/PremiumUI";
import { supabase, isDemoMode } from "@/lib/supabase";
import { useRole } from "@/hooks/useRole";
import { calcularPrecioSugerido, calcularETAs, PRODUCTOS_GRANOS } from "@/lib/types";
import { RoleSwitcher } from "@/components/RoleSwitcher";
import { EscrowFlow, ValidationChecklist } from "@/components/Security";

interface Carga {
 id: string;
 origen: string;
 destino: string;
 origenExacto?: string;
 destinoExacto?: string;
 distanciaKm: number;
 montoOfrecido: number;
 montoContraoferta?: number;
 permitirContraofertas: boolean;
 producto: string;
 tipoProducto: string;
 pesoTon: number;
 pesoKg: number;
 unidadRequerida: string;
 epp?: string;
 urgencia: "normal" | "urgente" | "express";
 fechaRecogida: string;
 clienteNombre: string;
 clienteRating: number;
 escrowActivo: boolean;
 seguroActivo: boolean;
 estatus: string;
 createdAt: string;
 ofertasCount?: number;
}

const CARGAS_DEMO: Carga[] = [
 {
  id: "carga-9901-prod",
  origen: "Guadalajara, JAL",
  destino: "Culiacán, SIN",
  origenExacto: "Bodega Granos Occidente, Calle 8 #142, Loma Dorada",
  destinoExacto: "Bodega Cliente Sinaloa, Km 12 Carretera a Navolato",
  distanciaKm: 720,
  montoOfrecido: 38500,
  permitirContraofertas: true,
  producto: "9.5 Toneladas Trigo Comercial 12% proteína",
  tipoProducto: "trigo",
  pesoTon: 9.5,
  pesoKg: 9500,
  unidadRequerida: "Torton Cajas Secas 3 ejes",
  epp: "Casco y chaleco básico",
  urgencia: "urgente",
  fechaRecogida: "Hoy 14:00",
  clienteNombre: "Granos de Occidente SA",
  clienteRating: 4.9,
  escrowActivo: true,
  seguroActivo: true,
  estatus: "buscando",
  createdAt: new Date().toISOString(),
  ofertasCount: 3,
 },
 {
  id: "carga-8802-prod",
  origen: "Tlaquepaque, JAL",
  destino: "Mazatlán, SIN",
  distanciaKm: 310,
  montoOfrecido: 24000,
  permitirContraofertas: false,
  producto: "12 Toneladas Maíz Blanco Premium",
  tipoProducto: "maiz",
  pesoTon: 12,
  pesoKg: 12000,
  unidadRequerida: "Tolva 35m3 Granelera",
  epp: "Overol + botas + casco",
  urgencia: "normal",
  fechaRecogida: "Mañana 08:00",
  clienteNombre: "Comercializadora El Bajío",
  clienteRating: 4.7,
  escrowActivo: true,
  seguroActivo: false,
  estatus: "buscando",
  createdAt: new Date(Date.now() - 3600000*2).toISOString(),
  ofertasCount: 1,
 },
 {
  id: "carga-7703-prod",
  origen: "Zapopan, JAL",
  destino: "Tepic, NAY",
  distanciaKm: 180,
  montoOfrecido: 18500,
  permitirContraofertas: true,
  producto: "8 Toneladas Soya Premium",
  tipoProducto: "soya",
  pesoTon: 8,
  pesoKg: 8000,
  unidadRequerida: "Torton Rabón Heavy Duty",
  urgencia: "express",
  fechaRecogida: "En 2 horas ",
  clienteNombre: "AgroGDL",
  clienteRating: 5.0,
  escrowActivo: true,
  seguroActivo: true,
  estatus: "con_ofertas",
  createdAt: new Date(Date.now() - 3600000*5).toISOString(),
  ofertasCount: 5,
 },
];

export default function BolsaCargaMamalonesPremium() {
 const { role } = useRole();
 const [cargas, setCargas] = useState<Carga[]>([]);
 const [loading, setLoading] = useState(true);
 const [filter, setFilter] = useState<"todas" | "escrow" | "mi_unidad" | "cerca">("todas");
 const [unidadFilter, setUnidadFilter] = useState<string>("todas");
 const [searchText, setSearchText] = useState("");
 const [selected, setSelected] = useState<Carga | null>(null);
 const [showCounterOffer, setShowCounterOffer] = useState(false);
 const [favorites, setFavorites] = useState<string[]>([]);
 const [copiedId, setCopiedId] = useState<string | null>(null);

 // Form contraoferta transportista
 const [miUnidad, setMiUnidad] = useState("88-AA-3B Torton 3 ejes Kenworth T680 2022");
 const [miChofer, setMiChofer] = useState("Donovan Ávila FED-8839201 4.9 ");
 const [miPrecio, setMiPrecio] = useState("");
 const [etaRecogida, setEtaRecogida] = useState("En 2 horas");
 const [etaEntrega, setEtaEntrega] = useState("Mañana 20:00");
 const [comentario, setComentario] = useState("");

 useEffect(() => {
  const favs = localStorage.getItem("mamalones_favs");
  if (favs) setFavorites(JSON.parse(favs));
 }, []);

 const toggleFav = (id: string) => {
  const nf = favorites.includes(id) ? favorites.filter(f => f !== id) : [...favorites, id];
  setFavorites(nf);
  localStorage.setItem("mamalones_favs", JSON.stringify(nf));
 };

 useEffect(() => {
  async function fetchCargas() {
   setLoading(true);
   await new Promise(r=>setTimeout(r,500));
   setCargas(CARGAS_DEMO);
   setLoading(false);
  }
  fetchCargas();
 }, []);

 const filtered = useMemo(() => {
  return cargas.filter(c => {
   if (filter === "escrow" && !c.escrowActivo) return false;
   if (filter === "cerca" && c.distanciaKm > 400) return false;
   if (unidadFilter !== "todas" && !c.unidadRequerida.toLowerCase().includes(unidadFilter.toLowerCase())) return false;
   if (searchText && !(c.origen.toLowerCase().includes(searchText.toLowerCase()) || c.destino.toLowerCase().includes(searchText.toLowerCase()) || c.producto.toLowerCase().includes(searchText.toLowerCase()))) return false;
   return true;
  });
 }, [cargas, filter, unidadFilter, searchText]);

 const handleAceptarTarifaFija = (carga: Carga) => {
  const oferta = {
   id: `oferta-${Date.now()}`,
   cargaId: carga.id,
   precio: carga.montoOfrecido,
   unidad: miUnidad,
   chofer: miChofer,
   etaRecogida,
   etaEntrega,
   comentario,
   status: "pendiente",
   createdAt: new Date().toISOString(),
  };
  const existing = JSON.parse(localStorage.getItem("mis_ofertas_transportista") || "[]");
  localStorage.setItem("mis_ofertas_transportista", JSON.stringify([oferta, ...existing]));
  alert(` Viaje tomado con tarifa fija $${carga.montoOfrecido.toLocaleString()}!\n Cliente notificado Escrow retenido\n Unidad ${miUnidad.split("")[0]} Chofer ${miChofer.split("")[0]}\n Recogida: ${etaRecogida} Entrega: ${etaEntrega}\n\nSiguiente: Sube foto ticket báscula en Check-in para activar GPS`);
  setSelected(null);
 };

 const handleContraoferta = (carga: Carga) => {
  if (!miPrecio) { alert("Pon tu precio contraoferta"); return; }
  const oferta = {
   id: `oferta-${Date.now()}`,
   cargaId: carga.id,
   precio: parseFloat(miPrecio),
   precioCliente: carga.montoOfrecido,
   unidad: miUnidad,
   chofer: miChofer,
   etaRecogida,
   etaEntrega,
   comentario,
   status: "pendiente",
   createdAt: new Date().toISOString(),
  };
  const existing = JSON.parse(localStorage.getItem("mis_ofertas_transportista") || "[]");
  localStorage.setItem("mis_ofertas_transportista", JSON.stringify([oferta, ...existing]));
  alert(` Contraoferta enviada: $${parseFloat(miPrecio).toLocaleString()} (cliente ofreció $${carga.montoOfrecido.toLocaleString()})\n Con tu reputación 4.9  tienes 78% prob de aceptada\n ${miUnidad}\n ${etaRecogida} → ${etaEntrega}`);
  setShowCounterOffer(false);
  setSelected(null);
 };

 const copyLink = (id: string) => {
  navigator.clipboard.writeText(`https://mamalones.vercel.app/cargas#${id}`);
  setCopiedId(id);
  setTimeout(() => setCopiedId(null), 2000);
 };

 if (loading) {
  return (
   <div className="min-h-screen p-4 max-w-md mx-auto space-y-3">
    <Skeleton className="h-16 rounded-xl" />
    <Skeleton className="h-24 rounded-xl" />
    {[1,2,3].map(i=><Skeleton key={i} className="h-40 rounded-xl" />)}
   </div>
  );
 }

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-[73px] z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4 space-y-3">
    <div className="flex items-center justify-between gap-2">
     <div className="flex items-center gap-2">
      <Link href="/" className="p-2 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4" /></Link>
      <div>
       <h1 className="text-sm font-black tracking-tight text-white flex items-center gap-2">BOLSA DE CARGA <PremiumBadge variant="live">{filtered.length} LIVE</PremiumBadge></h1>
       <span className="text-[10px] font-mono text-[#666] uppercase">Mamalones materia prima Filtra por cercanía, unidad, $/km</span>
      </div>
     </div>
     <RoleSwitcher />
    </div>

    <div className="relative">
     <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#555]" />
     <input value={searchText} onChange={e=>setSearchText(e.target.value)} placeholder="Buscar trigo, maíz, soya, ruta GDL-CUL..." className="w-full bg-[#0a0a0a] border border-[#222] focus:border-[#444] rounded-xl py-2.5 pl-10 pr-4 text-xs font-mono text-white outline-none placeholder:text-[#555]" />
    </div>

    <div className="flex gap-1.5 overflow-x-auto scrollbar-none pb-1">
     {[{id:"todas", label:"Todas"},{id:"escrow", label:"Escrow "},{id:"cerca", label:"Cerca <400km"},{id:"mi_unidad", label:"Mi unidad Torton"}].map(f=>(
      <button key={f.id} onClick={()=>setFilter(f.id as any)} className={`whitespace-nowrap px-3 py-1.5 rounded-full text-[11px] font-mono font-bold border ${filter===f.id?"bg-white text-black border-white":"bg-[#0a0a0a] text-[#888] border-[#222] hover:text-white"}`}>{f.label}</button>
     ))}
    </div>

    <div className="flex gap-1.5 overflow-x-auto scrollbar-none">
     {["Torton","Tolva","Rabón","Thermo","Plataforma"].map(u=>(
      <button key={u} onClick={()=>setUnidadFilter(unidadFilter===u?"todas":u)} className={`whitespace-nowrap px-2.5 py-1 rounded-full text-[10px] font-mono border ${unidadFilter===u?"bg-white text-black border-white":"bg-[#0a0a0a] text-[#666] border-[#222]"}`}>{u}</button>
     ))}
    </div>

    <div className="grid grid-cols-3 gap-2 text-[10px] font-mono">
     <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-2 text-center"><span className="text-[#666] block uppercase text-[9px]">Tarifa prom</span><span className="text-white font-black">${(cargas.reduce((a,b)=>a+b.montoOfrecido,0)/cargas.length/1000).toFixed(1)}k</span></div>
     <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-2 text-center"><span className="text-[#666] block uppercase text-[9px]">$/km prom</span><span className="text-white font-black">${Math.round(cargas.reduce((a,b)=>a+b.montoOfrecido/b.distanciaKm,0)/cargas.length)}/km</span></div>
     <div className="bg-emerald-950/20 border border-emerald-900/30 rounded-xl p-2 text-center"><span className="text-emerald-400 block uppercase text-[9px]">Con escrow</span><span className="text-emerald-400 font-black">{cargas.filter(c=>c.escrowActivo).length} cargas</span></div>
    </div>
   </div>

   <div className="p-4 space-y-3">
    <div className="flex items-center gap-2 text-[10px] font-mono text-[#555] bg-[#0a0a0a] border border-[#1a1a1a] rounded-full px-3 py-1.5 w-fit"><Lock className="w-3 h-3 text-emerald-400" />Bolsa pública Al tomar viaje desaparece Solo asignado ve puntos exactos</div>

    {filtered.map(carga=>{
     const sug = calcularPrecioSugerido(carga.pesoTon, carga.distanciaKm, carga.tipoProducto);
     const etas = calcularETAs(carga.distanciaKm, 2);
     return (
      <CyberCard key={carga.id} variant={carga.escrowActivo?"emerald":"default"} badgeText={`${carga.urgencia==="express"?" EXPRESS ":carga.urgencia==="urgente"?" URGENTE ":""}ID ${carga.id.slice(-4).toUpperCase()} ${carga.ofertasCount} ofertas ${Math.round((Date.now()-new Date(carga.createdAt).getTime())/60000)}m`}>
       <div className="space-y-3">
        <div className="flex justify-between items-start">
         <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-bold text-white"><MapPin className="w-3.5 h-3.5 text-[#666]"/>{carga.origen} → {carga.destino} {carga.distanciaKm}km</div>
          <div className="flex items-center gap-2 text-[10px] font-mono">
           <span className="flex items-center gap-1 text-[#888]"><Weight className="w-3 h-3"/>{carga.pesoTon}T {carga.tipoProducto}</span>
           <span className="flex items-center gap-1 text-[#888]"><Clock className="w-3 h-3"/>{carga.fechaRecogida}</span>
           <span className="text-amber-400 flex items-center gap-0.5"><Star className="w-3 h-3 fill-amber-400"/> {carga.clienteRating}</span>
          </div>
         </div>
         <div className="text-right">
          <div className="text-base font-black font-mono text-white">${carga.montoOfrecido.toLocaleString()}</div>
          <div className="text-[10px] font-mono text-[#666]">${(carga.montoOfrecido/carga.distanciaKm).toFixed(0)}/km ${(carga.montoOfrecido/carga.pesoTon).toFixed(0)}/ton</div>
          {carga.permitirContraofertas ? <PremiumBadge variant="default">Ofertable</PremiumBadge> : <PremiumBadge variant="success">Fija</PremiumBadge>}
         </div>
        </div>

        <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-2.5 space-y-1.5 text-[11px] font-mono">
         <div className="flex justify-between"><span className="text-[#666] flex items-center gap-1"><Package className="w-3 h-3"/> Producto</span><span className="text-white font-bold">{carga.producto}</span></div>
         <div className="flex justify-between"><span className="text-[#666] flex items-center gap-1"><Truck className="w-3 h-3"/> Unidad</span><span className="text-[#ccc]">{carga.unidadRequerida}</span></div>
         <div className="flex justify-between"><span className="text-[#666] flex items-center gap-1"><HardHat className="w-3 h-3"/> EPP</span><span className="text-[#aaa]">{carga.epp}</span></div>
         <div className="flex justify-between"><span className="text-[#666]">Cliente</span><span className="text-[#aaa] truncate max-w-[150px]">{carga.clienteNombre} Escrow {carga.escrowActivo?"Sí":"No"} Seguro {carga.seguroActivo?"Sí":"No"}</span></div>
        </div>

        <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-xl p-2.5 flex gap-2">
         <Calculator className="w-4 h-4 text-[#666] shrink-0 mt-0.5" />
         <div className="text-[10px] font-mono text-[#888] leading-relaxed">
          Sugerido <span className="text-white font-bold">${sug.optimo.toLocaleString()}</span> (min ${sug.min.toLocaleString()} - max ${sug.max.toLocaleString()}) Cliente ofrece <span className={carga.montoOfrecido>=sug.min && carga.montoOfrecido<=sug.max ? "text-emerald-400" : "text-amber-400"}>${carga.montoOfrecido.toLocaleString()}</span> ETA {etas.horasTransito.toFixed(1)}h tránsito
         </div>
        </div>

        <div className="flex gap-1.5">
         <button onClick={()=>toggleFav(carga.id)} className={`p-2.5 rounded-xl border ${favorites.includes(carga.id)?"bg-red-950/30 border-red-900/30 text-red-400":"bg-[#12151c] border-slate-800 text-slate-500"}`}><Heart className={`w-4 h-4 ${favorites.includes(carga.id)?"fill-red-400":""}`} /></button>
         <button onClick={()=>copyLink(carga.id)} className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl text-slate-400"><Copy className="w-4 h-4"/></button>
         <button onClick={()=>setSelected(carga)} className="flex-1 bg-white text-black font-black py-2.5 rounded-xl text-xs flex items-center justify-center gap-2">Ver detalles + Ofertar <ChevronRight className="w-4 h-4"/></button>
        </div>
       </div>
      </CyberCard>
     );
    })}
   </div>

   {/* Modal detalle + ofertar */}
   {selected && (
    <div className="fixed inset-0 z-[70] bg-black/90 backdrop-blur-xl max-w-md mx-auto p-4 flex flex-col">
     <div className="bg-[#0e0e10] border border-[#222] rounded-2xl flex flex-col max-h-[92vh] overflow-hidden">
      <div className="p-4 border-b border-[#1e1e1e] flex items-center justify-between">
       <div><h2 className="text-sm font-black text-white flex items-center gap-2">{selected.origen} → {selected.destino} <PremiumBadge variant={selected.permitirContraofertas?"default":"success"}>{selected.permitirContraofertas?"Ofertable":"Tarifa fija"}</PremiumBadge></h2><span className="text-[10px] font-mono text-[#666]">{selected.id} {selected.distanciaKm}km {selected.pesoTon}T</span></div>
       <button onClick={()=>{setSelected(null); setShowCounterOffer(false);}} className="p-2 bg-[#1a1a1a] border border-[#222] rounded-xl text-white">No</button>
      </div>

      <div className="overflow-y-auto flex-1 p-4 space-y-4">
       <div className="grid grid-cols-2 gap-2">
        <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-3"><span className="text-[9px] font-mono text-[#666] uppercase block">Tarifa cliente ofrece</span><span className="text-lg font-black font-mono text-white">${selected.montoOfrecido.toLocaleString()}</span><span className="text-[10px] font-mono text-[#666]">${(selected.montoOfrecido/selected.distanciaKm).toFixed(0)}/km ${(selected.montoOfrecido/selected.pesoTon).toFixed(0)}/ton</span></div>
        <div className="bg-emerald-950/20 border border-emerald-900/30 rounded-xl p-3"><span className="text-[9px] font-mono text-emerald-400 uppercase block">Escrow + Seguro</span><span className="text-sm font-bold text-emerald-400 block">{selected.escrowActivo?"Escrow Sí":"Sin escrow"} {selected.seguroActivo?"Asegurado Sí":"Sin seguro"}</span><span className="text-[10px] font-mono text-[#666]">Pago garantizado</span></div>
       </div>

       <CyberCard badgeText="Mercancía exacta que transportar" variant="glass">
        <div className="space-y-2 text-xs font-mono">
         <div className="flex justify-between"><span className="text-[#666]">Producto</span><span className="text-white font-bold">{selected.producto}</span></div>
         <div className="flex justify-between"><span className="text-[#666]">Peso / Volumen</span><span className="text-white">{selected.pesoTon}T {selected.pesoKg}kg</span></div>
         <div className="flex justify-between"><span className="text-[#666]">Unidad req</span><span className="text-white">{selected.unidadRequerida}</span></div>
         <div className="flex justify-between"><span className="text-[#666]">EPP</span><span className="text-white">{selected.epp}</span></div>
         <div className="flex justify-between"><span className="text-[#666]">Recogida</span><span className="text-white">{selected.fechaRecogida}</span></div>
         <div className="flex justify-between"><span className="text-[#666]">Origen exacto</span><span className="text-amber-400 text-[10px]">Solo visible al tomar viaje </span></div>
        </div>
       </CyberCard>

       <EscrowFlow amount={selected.montoOfrecido} status="depositado" />
       <ValidationChecklist type="empresa" />

       {!showCounterOffer ? (
        <div className="space-y-3">
         <p className="text-xs font-bold text-white">¿Cómo quieres tomar este viaje?</p>
         <PremiumButton onClick={()=>handleAceptarTarifaFija(selected)} variant="primary" size="lg" className="w-full"><Check className="w-4 h-4"/> ACEPTAR TARIFA FIJA ${selected.montoOfrecido.toLocaleString()} 1 toque</PremiumButton>
         {selected.permitirContraofertas && <button onClick={()=>{setShowCounterOffer(true); setMiPrecio((selected.montoOfrecido*1.05).toFixed(0));}} className="w-full py-3 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-2"><DollarSign className="w-4 h-4"/> ENVIAR CONTRAOFERTA con mi precio + unidad + ETA</button>}
         <p className="text-[10px] font-mono text-[#555] text-center">Al aceptar especificas unidad, placas, chofer, ETA recogida/entrega. Cliente ve tu reputación 4.9 </p>
        </div>
       ) : (
        <CyberCard badgeText="Contraoferta transportista Tu precio + unidad + tiempos" variant="glow">
         <div className="space-y-3">
          <PremiumSelect label="Mi unidad + placas *" value={miUnidad} onChange={e=>setMiUnidad(e.target.value)}>
           <option>88-AA-3B Torton 3 ejes Kenworth T680 2022 Disponible</option>
           <option>99-BB-4C Rabón Freightliner M2 2020 Disponible</option>
           <option>77-CC-2A Thermo 53ft International 2021 En taller 2h</option>
          </PremiumSelect>
          <PremiumSelect label="Chofer asignado *" value={miChofer} onChange={e=>setMiChofer(e.target.value)}>
           <option>Donovan Ávila FED-8839201 4.9  38 viajes Verificado SCT</option>
           <option>Jesús M. FED-7728102 4.7  22 viajes</option>
          </PremiumSelect>
          <div className="grid grid-cols-2 gap-3">
           <div className="space-y-1.5"><label className="text-[10px] font-mono font-bold text-[#666] uppercase">Mi precio contraoferta MXN *</label><input value={miPrecio} onChange={e=>setMiPrecio(e.target.value)} type="number" className="w-full bg-[#0a0b0d] border border-slate-800 rounded-xl p-2.5 text-xs font-mono text-white outline-none" placeholder="40000" /></div>
           <div className="space-y-1.5"><label className="text-[10px] font-mono font-bold text-[#666] uppercase">Cliente ofrece</label><div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-2.5 text-xs font-mono text-[#888]">${selected.montoOfrecido.toLocaleString()} {(parseFloat(miPrecio||"0")-selected.montoOfrecido)>0?`+${(parseFloat(miPrecio||"0")-selected.montoOfrecido).toLocaleString()} tu plus`:"Tu precio menor, 90% aceptado"}</div></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
           <PremiumSelect label="ETA llegar a recoger" value={etaRecogida} onChange={e=>setEtaRecogida(e.target.value)}><option>En 1 hora</option><option>En 2 horas</option><option>En 4 horas</option><option>Mañana 08:00 AM</option></PremiumSelect>
           <PremiumSelect label="ETA entrega destino" value={etaEntrega} onChange={e=>setEtaEntrega(e.target.value)}><option>Mañana 20:00 30h</option><option>Pasado mañana 14:00 38h</option><option>En 24h</option><option>En 12h express</option></PremiumSelect>
          </div>
          <div className="space-y-1.5"><label className="text-[10px] font-mono font-bold text-[#666] uppercase">Comentario para cliente (reputación)</label><textarea value={comentario} onChange={e=>setComentario(e.target.value)} placeholder="Ej. Unidad disponible ahora en Tlaquepaque a 5km de tu bodega, puedo recoger en 2h, entrego mañana 8pm con ticket báscula, incluye casetas y diesel, mi chofer 4.9  38 viajes sin incidentes..." className="w-full bg-[#0a0b0d] border border-slate-800 rounded-xl p-3 text-xs font-mono text-white outline-none min-h-[70px] placeholder:text-[#555]" /></div>
          <div className="grid grid-cols-2 gap-2">
           <PremiumButton onClick={()=>handleContraoferta(selected)} variant="primary"><DollarSign className="w-4 h-4"/> Enviar contraoferta ${miPrecio? parseFloat(miPrecio).toLocaleString():"0"}</PremiumButton>
           <button onClick={()=>setShowCounterOffer(false)} className="py-2.5 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white">Cancelar</button>
          </div>
         </div>
        </CyberCard>
       )}
      </div>
     </div>
    </div>
   )}
  </div>
 );
}
