"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, MapPin, Clock, Star, Plus, Utensils, Wrench, Fuel, Hotel, ShoppingCart, Truck } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton } from "@/components/PremiumUI";

const categorias = [
 { id:"comida", label:"Comida", icon:Utensils },
 { id:"taller", label:"Talleres", icon:Wrench },
 { id:"diesel", label:"Diesel barato", icon:Fuel },
 { id:"hotel", label:"Hotel + regadera", icon:Hotel },
];

const servicios = [
 { id:1, nombre:"Birria El Chino Tlaquepaque", tipo:"comida", rating:4.8, distancia:"2.3km", precio:"$$", desc:"Menudo, birria, café de olla 24h - 10% descuento mamalones", promo:"10% OFF", tiempo:"8 min" },
 { id:2, nombre:"Vulcanizadora Ruiz Km 142", tipo:"taller", rating:4.9, distancia:"0.5km", precio:"$$$", desc:"Talachas 24h, rescate carretero, llantera", promo:"Rescate", tiempo:"5 min" },
 { id:3, nombre:"Kronos Sushi Operador Arenal", tipo:"comida", rating:4.7, distancia:"12km", precio:"$$", desc:"Combo roll empanizado + bebida energética para viaje", promo:"Combo $180", tiempo:"15 min" },
 { id:4, nombre:"Hotel del Trailero Tepic", tipo:"hotel", rating:4.5, distancia:"42km", precio:"$", desc:"Regadera, estacionamiento seguro, cena", promo:"$350 noche", tiempo:"2 min desvío" },
];

export default function ServiciosRutaPremium() {
 const [cat, setCat] = useState("comida");
 const [cart, setCart] = useState(0);

 const filtrados = servicios.filter(s=>cat==="comida"?true:s.tipo===cat);

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4 space-y-3">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4"/></Link>
     <div className="flex-1"><h1 className="text-sm font-black text-white">SERVICIOS EN RUTA</h1><span className="text-[10px] font-mono text-[#666] uppercase">Paradas verificadas Descuentos mamalones</span></div>
     <button className="relative p-2.5 bg-white text-black rounded-xl"><ShoppingCart className="w-4 h-4"/><span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">{cart}</span></button>
    </div>

    <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1">
     {categorias.map(c=>{
      const Icon=c.icon;
      return (
       <button key={c.id} onClick={()=>setCat(c.id)} className={`whitespace-nowrap flex items-center gap-1.5 px-3 py-2 rounded-full border text-xs font-mono font-bold ${cat===c.id?"bg-white text-black border-white":"bg-[#0a0a0a] border-[#222] text-[#666] hover:text-white"}`}>
        <Icon className="w-3.5 h-3.5"/>{c.label}
       </button>
      );
     })}
    </div>

    <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-xl p-2.5 flex items-center justify-between">
     <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-emerald-400"/><span className="text-[11px] font-mono text-white">Ruta actual: GDL → CUL 12 servicios cerca</span></div>
     <PremiumBadge variant="success">Live</PremiumBadge>
    </div>
   </div>

   <div className="p-4 space-y-4">
    <CyberCard badgeText="Destacado Recomendado por traileros" variant="glow">
     <div className="flex gap-3">
      <div className="w-16 h-16 bg-[#1a1a1a] border border-[#222] rounded-xl flex items-center justify-center text-2xl">🍣</div>
      <div className="flex-1">
       <div className="flex items-center gap-2"><span className="text-sm font-black text-white">Kronos Sushi Operador</span><PremiumBadge variant="warning">Combo</PremiumBadge></div>
       <span className="text-[11px] font-mono text-[#888] block">Roll empanizado + bebida + papas Listo en 12 min para llevar</span>
       <div className="flex items-center gap-2 mt-1"><Star className="w-3 h-3 text-amber-400 fill-amber-400"/><span className="text-[10px] font-mono text-[#aaa]">4.9 127 pedidos 8 min desvío caseta Arenal</span></div>
      </div>
     </div>
     <div className="flex gap-2 mt-3">
      <PremiumButton variant="primary" size="sm" className="flex-1" onClick={()=>setCart(c=>c+1)}><Plus className="w-3 h-3"/> $180 Ordenar para caseta</PremiumButton>
      <button className="px-3 py-2 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white">Ver menú</button>
     </div>
    </CyberCard>

    <h2 className="text-xs font-black text-white">Cerca de ti {cat}</h2>

    <div className="space-y-3">
     {filtrados.map(s=>(
      <CyberCard key={s.id} variant="default" padding="sm">
       <div className="flex gap-3">
        <div className="w-12 h-12 bg-[#12151c] border border-[#222] rounded-xl flex items-center justify-center text-white"><Truck className="w-5 h-5"/></div>
        <div className="flex-1 min-w-0">
         <div className="flex items-center gap-2"><span className="text-xs font-bold text-white truncate">{s.nombre}</span><span className="text-[9px] font-mono bg-[#1a1a1a] border border-[#222] text-[#888] px-1.5 py-0.5 rounded-full">{s.precio}</span></div>
         <span className="text-[11px] font-mono text-[#888] block leading-relaxed truncate">{s.desc}</span>
         <div className="flex items-center gap-2 mt-1">
          <span className="text-[10px] font-mono text-amber-400 flex items-center gap-1"><Star className="w-3 h-3 fill-amber-400"/>{s.rating}</span>
          <span className="text-[10px] font-mono text-[#666] flex items-center gap-1"><MapPin className="w-3 h-3"/>{s.distancia}</span>
          <span className="text-[10px] font-mono text-[#666] flex items-center gap-1"><Clock className="w-3 h-3"/>{s.tiempo}</span>
          {s.promo && <PremiumBadge variant="success">{s.promo}</PremiumBadge>}
         </div>
        </div>
       </div>
       <div className="flex gap-2 mt-2.5">
        <button className="flex-1 py-2 bg-white text-black rounded-xl text-xs font-bold">Pedir / Reservar</button>
        <button className="px-3 py-2 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white">Cómo llegar</button>
       </div>
      </CyberCard>
     ))}
    </div>

    <CyberCard badgeText="¿Tienes negocio en carretera?" variant="glass">
     <div className="text-center py-3 space-y-2">
      <p className="text-xs font-bold text-white">Únete a red de servicios Mamalones</p>
      <p className="text-[11px] font-mono text-[#666]">Recibe 50 traileros al mes Comisión 5% Pago semanal</p>
      <PremiumButton variant="secondary" size="sm" className="w-full">Registrar mi negocio Gratis</PremiumButton>
     </div>
    </CyberCard>
   </div>
  </div>
 );
}
