"use client";

import Link from "next/link";
import { ArrowRight, ShieldCheck, MapPin, Package, Navigation, Camera, Truck, Building } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { RoleSwitcher } from "@/components/RoleSwitcher";
import { useRole } from "@/hooks/useRole";

export default function WelcomeMamalonesMateriaPrima() {
 const { role } = useRole();

 return (
  <div className="min-h-screen bg-[#0A0A0B] text-[#FAFAFA] max-w-md mx-auto pb-28">
   <div className="p-5 space-y-6">
    {/* Header serious */}
    <div className="flex items-center justify-between pt-2">
     <div className="flex items-center gap-3">
      <div className="w-8 h-8 bg-[#FAFAFA] text-[#0A0A0B] rounded-[12px] flex items-center justify-center">
       <Truck className="w-4 h-4" />
      </div>
      <div>
       <span className="text-[13px] font-semibold tracking-[-0.02em] block">MAMALONES</span>
       <span className="text-[10px] font-medium tracking-[0.08em] text-[#71717B] uppercase">Logistics Platform v3.1</span>
      </div>
     </div>
     <PremiumBadge variant="neutral">Jalisco México</PremiumBadge>
    </div>

    <RoleSwitcher />

    {/* Hero serious */}
    <div className="space-y-4 pt-4">
     <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#111113] border border-[#1E1E21] text-[11px] text-[#A1A1AA]">
      <div className="w-1.5 h-1.5 bg-[#22C55E] rounded-full animate-pulse" />
      <span>{role === "cliente" ? "8 solicitudes activas hoy Tiempo medio de oferta 12 minutos" : "12 cargas verificadas disponibles Validación SCT/SAT"}</span>
     </div>
     
     <h1 className="text-[32px] font-semibold tracking-[-0.03em] leading-[0.95] text-balance">
      {role === "cliente" ? (
       <>Plataforma logística para empresas que mueven <span className="text-[#71717B]">materia prima</span> con control total</>
      ) : (
       <>Fletes verificados con pago garantizado y <span className="text-[#71717B]">operación sin intermediarios</span></>
      )}
     </h1>
     
     <p className="text-[14px] leading-[1.6] text-[#A1A1AA] max-w-[95%]">
      {role === "cliente"
       ? "Publica carga especificando material, peso, ruta exacta y tarifa. Recibe ofertas de transportistas verificados con unidad, placas, operador y tiempos estimados de recolección y entrega. Custodia de pago y seguro por tonelada incluidos."
       : "Bolsa de carga filtrada por cercanía, costo por kilómetro y tipo de unidad. Acepta tarifa fija o envía contraoferta con tu unidad, operador y tiempos. Check-in con ticket de báscula activa rastreo satelital."}
     </p>
    </div>

    {/* Trust bar */}
    <div className="flex items-center gap-3 py-3 border-y border-[#1E1E21]">
     <span className="text-[11px] font-medium text-[#52525B] uppercase tracking-[0.06em]">Validado por</span>
     <div className="flex items-center gap-4 text-[11px] font-medium text-[#71717B]">
      <span className="flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5" /> SCT</span>
      <span className="flex items-center gap-1.5"><Building className="w-3.5 h-3.5" /> SAT 3.1</span>
      <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" /> AES-256</span>
     </div>
    </div>

    {/* Flow serious */}
    <CyberCard badgeText={`Flujo operativo ${role.toUpperCase()}`} variant="enterprise">
     <div className="space-y-4">
      {role === "cliente" ? (
       <>
        <div className="flex gap-3"><div className="w-7 h-7 bg-[#FAFAFA] text-[#0A0A0B] rounded-full flex items-center justify-center text-[12px] font-semibold shrink-0">1</div><div className="space-y-1"><p className="text-[13px] font-medium text-[#FAFAFA]">Publicación detallada de carga</p><p className="text-[12px] leading-[1.5] text-[#71717B]">Material, peso en toneladas, volumen, ruta con puntos exactos de carga/descarga, tipo de unidad requerida, equipo de protección y tarifa ofrecida con opción a contraofertas</p></div></div>
        <div className="flex gap-3"><div className="w-7 h-7 bg-[#FAFAFA] text-[#0A0A0B] rounded-full flex items-center justify-center text-[12px] font-semibold shrink-0">2</div><div className="space-y-1"><p className="text-[13px] font-medium text-[#FAFAFA]">Recepción de ofertas verificadas</p><p className="text-[12px] leading-[1.5] text-[#71717B]">Transportistas ofertan con unidad específica, placas, operador con licencia federal verificada, tiempo estimado de llegada y entrega, respaldado por calificación e historial</p></div></div>
        <div className="flex gap-3"><div className="w-7 h-7 bg-[#18181B] border border-[#27272A] text-[#FAFAFA] rounded-full flex items-center justify-center text-[12px] font-medium shrink-0">3</div><div className="space-y-1"><p className="text-[13px] font-medium text-[#FAFAFA]">Custodia y seguimiento</p><p className="text-[12px] leading-[1.5] text-[#71717B]">Depósito en custodia, retención hasta evidencia de entrega. Rastreo satelital con detección de desvíos y zonas de riesgo. Seguro por tonelada opcional</p></div></div>
       </>
      ) : (
       <>
        <div className="flex gap-3"><div className="w-7 h-7 bg-[#FAFAFA] text-[#0A0A0B] rounded-full flex items-center justify-center text-[12px] font-semibold shrink-0">1</div><div className="space-y-1"><p className="text-[13px] font-medium text-[#FAFAFA]">Bolsa de carga filtrada</p><p className="text-[12px] leading-[1.5] text-[#71717B]">Filtra por proximidad a tu ubicación, costo por kilómetro y tipo de unidad. Solo cargas con custodia de pago y verificación de empresa</p></div></div>
        <div className="flex gap-3"><div className="w-7 h-7 bg-[#FAFAFA] text-[#0A0A0B] rounded-full flex items-center justify-center text-[12px] font-semibold shrink-0">2</div><div className="space-y-1"><p className="text-[13px] font-medium text-[#FAFAFA]">Oferta con operador y tiempos</p><p className="text-[12px] leading-[1.5] text-[#71717B]">Acepta tarifa fija en un toque o envía contraoferta especificando unidad, placas, operador con licencia verificada, tiempo estimado de recolección y entrega</p></div></div>
        <div className="flex gap-3"><div className="w-7 h-7 bg-[#18181B] border border-[#27272A] text-[#FAFAFA] rounded-full flex items-center justify-center text-[12px] font-medium shrink-0">3</div><div className="space-y-1"><p className="text-[13px] font-medium text-[#FAFAFA]">Check-in y pago garantizado</p><p className="text-[12px] leading-[1.5] text-[#71717B]">Foto de ticket de báscula inicial activa rastreo satelital y notifica al cliente. Botón de pánico SOS 24/7. Pago liberado inmediatamente al entregar evidencia firmada</p></div></div>
       </>
      )}
     </div>
    </CyberCard>

    {/* Metrics serious */}
    <div className="grid grid-cols-2 gap-3">
     <div className="bg-[#111113] border border-[#1E1E21] rounded-[12px] p-4 space-y-3">
      <div className="w-8 h-8 bg-[#18181B] border border-[#27272A] rounded-[10px] flex items-center justify-center"><ShieldCheck className="w-4 h-4 text-[#A1A1AA]" /></div>
      <div><p className="text-[13px] font-medium text-[#FAFAFA]">Custodia de pago</p><p className="text-[11px] leading-[1.5] text-[#71717B]">Retención segura hasta evidencia de entrega con ticket y firma</p></div>
     </div>
     <div className="bg-[#111113] border border-[#1E1E21] rounded-[12px] p-4 space-y-3">
      <div className="w-8 h-8 bg-[#18181B] border border-[#27272A] rounded-[10px] flex items-center justify-center"><Navigation className="w-4 h-4 text-[#A1A1AA]" /></div>
      <div><p className="text-[13px] font-medium text-[#FAFAFA]">Check-in con báscula</p><p className="text-[11px] leading-[1.5] text-[#71717B]">Foto de ticket activa GPS encriptado AES-256</p></div>
     </div>
     <div className="bg-[#111113] border border-[#1E1E21] rounded-[12px] p-4 space-y-3">
      <div className="w-8 h-8 bg-[#18181B] border border-[#27272A] rounded-[10px] flex items-center justify-center"><Camera className="w-4 h-4 text-[#A1A1AA]" /></div>
      <div><p className="text-[13px] font-medium text-[#FAFAFA]">Validación SCT/SAT</p><p className="text-[11px] leading-[1.5] text-[#71717B]">Licencia federal, CURP, antecedentes y póliza verificada</p></div>
     </div>
     <div className="bg-[#111113] border border-[#1E1E21] rounded-[12px] p-4 space-y-3">
      <div className="w-8 h-8 bg-[#18181B] border border-[#27272A] rounded-[10px] flex items-center justify-center"><Package className="w-4 h-4 text-[#A1A1AA]" /></div>
      <div><p className="text-[13px] font-medium text-[#FAFAFA]">Seguro por tonelada</p><p className="text-[11px] leading-[1.5] text-[#71717B]">Cobertura contra robo y siniestro durante trayecto</p></div>
     </div>
    </div>

    {/* CTA serious */}
    <div className="space-y-3 pt-2">
     {role === "cliente" ? (
      <>
       <Link href="/publicar" className="w-full bg-[#FAFAFA] hover:bg-[#E4E4E7] text-[#0A0A0B] font-medium py-3.5 rounded-[12px] text-[14px] flex items-center justify-center gap-2 transition-colors tracking-[-0.01em]">Publicar carga de materia prima <ArrowRight className="w-4 h-4" /></Link>
       <Link href="/mis-cargas" className="w-full bg-[#111113] hover:bg-[#151518] border border-[#1E1E21] hover:border-[#2A2A2E] text-[#A1A1AA] hover:text-[#FAFAFA] font-medium py-3 rounded-[12px] text-[13px] flex items-center justify-center gap-2 transition-colors">Ver cargas y ofertas recibidas</Link>
      </>
     ) : (
      <>
       <Link href="/cargas" className="w-full bg-[#FAFAFA] hover:bg-[#E4E4E7] text-[#0A0A0B] font-medium py-3.5 rounded-[12px] text-[14px] flex items-center justify-center gap-2 transition-colors">Explorar bolsa de carga <ArrowRight className="w-4 h-4" /></Link>
       <Link href="/mis-viajes" className="w-full bg-[#111113] hover:bg-[#151518] border border-[#1E1E21] hover:border-[#2A2A2E] text-[#A1A1AA] hover:text-[#FAFAFA] font-medium py-3 rounded-[12px] text-[13px] flex items-center justify-center gap-2">Mis viajes y check-in</Link>
      </>
     )}
     <div className="grid grid-cols-2 gap-2">
      <Link href="/dashboard" className="bg-[#0F0F11] border border-[#1E1E21] hover:border-[#2A2A2E] text-[#71717B] hover:text-[#FAFAFA] text-[13px] py-2.5 rounded-[12px] text-center font-medium transition-colors">Dashboard</Link>
      <Link href="/empresa" className="bg-[#0F0F11] border border-[#1E1E21] hover:border-[#2A2A2E] text-[#71717B] hover:text-[#FAFAFA] text-[13px] py-2.5 rounded-[12px] text-center font-medium transition-colors">Empresa verificada</Link>
     </div>
    </div>

    <div className="pt-6 border-t border-[#1E1E21] flex items-center justify-between">
     <span className="text-[11px] font-medium text-[#52525B] tracking-[0.04em] uppercase">Tlaquepaque, Jalisco México 2026</span>
     <span className="text-[11px] text-[#3F3F47]">SCT SAT AES-256</span>
    </div>
   </div>
  </div>
 );
}
