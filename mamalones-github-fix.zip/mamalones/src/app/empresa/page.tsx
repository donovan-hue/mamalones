"use client";

import Link from "next/link";
import { ArrowLeft, ShieldCheck, Star, Truck, MapPin, Package, CheckCircle2, Award, Phone } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { ValidationChecklist } from "@/components/Security";

export default function EmpresaProfilePremium() {
 return (
  <div className="min-h-screen max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4 text-white"/></Link>
     <div><h1 className="text-sm font-black text-white">PERFIL EMPRESA VERIFICADA</h1><span className="text-[10px] font-mono text-[#666]">Validación transportista Anti-fraude</span></div>
     <PremiumBadge variant="success">Verificada</PremiumBadge>
    </div>
   </div>

   <div className="p-4 space-y-4">
    <CyberCard variant="glow" badgeText="Transportes Mamalones JAL RFC validado">
     <div className="flex gap-4">
      <div className="w-16 h-16 bg-white text-black rounded-2xl flex items-center justify-center font-black text-xl">TM</div>
      <div className="flex-1">
       <div className="flex items-center gap-2"><span className="text-sm font-black text-white">Transportes Mamalones JAL</span><ShieldCheck className="w-4 h-4 text-emerald-400"/><Star className="w-4 h-4 text-amber-400 fill-amber-400"/><span className="text-xs font-bold text-amber-400">4.9</span></div>
       <span className="text-[11px] font-mono text-[#888] block">Tlaquepaque, JAL 38 viajes completados Miembro desde 2024</span>
       <div className="flex gap-1.5 mt-1.5 flex-wrap">
        <PremiumBadge variant="success">Oro  4.8</PremiumBadge>
        <PremiumBadge variant="default">38 viajes</PremiumBadge>
        <PremiumBadge variant="default">0 fraudes</PremiumBadge>
       </div>
      </div>
     </div>
    </CyberCard>

    <div className="grid grid-cols-3 gap-2">
     <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-2.5 text-center"><span className="text-[9px] font-mono text-[#666] uppercase block">Viajes</span><span className="text-sm font-black text-white">38</span></div>
     <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-2.5 text-center"><span className="text-[9px] font-mono text-[#666] uppercase block">Puntualidad</span><span className="text-sm font-black text-emerald-400">98%</span></div>
     <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-2.5 text-center"><span className="text-[9px] font-mono text-[#666] uppercase block">Respuesta</span><span className="text-sm font-black text-white">12m prom</span></div>
    </div>

    <CyberCard badgeText="Verificación empresa anti-fraude (para conductor)" variant="default">
     <ValidationChecklist type="empresa" />
    </CyberCard>

    <CyberCard badgeText="Flotilla 3 unidades verificadas SCT" variant="default">
     <div className="space-y-2">
      {[
       { placas:"88-AA-3B", tipo:"Torton Kenworth T680 2022", status:"Disponible Tlaquepaque", km:"142k", rating:"4.9 " },
       { placas:"99-BB-4C", tipo:"Rabón Freightliner M2 2020", status:"En ruta CUL", km:"89k", rating:"4.7 " },
      ].map(u=>(
       <div key={u.placas} className="flex gap-3 p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl">
        <div className="w-10 h-10 bg-[#12151c] border border-[#222] rounded-xl flex items-center justify-center text-white font-bold text-xs">{u.placas.slice(0,2)}</div>
        <div className="flex-1"><span className="text-xs font-bold text-white block">{u.placas} {u.tipo}</span><span className="text-[10px] font-mono text-[#666]">{u.status} {u.km} {u.rating}</span></div>
        <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-1" />
       </div>
      ))}
     </div>
    </CyberCard>

    <CyberCard badgeText="Historial calificaciones clientes">
     <div className="space-y-2">
      {[
       { cliente:"Granos Occidente", texto:"Excelente, llegó 2h antes, todo bien con báscula, 100% recomendado", stars:5 },
       { cliente:"El Bajío", texto:"Muy profesional, unidad limpia, chofer verificado, pago escrow liberado rápido", stars:5 },
      ].map((r,i)=>(
       <div key={i} className="p-3 bg-[#070709] border border-[#1a1a1a] rounded-xl">
        <div className="flex items-center gap-1 mb-1"><span className="text-xs font-bold text-white">{r.cliente}</span><span className="text-amber-400 text-[10px]">{" ".repeat(r.stars)}</span></div>
        <p className="text-[11px] font-mono text-[#888] leading-relaxed">"{r.texto}"</p>
       </div>
      ))}
     </div>
    </CyberCard>

    <div className="grid grid-cols-2 gap-2">
     <a href="https://wa.me/523333333333" target="_blank" className="py-3 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"><Phone className="w-4 h-4"/> Contactar empresa</a>
     <Link href="/cargas" className="py-3 bg-[#12151c] border border-slate-800 text-white rounded-xl text-xs font-bold text-center">Ver cargas compatibles</Link>
    </div>
   </div>
  </div>
 );
}
