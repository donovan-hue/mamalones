"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, QrCode, Wallet, TrendingUp, Plus, CreditCard, MapPin, Clock, Filter } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton } from "@/components/PremiumUI";

export default function CasetaPremium() {
 const [showQr, setShowQr] = useState(false);
 const transactions = [
  { caseta:"Tepic San Mateo", monto:620, hora:"10:15 AM hoy", tipo:"QR", saldo:"4,850" },
  { caseta:"Arenal", monto:195, hora:"08:30 AM hoy", tipo:"Tag", saldo:"5,470" },
  { caseta:"La Barca", monto:85, hora:"Ayer 16:20", tipo:"Tag", saldo:"5,665" },
  { caseta:"Ruiz", monto:620, hora:"Ayer 13:10", tipo:"Tag", saldo:"6,285" },
 ];

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4 space-y-3">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4"/></Link>
     <div><h1 className="text-sm font-black text-white">TAG CASETAS PRO</h1><span className="text-[10px] font-mono text-[#666] uppercase">Wallet + QR encriptado</span></div>
     <PremiumBadge variant="success">IAVE</PremiumBadge>
    </div>
   </div>

   <div className="p-4 space-y-4">
    <CyberCard badgeText="Balance wallet tag" variant="glow">
     <div className="space-y-4">
      <div className="flex justify-between items-start">
       <div>
        <span className="text-[10px] font-mono uppercase text-[#666] tracking-widest">Saldo disponible</span>
        <div className="text-3xl font-black font-mono text-white tracking-tight">$4,850<span className="text-lg text-[#666]"> MXN</span></div>
        <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1"><TrendingUp className="w-3 h-3"/> +$2,000 recarga ayer</span>
       </div>
       <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-black font-black">TAG</div>
      </div>

      <div className="grid grid-cols-2 gap-2">
       <PremiumButton variant="primary" size="md"><Plus className="w-4 h-4"/> Recargar</PremiumButton>
       <button onClick={()=>setShowQr(!showQr)} className="py-2.5 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white flex items-center justify-center gap-2 hover:bg-slate-800"><QrCode className="w-4 h-4"/> {showQr?"Ocultar QR":"Mostrar QR"}</button>
      </div>

      <div className="grid grid-cols-3 gap-2 text-center">
       <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-2"><span className="text-[9px] font-mono text-[#666] uppercase block">Hoy</span><span className="text-sm font-bold font-mono text-white">-$815</span></div>
       <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-2"><span className="text-[9px] font-mono text-[#666] uppercase block">Mes</span><span className="text-sm font-bold font-mono text-white">-$4,230</span></div>
       <div className="bg-[#070709] border border-[#1a1a1a] rounded-xl p-2"><span className="text-[9px] font-mono text-[#666] uppercase block">Ahorro vs efectivo</span><span className="text-sm font-bold font-mono text-emerald-400">12%</span></div>
      </div>
     </div>
    </CyberCard>

    {showQr && (
     <CyberCard badgeText="QR encriptado pase express" variant="emerald" className="animate-in zoom-in">
      <div className="text-center space-y-3 py-2">
       <div className="bg-white p-5 rounded-2xl inline-block shadow-2xl">
        <QrCode className="w-40 h-40 text-black" />
       </div>
       <div>
        <span className="text-[10px] font-mono uppercase text-[#666] tracking-widest block">Folio dinámico Expira 5min</span>
        <span className="text-sm font-mono font-black text-white tracking-tight">KRN-TAG-991823-MX AES-256</span>
        <span className="text-[10px] font-mono text-emerald-400 block mt-1">✓ Válido en 127 casetas CAPUFE</span>
       </div>
      </div>
     </CyberCard>
    )}

    <div className="flex items-center justify-between">
     <h2 className="text-xs font-black text-white">Transacciones 4 últimas</h2>
     <button className="p-1.5 bg-[#12151c] border border-slate-800 rounded-lg text-slate-400"><Filter className="w-3.5 h-3.5"/></button>
    </div>

    <CyberCard badgeText="Historial casetas" variant="default">
     <div className="space-y-2">
      {transactions.map((t,i)=>(
       <div key={i} className="flex items-center gap-3 p-3 bg-[#070709] border border-[#1a1a1a] rounded-xl hover:border-[#222] transition-colors">
        <div className="w-10 h-10 bg-[#12151c] border border-[#222] rounded-xl flex items-center justify-center text-white"><MapPin className="w-4 h-4"/></div>
        <div className="flex-1">
         <span className="text-xs font-bold text-white block">{t.caseta}</span>
         <span className="text-[10px] font-mono text-[#666] flex items-center gap-1"><Clock className="w-3 h-3"/>{t.hora} {t.tipo}</span>
        </div>
        <div className="text-right">
         <span className="text-sm font-black font-mono text-white">-${t.monto}</span>
         <span className="text-[10px] font-mono text-[#555] block">Saldo ${t.saldo}</span>
        </div>
       </div>
      ))}
     </div>
    </CyberCard>

    <CyberCard badgeText="Map casetas México" variant="glass">
     <div className="h-32 bg-[#070709] border border-[#1a1a1a] rounded-xl relative overflow-hidden flex items-center justify-center">
      <span className="text-[11px] font-mono text-[#555]">Mapa interactivo CAPUFE 127 casetas Costo ruta GDL-SIN $815</span>
      <div className="absolute top-2 left-2 bg-[#12151c] border border-[#222] px-2 py-1 rounded-full text-[9px] font-mono text-white">GDL → CUL: $815</div>
      <div className="absolute bottom-2 right-2 bg-emerald-950/50 border border-emerald-900/30 px-2 py-1 rounded-full text-[9px] font-mono text-emerald-400">Ahorro Tag 10%</div>
     </div>
    </CyberCard>
   </div>
  </div>
 );
}
