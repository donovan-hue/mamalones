import "./globals.css";
import type { Metadata, Viewport } from "next";
import { Navbar } from "@/components/Navbar";

export const metadata: Metadata = {
 title: {
  default: "MAMALONES - Kronos Fleet | Plataforma Logística",
  template: "%s | MAMALONES",
 },
 description: "Plataforma logística autónoma de Jalisco. Telemetría en tiempo real, Bóveda Escrow, Carta Porte SAT 3.1, rastreo GPS privado. Conectamos cargas con mamalones verificados.",
 keywords: ["fletes", "cargas", "transporte", "logística", "Jalisco", "torton", "trailer", "escrow", "Carta Porte", "SAT", "rastreo GPS", "mamalones"],
 authors: [{ name: "Kronos Fleet" }],
 creator: "Kronos Fleet",
 openGraph: {
  type: "website",
  locale: "es_MX",
  url: "https://mamalones.vercel.app",
  title: "MAMALONES - Fletes Verificados Jalisco",
  description: "Telemetría en tiempo real, Pago en custodia Escrow y Carta Porte SAT 3.1. La plataforma que sí paga.",
  siteName: "MAMALONES by Kronos Fleet",
 },
 twitter: {
  card: "summary_large_image",
  title: "MAMALONES - Kronos Fleet",
  description: "Control Logístico Autónomo. Encuentra fletes, publica cargas, rastreo GPS encriptado.",
 },
 robots: {
  index: true,
  follow: true,
 },
 manifest: "/manifest.json",
};

export const viewport: Viewport = {
 width: "device-width",
 initialScale: 1,
 maximumScale: 1,
 themeColor: "#000000",
};

export default function RootLayout({
 children,
}: {
 children: React.ReactNode;
}) {
 return (
  <html lang="es">
   <body className="antialiased min-h-screen bg-[#0b0c0e] text-slate-100 relative">
    <Navbar />
    <main className="pb-20">{children}</main>
   </body>
  </html>
 );
}
