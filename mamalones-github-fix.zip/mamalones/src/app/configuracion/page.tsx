"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, Building, Truck, Users, FileText, CreditCard, Settings, Save, Plus, Edit3, Trash2, Upload, CheckCircle2, MapPin, Shield } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton, PremiumInput, PremiumSelect } from "@/components/PremiumUI";

type Tab = "empresa" | "flotilla" | "choferes" | "rutas" | "docs" | "pagos";

export default function ConfigPremium() {
 const [tab, setTab] = useState<Tab>("empresa");
 const [saved, setSaved] = useState(false);
 const [empresa, setEmpresa] = useState({ razon:"Comercializadora de Granos S.A.", rfc:"CGR990101XYZ", tel:"3331234567", email:"contacto@granospacifico.mx", regimen:"601 General Ley" });

 const handleSave = () => { setSaved(true); setTimeout(()=>setSaved(false), 2500); };

 const tabs: {id: Tab, label: string, icon: any, badge?: string}[] = [
  { id:"empresa", label:"Empresa", icon:Building },
  { id:"flotilla", label:"Flotilla", icon:Truck, badge:"3" },
  { id:"choferes", label:"Choferes", icon:Users, badge:"4" },
  { id:"rutas", label:"Rutas", icon:MapPin },
  { id:"docs", label:"Documentos", icon:FileText, badge:"2!" },
  { id:"pagos", label:"Pagos", icon:CreditCard },
 ];

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4 space-y-3">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4" /></Link>
     <div>
      <h1 className="text-sm font-black text-white">CONFIGURACIÓN ERP</h1>
      <span className="text-[10px] font-mono text-[#666] uppercase">Gestión completa 6 módulos</span>
     </div>
     {saved && <div className="ml-auto flex items-center gap-1.5 px-2.5 py-1 bg-emerald-950/40 border border-emerald-900/30 rounded-full text-emerald-400 text-[11px] font-mono"><CheckCircle2 className="w-3.5 h-3.5"/> Guardado</div>}
    </div>

    <div className="flex gap-1.5 overflow-x-auto scrollbar-none pb-1">
     {tabs.map(t=>{
      const Icon=t.icon;
      const active=tab===t.id;
      return (
       <button key={t.id} onClick={()=>setTab(t.id)} className={`whitespace-nowrap flex items-center gap-1.5 px-3 py-2 rounded-full border text-xs font-mono font-bold transition-all ${active?"bg-white text-black border-white":"bg-[#0a0a0a] border-[#222] text-[#666] hover:text-white hover:border-[#333]"}`}>
        <Icon className="w-3.5 h-3.5"/>{t.label}{t.badge && <span className={`text-[9px] px-1 py-0.5 rounded-full ${active?"bg-black text-white":"bg-[#1a1a1a] text-[#888]"}`}>{t.badge}</span>}
       </button>
      );
     })}
    </div>
   </div>

   <div className="p-4 space-y-4">
    {tab==="empresa" && (
     <div className="space-y-4 animate-in fade-in">
      <CyberCard badgeText="Datos fiscales" variant="glass">
       <div className="space-y-3">
        <PremiumInput label="Razón Social" value={empresa.razon} onChange={e=>setEmpresa({...empresa,razon:e.target.value})} />
        <div className="grid grid-cols-2 gap-3">
         <PremiumInput label="RFC" value={empresa.rfc} onChange={e=>setEmpresa({...empresa,rfc:e.target.value.toUpperCase()})} />
         <PremiumInput label="Teléfono" value={empresa.tel} onChange={e=>setEmpresa({...empresa,tel:e.target.value})} />
        </div>
        <PremiumInput label="Email facturación" value={empresa.email} onChange={e=>setEmpresa({...empresa,email:e.target.value})} />
        <PremiumSelect label="Régimen Fiscal" value={empresa.regimen} onChange={e=>setEmpresa({...empresa,regimen:e.target.value})}>
         <option>601 General Ley Personas Morales</option>
         <option>612 Personas Físicas Actividad Empresarial</option>
         <option>626 RESICO</option>
        </PremiumSelect>
        <PremiumButton onClick={handleSave} variant="primary" className="w-full"><Save className="w-4 h-4"/> Guardar empresa</PremiumButton>
       </div>
      </CyberCard>
      <CyberCard badgeText="Verificación SAT / SCT">
       <div className="space-y-2 text-xs font-mono">
        <div className="flex justify-between p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl"><span className="text-[#666]">SAT e.firma</span><span className="text-emerald-400 flex items-center gap-1"><CheckCircle2 className="w-3 h-3"/> Vigente hasta 2027</span></div>
        <div className="flex justify-between p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl"><span className="text-[#666]">SCT Permiso</span><span className="text-emerald-400">T-003922 Sí</span></div>
        <div className="flex justify-between p-2.5 bg-amber-950/20 border border-amber-900/20 rounded-xl"><span className="text-[#666]">INE Representante</span><span className="text-amber-400">Renovar en 12 días</span></div>
       </div>
      </CyberCard>
     </div>
    )}

    {tab==="flotilla" && (
     <div className="space-y-3 animate-in fade-in">
      <div className="flex justify-between items-center"><h2 className="text-xs font-black text-white">FLOTILLA 3 UNIDADES</h2><button className="px-3 py-1.5 bg-white text-black rounded-full text-xs font-bold flex items-center gap-1"><Plus className="w-3 h-3"/> Agregar</button></div>
      {[
       { placas:"88-AA-3B", tipo:"Torton 3 Ejes", marca:"Kenworth T680 2022", status:"En ruta", km:"142k", chofer:"Donovan" },
       { placas:"99-BB-4C", tipo:"Rabón", marca:"Freightliner M2 2020", status:"Disponible", km:"89k", chofer:"Jesús" },
       { placas:"77-CC-2A", tipo:"Thermo 53ft", marca:"International LT 2021", status:"Taller", km:"201k", chofer:"Miguel" },
      ].map(u=>(
       <CyberCard key={u.placas} variant={u.status==="En ruta"?"emerald":"default"}>
        <div className="flex gap-3">
         <div className="w-12 h-12 bg-[#12151c] border border-[#222] rounded-xl flex items-center justify-center text-white font-black text-xs">{u.placas.slice(0,2)}</div>
         <div className="flex-1">
          <div className="flex items-center gap-2"><span className="text-xs font-bold text-white">{u.placas}</span><PremiumBadge variant={u.status==="En ruta"?"success":u.status==="Disponible"?"default":"warning"}>{u.status}</PremiumBadge></div>
          <span className="text-[11px] font-mono text-white block">{u.tipo} {u.marca}</span>
          <span className="text-[10px] font-mono text-[#666]">{u.km} km Chofer: {u.chofer}</span>
         </div>
         <div className="flex flex-col gap-1">
          <button className="p-2 bg-[#12151c] border border-slate-800 rounded-lg text-slate-400"><Edit3 className="w-3.5 h-3.5"/></button>
          <button className="p-2 bg-red-950/20 border border-red-900/20 rounded-lg text-red-400"><Trash2 className="w-3.5 h-3.5"/></button>
         </div>
        </div>
       </CyberCard>
      ))}
     </div>
    )}

    {tab==="choferes" && (
     <div className="space-y-3 animate-in fade-in">
      <div className="flex justify-between"><h2 className="text-xs font-black text-white">CHOFERES 4</h2><button className="px-3 py-1.5 bg-white text-black rounded-full text-xs font-bold flex items-center gap-1"><Plus className="w-3 h-3"/> Nuevo chofer</button></div>
      {[
       { nombre:"Donovan Ávila", lic:"FED-8839201", rating:4.9, viajes:38, status:"Verificado SCT" },
       { nombre:"Jesús M.", lic:"FED-7728102", rating:4.7, viajes:22, status:"Verificado" },
       { nombre:"Miguel R.", lic:"FED-6639204", rating:4.5, viajes:15, status:"Docs por vencer" },
      ].map(c=>(
       <CyberCard key={c.lic} variant="default">
        <div className="flex gap-3 items-center">
         <div className="w-10 h-10 bg-[#1a1a1a] border border-[#222] rounded-full flex items-center justify-center font-bold text-white">{c.nombre.split(" ").map(n=>n[0]).join("").slice(0,2)}</div>
         <div className="flex-1">
          <span className="text-xs font-bold text-white block">{c.nombre} <span className="text-amber-400 text-[10px]">  {c.rating}</span></span>
          <span className="text-[10px] font-mono text-[#666]">{c.lic} {c.viajes} viajes {c.status}</span>
         </div>
         <Shield className="w-4 h-4 text-emerald-400" />
        </div>
       </CyberCard>
      ))}
     </div>
    )}

    {tab==="docs" && (
     <div className="space-y-3 animate-in fade-in">
      <CyberCard badgeText="Gestor documental drag & drop" variant="glass">
       <div className="border-2 border-dashed border-[#333] hover:border-[#666] rounded-xl p-8 text-center bg-[#0a0a0a] cursor-pointer">
        <Upload className="w-8 h-8 text-[#555] mx-auto mb-2" />
        <p className="text-xs font-bold text-white">Arrastra facturas, INE, pólizas</p>
        <p className="text-[10px] font-mono text-[#666]">PDF, JPG, PNG Máx 20MB</p>
       </div>
       <div className="space-y-2 mt-3">
        {[{name:"Poliza GNP-883920-A.pdf", size:"2.4MB", status:"Verificado"},{name:"INE Donovan frontal.jpg", size:"1.2MB", status:"Pendiente"}, {name:"Licencia Federal FED-883.pdf", size:"800KB", status:"Vence 12 días"}].map(f=>(
         <div key={f.name} className="flex items-center gap-2 p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl">
          <FileText className="w-4 h-4 text-[#666]" />
          <div className="flex-1 min-w-0"><span className="text-[11px] font-mono text-white block truncate">{f.name}</span><span className="text-[9px] font-mono text-[#666]">{f.size} {f.status}</span></div>
          <PremiumBadge variant={f.status==="Verificado"?"success":f.status.includes("Vence")?"warning":"default"}>{f.status}</PremiumBadge>
         </div>
        ))}
       </div>
      </CyberCard>
     </div>
    )}

    {(tab==="rutas" || tab==="pagos") && (
     <div className="space-y-3 animate-in fade-in">
      <CyberCard badgeText={tab==="rutas"?"Rutas favoritas guardadas":"Historial pagos escrow"}>
       <div className="py-8 text-center">
        <div className="w-12 h-12 bg-[#12151c] border border-[#222] rounded-xl mx-auto flex items-center justify-center mb-3"><Settings className="w-6 h-6 text-[#444]" /></div>
        <p className="text-sm font-bold text-white">Módulo premium en construcción</p>
        <p className="text-xs font-mono text-[#666] mt-1">Guardaremos tus rutas GDL-CUL favoritas y historial completo de pagos con facturas automáticas</p>
        <PremiumButton variant="secondary" size="sm" className="mt-3">Próximamente Q4 2026</PremiumButton>
       </div>
      </CyberCard>
     </div>
    )}
   </div>
  </div>
 );
}
