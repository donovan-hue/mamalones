"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, MapPin, Package, ShieldCheck, CheckCircle2, DollarSign, Truck, Clock, FileText, Camera, Calculator, Info, ChevronRight, ChevronLeft, Navigation, Shield, HardHat, AlertCircle } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton, PremiumInput, PremiumSelect } from "@/components/PremiumUI";
import { EscrowFlow, CargoInsuranceCard } from "@/components/Security";
import { calcularDistancia, calcularPrecioSugerido, PRODUCTOS_GRANOS } from "@/lib/types";
import { supabase, isDemoMode } from "@/lib/supabase";

const STEPS = [
 { id: 1, title: "Mercancía", icon: Package, desc: "Material y peso" },
 { id: 2, title: "Ruta Exacta", icon: Navigation, desc: "Puntos carga/descarga" },
 { id: 3, title: "Unidad & EPP", icon: HardHat, desc: "Tipo camión y protección" },
 { id: 4, title: "Tarifa & Escrow", icon: DollarSign, desc: "Precio y custodia" },
 { id: 5, title: "Confirmar", icon: CheckCircle2, desc: "Preview publico" },
];

const UNIDADES = [
 "Torton Cajas Secas 3 ejes",
 "Torton Rabón Heavy Duty",
 "Trailer 53ft Caja Seca",
 "Trailer Thermo 53ft Refrigerado",
 "Tolva 35m3 Granelera",
 "Plataforma 40ft",
 "Volteo 14m3",
 "Lowboy Cama Baja",
];

const EPP_OPTIONS = [
 "Casco y chaleco básico",
 "Overol + botas + casco",
 "EPP completo químico",
 "Sin EPP especial",
];

export default function PublicarCargaMamalonesMateriaPrima() {
 const [step, setStep] = useState(1);
 const [loading, setLoading] = useState(false);
 const [exito, setExito] = useState(false);

 // Paso 1: Mercancía
 const [tipoProducto, setTipoProducto] = useState("trigo");
 const [productoDetalle, setProductoDetalle] = useState("");
 const [pesoTon, setPesoTon] = useState("");
 const [volumenM3, setVolumenM3] = useState("");
 const [valorMercancia, setValorMercancia] = useState("");

 // Paso 2: Ruta exacta
 const [origen, setOrigen] = useState("");
 const [origenExacto, setOrigenExacto] = useState("");
 const [destino, setDestino] = useState("");
 const [destinoExacto, setDestinoExacto] = useState("");
 const [fechaRecogida, setFechaRecogida] = useState("");
 const [fechaEntregaLimite, setFechaEntregaLimite] = useState("");
 const [urgencia, setUrgencia] = useState<"normal" | "urgente" | "express">("normal");
 const [paradas, setParadas] = useState<string[]>([]);

 // Paso 3: Unidad y EPP
 const [unidadRequerida, setUnidadRequerida] = useState(UNIDADES[0]);
 const [epp, setEpp] = useState(EPP_OPTIONS[0]);
 const [requiereManiobras, setRequiereManiobras] = useState(false);
 const [descripcion, setDescripcion] = useState("");

 // Paso 4: Tarifa y seguridad
 const [montoOfrecido, setMontoOfrecido] = useState("");
 const [permitirContraofertas, setPermitirContraofertas] = useState(true);
 const [escrow, setEscrow] = useState(true);
 const [seguro, setSeguro] = useState(true);

 const distanciaKm = calcularDistancia(origen, destino);
 const precioSugerido = calcularPrecioSugerido(parseFloat(pesoTon || "0"), distanciaKm, tipoProducto);
 const comision = montoOfrecido ? (parseFloat(montoOfrecido) * 0.03).toFixed(0) : "0";
 const seguroCosto = seguro && pesoTon ? (parseFloat(pesoTon) * 7500 * 0.025).toFixed(0) : "0";

 const handleSubmit = async () => {
  setLoading(true);
  try {
   // Guardar local para demo
   const carga = {
    id: `carga-${Date.now()}`,
    origen, destino, origenExacto, destinoExacto,
    distanciaKm,
    producto: `${pesoTon}T ${PRODUCTOS_GRANOS.find(p=>p.value===tipoProducto)?.label} ${productoDetalle}`,
    tipoProducto, pesoTon, volumenM3,
    unidadRequerida, epp, montoOfrecido, permitirContraofertas, escrow, seguro,
    urgencia, fechaRecogida, fechaEntregaLimite,
    createdAt: new Date().toISOString(),
    estatus: "buscando",
   };
   const existing = JSON.parse(localStorage.getItem("mis_cargas_cliente") || "[]");
   localStorage.setItem("mis_cargas_cliente", JSON.stringify([carga, ...existing]));

   if (supabase && !isDemoMode) {
    await supabase.from("cargas").insert([{
     origen, destino, monto: parseFloat(montoOfrecido), producto: carga.producto,
     unidad_requerida: unidadRequerida, escrow_activo: escrow, estatus: "buscando",
    }]);
   }
   
   await new Promise(r=>setTimeout(r,1200));
   setExito(true);
  } catch (e:any) {
   alert("Error: "+e.message);
  } finally {
   setLoading(false);
  }
 };

 if (exito) {
  return (
   <div className="min-h-screen text-slate-100 p-4 max-w-md mx-auto flex flex-col justify-center pb-20">
    <CyberCard variant="emerald" badgeText="¡Carga Publicada en Bolsa!">
     <div className="text-center py-6 space-y-4">
      <div className="w-20 h-20 bg-emerald-500 rounded-full mx-auto flex items-center justify-center animate-bounce">
       <CheckCircle2 className="w-10 h-10 text-black" />
      </div>
      <h2 className="text-xl font-black text-white">¡En bolsa de carga!</h2>
      <p className="text-xs font-mono text-[#aaa] max-w-[300px] mx-auto leading-relaxed">Tu carga de <strong className="text-white">{pesoTon}T {tipoProducto}</strong> de <strong className="text-white">{origen} → {destino}</strong> ya la ven {Math.floor(Math.random()*40)+20} mamalones verificados cerca. {permitirContraofertas? "Te llegarán contraofertas en minutos." : "Tomarán tu tarifa fija."}</p>
      
      <EscrowFlow amount={parseFloat(montoOfrecido || "0")} status="depositado" />

      <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-3 text-left text-xs font-mono space-y-1.5">
       <div className="flex justify-between"><span className="text-[#666]">Ruta exacta</span><span className="text-white font-bold text-[10px]">{origenExacto.slice(0,20)} → {destinoExacto.slice(0,20)}</span></div>
       <div className="flex justify-between"><span className="text-[#666]">Tarifa ofrecida</span><span className="text-emerald-400 font-black">{montoOfrecido? `$${parseFloat(montoOfrecido).toLocaleString()} MXN` : "$0"} {permitirContraofertas && "(acepta contraofertas)"}</span></div>
       <div className="flex justify-between"><span className="text-[#666]">Distancia</span><span className="text-white">{distanciaKm} km {precioSugerido.porKm}/km</span></div>
       <div className="flex justify-between"><span className="text-[#666]">Unidad</span><span className="text-white">{unidadRequerida.split(" ")[0]} {epp}</span></div>
      </div>

      <div className="grid grid-cols-2 gap-2">
       <Link href="/mis-cargas" className="py-3 bg-white text-black font-black rounded-xl text-xs text-center">Ver mis cargas + ofertas</Link>
       <button onClick={()=>{setExito(false); setStep(1);}} className="py-3 bg-[#12151c] border border-slate-800 text-white font-bold rounded-xl text-xs">Publicar otra</button>
      </div>
     </div>
    </CyberCard>
   </div>
  );
 }

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4 space-y-3">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4" /></Link>
     <div>
      <h1 className="text-sm font-black tracking-tight text-white">PUBLICAR CARGA MAMALONES MATERIA PRIMA</h1>
      <span className="text-[10px] font-mono text-[#666] uppercase">Paso {step} de 5 Cliente {isDemoMode && "DEMO"}</span>
     </div>
    </div>

    <div className="flex gap-1.5 overflow-x-auto scrollbar-none">
     {STEPS.map(s=>{
      const Icon=s.icon;
      const active=step===s.id;
      const past=step>s.id;
      return (
       <div key={s.id} className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full border text-[10px] font-mono font-bold whitespace-nowrap transition-all ${active?"bg-white text-black border-white": past?"bg-emerald-950/40 border-emerald-900/30 text-emerald-400":"bg-[#0a0a0a] border-[#222] text-[#555]"}`}>
        <Icon className="w-3 h-3" />{s.title}
        {past && <CheckCircle2 className="w-3 h-3" />}
       </div>
      );
     })}
    </div>
    <div className="w-full bg-[#1a1a1a] h-1.5 rounded-full overflow-hidden"><div className="h-full bg-white transition-all duration-500" style={{width:`${(step/5)*100}%`}} /></div>
   </div>

   <div className="p-4 space-y-4">
    {step===1 && (
     <div className="space-y-4 animate-in fade-in">
      <CyberCard badgeText="Paso 1 Datos de mercancía (tipo, volumen, peso)" variant="glass">
       <div className="space-y-4">
        <PremiumSelect label="Tipo de material / Producto *" value={tipoProducto} onChange={e=>setTipoProducto(e.target.value)}>
         {PRODUCTOS_GRANOS.map(p=><option key={p.value} value={p.value}>{p.label} Clave SAT {p.claveSAT}</option>)}
        </PremiumSelect>

        <PremiumInput label="Detalle producto (ej. Trigo panificable 12% proteína)" icon={<Package className="w-4 h-4"/>} placeholder="Especifica calidad, humedad, etc." value={productoDetalle} onChange={e=>setProductoDetalle(e.target.value)} />

        <div className="grid grid-cols-2 gap-3">
         <PremiumInput label="Peso toneladas *" type="number" placeholder="9.5" value={pesoTon} onChange={e=>setPesoTon(e.target.value)} icon={<span className="text-[10px]">T</span>} />
         <PremiumInput label="Volumen M3 (opcional)" type="number" placeholder="35" value={volumenM3} onChange={e=>setVolumenM3(e.target.value)} icon={<span className="text-[10px]">m³</span>} />
        </div>

        <PremiumInput label="Valor mercancía MXN (para seguro)" type="number" placeholder="120000" value={valorMercancia} onChange={e=>setValorMercancia(e.target.value)} icon={<DollarSign className="w-4 h-4"/>} />

        <div className="bg-amber-950/20 border border-amber-900/30 rounded-xl p-3 flex gap-2">
         <Info className="w-4 h-4 text-amber-400 shrink-0" />
         <span className="text-[11px] font-mono text-amber-200/80">Para transporte de materia prima se requiere peso exacto para calcular precio por tonelada y costo de seguro.</span>
        </div>
       </div>
      </CyberCard>
     </div>
    )}

    {step===2 && (
     <div className="space-y-4 animate-in fade-in">
      <CyberCard badgeText="Paso 2 Ruta exacta con puntos de carga/descarga" variant="glass">
       <div className="space-y-4">
        <PremiumInput label="Ciudad Origen *" icon={<MapPin className="w-4 h-4"/>} placeholder="Tlaquepaque, JAL" value={origen} onChange={e=>setOrigen(e.target.value)} />
        <PremiumInput label="Punto exacto carga * (bodega, rampa, coordenadas)" icon={<Navigation className="w-4 h-4"/>} placeholder="Bodega Granos de Occidente, Calle 8 #142, Loma Dorada. Lat: 20.60, Lng: -103.31" value={origenExacto} onChange={e=>setOrigenExacto(e.target.value)} />

        <PremiumInput label="Ciudad Destino *" icon={<MapPin className="w-4 h-4"/>} placeholder="Culiacán, SIN" value={destino} onChange={e=>setDestino(e.target.value)} />
        <PremiumInput label="Punto exacto descarga * (bodega destino)" icon={<Navigation className="w-4 h-4"/>} placeholder="Bodega Cliente Sinaloa, Km 12 Carretera a Navolato. Lat: 24.80, Lng: -107.39" value={destinoExacto} onChange={e=>setDestinoExacto(e.target.value)} />

        {origen && destino && (
         <div className="bg-[#070709] border border-[#1e1e1e] rounded-xl p-3 space-y-2">
          <div className="flex justify-between text-xs font-mono"><span className="text-[#666]">Distancia calculada</span><span className="text-white font-black">{distanciaKm} km</span></div>
          <div className="flex justify-between text-xs font-mono"><span className="text-[#666]">Casetas estimadas</span><span className="text-white">${Math.round(distanciaKm*1.15).toLocaleString()} MXN</span></div>
          <div className="flex justify-between text-xs font-mono"><span className="text-[#666]">Tiempo tránsito</span><span className="text-emerald-400 font-bold">{(distanciaKm/68).toFixed(1)}h a 68 km/h prom</span></div>
         </div>
        )}

        <div className="grid grid-cols-2 gap-3">
         <PremiumInput label="Fecha recogida *" type="datetime-local" value={fechaRecogida} onChange={e=>setFechaRecogida(e.target.value)} icon={<Clock className="w-4 h-4"/>} />
         <PremiumInput label="Fecha entrega límite *" type="datetime-local" value={fechaEntregaLimite} onChange={e=>setFechaEntregaLimite(e.target.value)} icon={<Clock className="w-4 h-4"/>} />
        </div>

        <PremiumSelect label="Urgencia" value={urgencia} onChange={e=>setUrgencia(e.target.value as any)}>
         <option value="normal">Normal 24-48h para recoger</option>
         <option value="urgente">Urgente Hoy mismo </option>
         <option value="express">Express En 2 horas </option>
        </PremiumSelect>

        <div className="space-y-2">
         <label className="text-[10px] font-mono font-bold text-[#666] uppercase">Paradas intermedias</label>
         {paradas.map((p,i)=>(
          <div key={i} className="flex gap-2"><input value={p} onChange={e=>{const n=[...paradas]; n[i]=e.target.value; setParadas(n);}} className="flex-1 bg-[#0a0b0d] border border-slate-800 rounded-xl p-2.5 text-xs font-mono text-white outline-none" placeholder="Descarga parcial Mazatlán 3T" /><button onClick={()=>setParadas(paradas.filter((_,idx)=>idx!==i))} className="p-2.5 bg-red-950/30 border border-red-900/30 rounded-xl text-red-400">No</button></div>
         ))}
         <button onClick={()=>setParadas([...paradas,""])} className="w-full py-2 border border-dashed border-[#333] rounded-xl text-xs font-mono text-[#666] hover:text-white">+ Parada intermedia</button>
        </div>
       </div>
      </CyberCard>
     </div>
    )}

    {step===3 && (
     <div className="space-y-4 animate-in fade-in">
      <CyberCard badgeText="Paso 3 Unidad requerida y EPP" variant="glass">
       <div className="space-y-4">
        <PremiumSelect label="Tipo unidad requerida *" value={unidadRequerida} onChange={e=>setUnidadRequerida(e.target.value)}>
         {UNIDADES.map(u=><option key={u} value={u}>{u}</option>)}
        </PremiumSelect>

        <PremiumSelect label="Equipo de protección EPP requerido" value={epp} onChange={e=>setEpp(e.target.value)}>
         {EPP_OPTIONS.map(o=><option key={o} value={o}>{o}</option>)}
        </PremiumSelect>

        <div className="flex items-center justify-between p-3 bg-[#0a0a0a] border border-[#222] rounded-xl">
         <div className="flex items-center gap-2"><HardHat className="w-4 h-4 text-[#666]"/><div><p className="text-xs font-bold text-white">Requiere maniobras / Montacargas</p><p className="text-[10px] font-mono text-[#666]">Carga/descarga con equipo especial</p></div></div>
         <label className="relative inline-flex items-center cursor-pointer"><input type="checkbox" checked={requiereManiobras} onChange={e=>setRequiereManiobras(e.target.checked)} className="sr-only peer"/><div className="w-11 h-6 bg-[#222] rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-white"></div></label>
        </div>

        <div className="space-y-1.5">
         <label className="text-[10px] font-mono font-bold text-[#666] uppercase">Descripción + requerimientos especiales</label>
         <textarea value={descripcion} onChange={e=>setDescripcion(e.target.value)} placeholder="Ej. Producto a granel, no mojar, requiere lonas, horario carga 8am-4pm, contacto bodega Juan 333..., etc." className="w-full bg-[#0a0b0d] border border-slate-800 rounded-xl p-3 text-xs font-mono text-white outline-none min-h-[80px] placeholder:text-[#555]" />
        </div>

        <div className="border-2 border-dashed border-[#222] rounded-xl p-4 text-center bg-[#0a0a0a] hover:border-[#444] cursor-pointer">
         <Camera className="w-6 h-6 text-[#444] mx-auto mb-1.5" />
         <p className="text-xs font-bold text-white">Fotos mercancía para transportista (opcional)</p>
         <p className="text-[10px] font-mono text-[#666]">Ayuda a que valoren mejor el flete</p>
        </div>
       </div>
      </CyberCard>
     </div>
    )}

    {step===4 && (
     <div className="space-y-4 animate-in fade-in">
      <CyberCard badgeText="Paso 4 Tarifa cliente y protección pago" variant="glass">
       <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
         <PremiumInput label="Tarifa ofrecida MXN *" icon={<DollarSign className="w-4 h-4"/>} placeholder="38500" value={montoOfrecido} onChange={e=>setMontoOfrecido(e.target.value)} type="number" />
         <div className="space-y-1.5">
          <label className="text-[10px] font-mono font-bold text-[#666] uppercase">Precio por km / ton</label>
          <div className="bg-[#070709] border border-[#1e1e1e] rounded-xl p-2.5 text-xs font-mono">
           <div className="text-white font-black">${precioSugerido.porKm}/km ${(parseFloat(montoOfrecido || "0")/(parseFloat(pesoTon|| "1"))).toFixed(0)}/ton</div>
           <div className="text-[10px] text-[#666]">Sugerido: ${precioSugerido.optimo.toLocaleString()}</div>
          </div>
         </div>
        </div>

        <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-3 space-y-2">
         <div className="flex gap-2">
          <button onClick={()=>setMontoOfrecido(precioSugerido.min.toString())} className="flex-1 py-2 bg-[#12151c] border border-slate-800 rounded-lg text-[10px] font-mono text-slate-300">${precioSugerido.min.toLocaleString()} bajo</button>
          <button onClick={()=>setMontoOfrecido(precioSugerido.optimo.toString())} className="flex-1 py-2 bg-white text-black rounded-lg text-[10px] font-mono font-bold">${precioSugerido.optimo.toLocaleString()} óptimo</button>
          <button onClick={()=>setMontoOfrecido(precioSugerido.max.toString())} className="flex-1 py-2 bg-[#12151c] border border-slate-800 rounded-lg text-[10px] font-mono text-slate-300">${precioSugerido.max.toLocaleString()} alto</button>
         </div>
         <p className="text-[10px] font-mono text-[#555] text-center">💡 {permitirContraofertas ? "Al permitir contraofertas recibes ofertas más rápido" : "Tarifa fija = transportistas aceptan directo si les conviene"}</p>
        </div>

        <div className="space-y-3">
         <div className="flex items-center justify-between p-3 bg-[#0a0a0a] border border-[#222] rounded-xl">
          <div className="flex items-center gap-2"><Calculator className="w-4 h-4 text-[#666]"/><div><p className="text-xs font-bold text-white">Permitir contraofertas transportistas</p><p className="text-[10px] font-mono text-[#666]">Deja que oferten su precio basado en su unidad/distancia</p></div></div>
          <label className="relative inline-flex items-center cursor-pointer"><input type="checkbox" checked={permitirContraofertas} onChange={e=>setPermitirContraofertas(e.target.checked)} className="sr-only peer"/><div className="w-11 h-6 bg-[#222] rounded-full peer peer-checked:after:translate-x-full after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-white"></div></label>
         </div>

         <EscrowFlow amount={parseFloat(montoOfrecido || "0")} status="depositado" />

         <div className="flex items-center justify-between p-3 bg-emerald-950/20 border border-emerald-900/30 rounded-xl">
          <div className="flex items-center gap-2"><ShieldCheck className="w-5 h-5 text-emerald-400"/><div><p className="text-xs font-bold text-white">Pago en Custodia Escrow</p><p className="text-[10px] font-mono text-[#aaa]">Depositas antes de cargar, se libera al entregar evidencia</p></div></div>
          <label className="relative inline-flex items-center cursor-pointer"><input type="checkbox" checked={escrow} onChange={e=>setEscrow(e.target.checked)} className="sr-only peer"/><div className="w-11 h-6 bg-[#222] rounded-full peer peer-checked:after:translate-x-full after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div></label>
         </div>

         <CargoInsuranceCard pesoTon={parseFloat(pesoTon || "0")} activo={seguro} onToggle={setSeguro} />
        </div>
       </div>
      </CyberCard>
     </div>
    )}

    {step===5 && (
     <div className="space-y-4 animate-in fade-in">
      <CyberCard badgeText="Preview - Así lo ven los transportistas" variant="glow">
       <div className="bg-[#070709] border border-[#1e1e1e] rounded-xl p-3 space-y-3">
        <div className="flex justify-between items-start">
         <div><div className="flex items-center gap-1.5 text-xs font-bold text-white"><MapPin className="w-3.5 h-3.5 text-[#666]"/>{origen||"Origen"} → {destino||"Destino"} {distanciaKm}km</div><span className="text-[10px] font-mono text-[#666]">{fechaRecogida||"Fecha flex"} {pesoTon||"0"}T {tipoProducto} {urgencia}</span></div>
         <span className="text-sm font-black font-mono text-white">${montoOfrecido? parseFloat(montoOfrecido).toLocaleString(): "0"} {permitirContraofertas?" Ofertable":" Fija"}</span>
        </div>
        <div className="text-[11px] font-mono text-[#aaa] bg-[#0a0a0a] border border-[#1a1a1a] rounded-lg p-2">
         {pesoTon}T {PRODUCTOS_GRANOS.find(p=>p.value===tipoProducto)?.label} {productoDetalle} {unidadRequerida} EPP {epp} {requiereManiobras && " Requiere maniobras"}<br/>
         Origen exacto: {origenExacto}<br/>Destino exacto: {destinoExacto}
        </div>
        <div className="flex gap-1.5 flex-wrap">
         {escrow && <PremiumBadge variant="success">Escrow ${montoOfrecido}</PremiumBadge>}
         {seguro && <PremiumBadge variant="success">Asegurado ${seguroCosto}</PremiumBadge>}
         {permitirContraofertas ? <PremiumBadge variant="default">Acepta contraofertas</PremiumBadge> : <PremiumBadge variant="default">Tarifa fija</PremiumBadge>}
         <PremiumBadge variant={urgencia==="normal"?"default":urgencia==="urgente"?"warning":"danger"}>{urgencia.toUpperCase()}</PremiumBadge>
        </div>
       </div>
      </CyberCard>

      <CyberCard badgeText="Resumen económico cliente" variant="glass">
       <div className="space-y-2 text-xs font-mono">
        <div className="flex justify-between"><span className="text-[#666]">Tarifa que ofreces</span><span className="text-white font-bold">${montoOfrecido||0} MXN</span></div>
        <div className="flex justify-between"><span className="text-[#666]">Comisión Mamalones 3%</span><span className="text-amber-400">-${comision}</span></div>
        <div className="flex justify-between"><span className="text-[#666]">Seguro {seguro?`(2.5% $${seguroCosto})`:"(no)"}</span><span className={seguro?"text-[#aaa]":"text-[#444]"}>{seguro?`-$${seguroCosto}`:"$0"}</span></div>
        <div className="flex justify-between border-t border-[#222] pt-2 font-black"><span className="text-white">Total a depositar en escrow</span><span className="text-emerald-400 text-sm">${(parseFloat(montoOfrecido||"0")+parseFloat(seguroCosto)).toLocaleString()} MXN</span></div>
        <div className="flex justify-between text-[10px]"><span className="text-[#555]">${precioSugerido.porKm}/km {pesoTon}T Pago liberado al entregar con ticket báscula + firma</span><span className="text-emerald-400">Sí Protegido</span></div>
       </div>
      </CyberCard>

      <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-3 flex gap-2.5">
       <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
       <span className="text-[11px] font-mono text-[#888] leading-relaxed"><strong className="text-white">Seguridad cliente:</strong> Validación estricta operadores (licencia, CURP, antecedentes, póliza), escrow retenido, seguro por tonelada, seguimiento GPS con alertas desvíos.</span>
      </div>
     </div>
    )}

    <div className="flex gap-2 pt-2">
     {step>1 && <button onClick={()=>setStep(step-1)} className="flex-1 py-3 bg-[#12151c] border border-slate-800 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2"><ChevronLeft className="w-4 h-4"/> Atrás</button>}
     {step<5 ? (
      <button onClick={()=>setStep(step+1)} disabled={(step===1 && (!pesoTon||!origen)) || (step===2 && (!origenExacto||!destinoExacto))} className="flex-[2] py-3 bg-white text-black font-black rounded-xl text-xs flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-zinc-100">Siguiente <ChevronRight className="w-4 h-4"/></button>
     ) : (
      <PremiumButton onClick={handleSubmit} variant="primary" size="lg" className="flex-[2]" disabled={loading}>
       {loading ? "Publicando en bolsa..." : "Publicar en bolsa Depositar escrow"}
      </PremiumButton>
     )}
    </div>

    <p className="text-[9px] font-mono text-center text-[#444]">Paso {step} de 5 Guardado automático Encriptado AES-256 Validación SCT</p>
   </div>
  </div>
 );
}
