"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowLeft, MapPin, Clock, CheckCircle2, Camera, Navigation, AlertTriangle } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton, EmptyState } from "@/components/PremiumUI";
import { EscrowFlow, PanicButton, RouteAlert } from "@/components/Security";

export default function MisViajesTransportista() {
 const [viajes, setViajes] = useState<any[]>([]);
 const [selected, setSelected] = useState<any>(null);

 useEffect(()=>{
  const ofertas = JSON.parse(localStorage.getItem("mis_ofertas_transportista") || "[]");
  setViajes(ofertas);
 },[]);

 const iniciarCheckIn = (viaje:any)=>{
  alert(` Check-in digital: Foto ticket báscula inicial para activar GPS\n Viaje ${viaje.cargaId}\n ${viaje.etaRecogida}\nLuego de foto, tracking inicia automático`);
  window.location.href = `/check-in/${viaje.cargaId}`;
 };

 if (viajes.length===0) {
  return (
   <div className="min-h-screen max-w-md mx-auto p-4 pb-28">
    <div className="flex items-center gap-3 border-b border-[#1a1a1a] pb-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4 text-white"/></Link>
     <div><h1 className="text-sm font-black text-white">MIS VIAJES TRANSPORTISTA</h1><span className="text-[10px] font-mono text-[#666]">Ofertas enviadas, viajes asignados, en tránsito</span></div>
    </div>
    <div className="pt-8"><EmptyState title="Aún no has ofertado" description="Explora bolsa de carga, envía contraoferta con tu unidad, placas, chofer, ETA recogida/entrega" action={<Link href="/cargas" className="mt-2 inline-block px-4 py-2 bg-white text-black font-bold rounded-xl text-xs">Ver bolsa de carga</Link>} /></div>
   </div>
  );
 }

 return (
  <div className="min-h-screen max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4 text-white"/></Link>
     <div><h1 className="text-sm font-black text-white">MIS VIAJES {viajes.length} OFERTAS</h1><span className="text-[10px] font-mono text-[#666]">Transportista Unidades, choferes, ETAs</span></div>
     <PremiumBadge variant="live">{viajes.filter(v=>v.status==="pendiente").length} pendientes</PremiumBadge>
    </div>
   </div>

   <div className="p-4 space-y-4">
    <div className="grid grid-cols-3 gap-2">
     <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-2.5 text-center"><span className="text-[9px] font-mono text-[#666] uppercase block">Ofertas</span><span className="text-sm font-black text-white">{viajes.length}</span></div>
     <div className="bg-emerald-950/20 border border-emerald-900/30 rounded-xl p-2.5 text-center"><span className="text-[9px] font-mono text-emerald-400 uppercase block">Aceptadas</span><span className="text-sm font-black text-emerald-400">{viajes.filter(v=>v.status==="aceptada").length}</span></div>
     <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-2.5 text-center"><span className="text-[9px] font-mono text-[#666] uppercase block">Garantizado</span><span className="text-sm font-black text-white">$85k</span></div>
    </div>

    {viajes.map(viaje=>(
     <CyberCard key={viaje.id} variant={viaje.status==="aceptada"?"emerald":viaje.status==="pendiente"?"glow":"default"} badgeText={`${viaje.status.toUpperCase()} ID ${viaje.cargaId.slice(-4)} ${viaje.precio?.toLocaleString()} MXN`}>
      <div className="space-y-3">
       <div className="flex justify-between items-start">
        <div><div className="text-xs font-bold text-white">{viaje.cargaId}</div><span className="text-[10px] font-mono text-[#666]">Unidad {viaje.unidad} Chofer {viaje.chofer?.split("")[0]}</span><div className="flex gap-2 mt-1 text-[10px] font-mono text-[#888]"><span className="flex items-center gap-1"><Clock className="w-3 h-3"/>Recogida {viaje.etaRecogida}</span><span>→ Entrega {viaje.etaEntrega}</span></div></div>
        <div className="text-right"><span className="text-sm font-black font-mono text-white">${viaje.precio?.toLocaleString()}</span><span className="text-[10px] font-mono text-[#666] block">{viaje.comentario?.slice(0,20) || "Sin comentario"}</span></div>
       </div>

       {viaje.status==="aceptada" && (
        <div className="space-y-2">
         <EscrowFlow amount={viaje.precio} status="retenido" />
         <PanicButton />
         <RouteAlert type="zona_riesgo" />
        </div>
       )}

       <div className="flex gap-2">
        {viaje.status==="pendiente" ? (
         <>
          <span className="flex-1 py-2.5 bg-[#0a0a0a] border border-[#222] rounded-xl text-xs font-mono text-[#888] text-center">⏳ Esperando cliente 4.9  te ayuda</span>
          <button onClick={()=>{const nv=viajes.filter(v=>v.id!==viaje.id); setViajes(nv); localStorage.setItem("mis_ofertas_transportista", JSON.stringify(nv));}} className="px-3 py-2.5 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white">Cancelar</button>
         </>
        ) : viaje.status==="aceptada" ? (
         <>
          <PremiumButton onClick={()=>iniciarCheckIn(viaje)} variant="success" size="sm" className="flex-1"><Camera className="w-4 h-4"/> Check-in ticket báscula Activar GPS</PremiumButton>
          <Link href="/rastreo" className="px-3 py-2.5 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white flex items-center gap-1"><Navigation className="w-4 h-4"/> Rastreo</Link>
         </>
        ) : (
         <span className="flex-1 py-2.5 bg-[#0a0a0a] border border-[#222] rounded-xl text-xs font-mono text-[#666] text-center">Viaje {viaje.status}</span>
        )}
       </div>
      </div>
     </CyberCard>
    ))}

    <CyberCard badgeText="Garantía de pago transportista">
     <div className="flex gap-3 p-2.5 bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl">
      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
      <div><p className="text-xs font-bold text-white">Cero riesgo cobranza tardía</p><p className="text-[11px] font-mono text-[#888] leading-relaxed">Fondos escrow se liberan digital inmediato al cerrar viaje con ticket báscula destino + firma cliente + foto evidencia. Verificación empresa: historial 4.9 , solvencia $1.2M, 0 fraudes.</p></div>
     </div>
    </CyberCard>
   </div>

   {selected && (
    <div className="fixed inset-0 z-[70] bg-black/90 max-w-md mx-auto p-4 flex flex-col"><div className="bg-[#0e0e10] border border-[#222] rounded-2xl p-4">Detalle viaje {selected.id}</div></div>
   )}
  </div>
 );
}
