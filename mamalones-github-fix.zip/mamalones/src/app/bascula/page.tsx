"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowLeft, Fuel, Weight, Camera, FileText, TrendingUp, AlertTriangle, Save, Upload } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton, PremiumInput } from "@/components/PremiumUI";

export default function BasculaPremium() {
 const [pesoBruto, setPesoBruto] = useState<number | "">("");
 const [pesoTara, setPesoTara] = useState<number | "">("");
 const [litros, setLitros] = useState<number | "">("");
 const [historial, setHistorial] = useState<any[]>([]);

 const neto = typeof pesoBruto==="number" && typeof pesoTara==="number" ? pesoBruto - pesoTara : 0;
 const merma = typeof litros==="number" ? (litros*0.835).toFixed(1) : "0.0";
 const rendimiento = typeof litros==="number" && litros>0 ? (neto / litros / 1000).toFixed(2) : "0";

 useEffect(()=>{
  const h = localStorage.getItem("bascula_historial");
  if (h) setHistorial(JSON.parse(h));
 },[]);

 const guardar = () => {
  const entry = { id:Date.now(), bruto:pesoBruto, tara:pesoTara, neto, diesel:litros, merma, fecha:new Date().toISOString() };
  const nuevo=[entry,...historial].slice(0,20);
  setHistorial(nuevo);
  localStorage.setItem("bascula_historial",JSON.stringify(nuevo));
  setPesoBruto(""); setPesoTara(""); setLitros("");
 };

 const limiteSCT = 32000;
 const sobrepeso = neto > limiteSCT;

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4"/></Link>
     <div><h1 className="text-sm font-black text-white">BÁSCULA & DIÉSEL PRO</h1><span className="text-[10px] font-mono text-[#666] uppercase">Control técnico + OCR tickets</span></div>
     <PremiumBadge variant={sobrepeso?"danger":"success"}>{sobrepeso?"¡Sobrepeso!":"OK SCT"}</PremiumBadge>
    </div>
   </div>

   <div className="p-4 space-y-4">
    {sobrepeso && (
     <div className="bg-red-950/30 border border-red-900/30 rounded-xl p-3 flex gap-2.5">
      <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
      <div><p className="text-xs font-bold text-red-300">Alerta SCT: {neto.toLocaleString()}kg excede límite {limiteSCT.toLocaleString()}kg</p><p className="text-[11px] font-mono text-red-300/70">Multa estimada $8,500 Descarga 500kg o divide carga</p></div>
     </div>
    )}

    <CyberCard badgeText="Pesaje móvil premium" variant={sobrepeso?"danger":"glass"}>
     <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
       <PremiumInput label="Peso Bruto KG *" icon={<Weight className="w-4 h-4"/>} type="number" placeholder="38000" value={pesoBruto} onChange={e=>setPesoBruto(e.target.value===""?"":Number(e.target.value))} />
       <PremiumInput label="Peso Tara KG *" icon={<Weight className="w-4 h-4"/>} type="number" placeholder="10000" value={pesoTara} onChange={e=>setPesoTara(e.target.value===""?"":Number(e.target.value))} />
      </div>

      <div className="bg-[#070709] border border-[#1e1e1e] rounded-xl p-4 text-center space-y-1">
       <span className="text-[10px] font-mono uppercase tracking-widest text-[#666]">Peso neto cargado calculado</span>
       <div className="text-3xl font-black font-mono text-white tracking-tight">{neto.toLocaleString()}<span className="text-sm font-normal text-[#666]"> KG</span></div>
       <div className="flex items-center justify-center gap-2 text-[11px] font-mono">
        <span className={`px-2 py-0.5 rounded-full border ${neto>0?"bg-emerald-950/30 text-emerald-400 border-emerald-900/30":"bg-[#1a1a1a] text-[#666] border-[#222]"}`}>{neto>0?`✓ Dentro norma`:"Esperando datos"}</span>
        <span className="text-[#555]">{neto?`${(neto/1000).toFixed(2)}T`:""} </span>
       </div>
      </div>

      <div className="border-2 border-dashed border-[#222] rounded-xl p-4 text-center bg-[#0a0a0a] hover:border-[#444] cursor-pointer">
       <Camera className="w-6 h-6 text-[#444] mx-auto mb-1.5" />
       <p className="text-xs font-bold text-white">Foto ticket báscula + OCR auto</p>
       <p className="text-[10px] font-mono text-[#666]">Detecta peso automático de la foto</p>
      </div>
     </div>
    </CyberCard>

    <CyberCard badgeText="Diésel y rendimiento" variant="default">
     <div className="space-y-3">
      <PremiumInput label="Litros recargados ruta" icon={<Fuel className="w-4 h-4"/>} type="number" placeholder="400" value={litros} onChange={e=>setLitros(e.target.value===""?"":Number(e.target.value))} />
      <div className="grid grid-cols-2 gap-2">
       <div className="bg-[#070709] border border-[#1e1e1e] rounded-xl p-3">
        <span className="text-[9px] font-mono uppercase text-[#666] block">Merma descuento</span>
        <span className="text-lg font-black font-mono text-white">{merma} <span className="text-xs text-[#666]">KG</span></span>
        <span className="text-[10px] font-mono text-[#555]">0.835 kg/L SCT</span>
       </div>
       <div className="bg-[#070709] border border-[#1e1e1e] rounded-xl p-3">
        <span className="text-[9px] font-mono uppercase text-[#666] block">Rendimiento</span>
        <span className="text-lg font-black font-mono text-white">{rendimiento} <span className="text-xs text-[#666]">km/L</span></span>
        <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1"><TrendingUp className="w-3 h-3"/> Bueno</span>
       </div>
      </div>
      <PremiumButton onClick={guardar} disabled={!neto} variant="primary" className="w-full" size="md"><Save className="w-4 h-4"/> Guardar pesaje en historial</PremiumButton>
     </div>
    </CyberCard>

    <CyberCard badgeText={`Historial ${historial.length} pesajes`} variant="default">
     {historial.length===0 ? (
      <div className="py-6 text-center">
       <Weight className="w-8 h-8 text-[#333] mx-auto mb-2" />
       <p className="text-xs font-bold text-white">Sin pesajes guardados</p>
       <p className="text-[11px] font-mono text-[#666]">Tus pesajes se guardan localmente offline</p>
      </div>
     ) : (
      <div className="space-y-2 max-h-[280px] overflow-y-auto">
       {historial.map(h=>(
        <div key={h.id} className="flex justify-between items-center p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl text-xs font-mono">
         <div><span className="text-white font-bold">{h.neto.toLocaleString()}kg neto</span><span className="text-[#666] block text-[10px]">{new Date(h.fecha).toLocaleString("es-MX")} {h.diesel||0}L diesel</span></div>
         <span className="text-[#888]">{h.bruto} / {h.tara}</span>
        </div>
       ))}
      </div>
     )}
    </CyberCard>
   </div>
  </div>
 );
}
