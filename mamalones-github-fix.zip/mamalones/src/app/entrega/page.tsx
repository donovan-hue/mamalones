"use client";

import { useState, useRef } from "react";
import Link from "next/link";
import { ArrowLeft, ShieldCheck, UserCheck, QrCode, CheckCircle2, Camera, PenTool, MapPin, Clock, FileText } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton } from "@/components/PremiumUI";

export default function EntregaPremium() {
 const [fotos, setFotos] = useState(0);
 const [firma, setFirma] = useState(false);
 const [otp, setOtp] = useState("");
 const [entregado, setEntregado] = useState(false);
 const canvasRef = useRef<HTMLCanvasElement>(null);

 const handleEntrega = () => {
  if (fotos>=1 && firma && otp.length===4) {
   setEntregado(true);
  } else {
   alert("Completa evidencia: foto, firma y OTP cliente 4 dígitos");
  }
 };

 if (entregado) {
  return (
   <div className="min-h-screen text-slate-100 max-w-md mx-auto p-4 flex flex-col justify-center pb-20">
    <CyberCard variant="emerald" badgeText="Entrega confirmada Escrow liberado">
     <div className="text-center py-8 space-y-4">
      <div className="w-20 h-20 bg-emerald-500 rounded-full mx-auto flex items-center justify-center animate-bounce"><CheckCircle2 className="w-10 h-10 text-black"/></div>
      <h2 className="text-xl font-black text-white">¡POD Generado!</h2>
      <p className="text-xs font-mono text-[#aaa]">Proof of Delivery enviado al cliente. Escrow de $38,500 liberado en 15 min.</p>
      <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-3 text-left text-xs font-mono">
       <div className="flex justify-between"><span className="text-[#666]">Folio POD</span><span className="text-white font-bold">POD-991823-MX</span></div>
       <div className="flex justify-between"><span className="text-[#666]">Hora entrega</span><span className="text-white">{new Date().toLocaleTimeString()}</span></div>
       <div className="flex justify-between"><span className="text-[#666]">Ubicación</span><span className="text-emerald-400">25.80°N, -108.9°W Culiacán</span></div>
      </div>
      <div className="grid grid-cols-2 gap-2">
       <PremiumButton variant="primary" className="w-full"><FileText className="w-4 h-4"/> Descargar POD PDF</PremiumButton>
       <Link href="/cargas" className="py-3 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-bold text-white text-center">Buscar nuevo flete</Link>
      </div>
     </div>
    </CyberCard>
   </div>
  );
 }

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4"/></Link>
     <div><h1 className="text-sm font-black text-white">ENTREGA CON EVIDENCIA</h1><span className="text-[10px] font-mono text-[#666] uppercase">POD + Escrow release</span></div>
     <PremiumBadge variant="warning">Pendiente</PremiumBadge>
    </div>
   </div>

   <div className="p-4 space-y-4">
    <div className="bg-emerald-950/20 border border-emerald-900/30 rounded-xl p-3 flex gap-2.5">
     <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
     <span className="text-[11px] font-mono text-[#ccc] leading-relaxed"><strong className="text-white">Verificación obligatoria:</strong> Toma fotos, firma digital y pide OTP al cliente para liberar pago escrow.</span>
    </div>

    <CyberCard badgeText="Operador verificado SCT" variant="default">
     <div className="flex gap-3 items-center bg-[#070709] border border-[#1a1a1a] rounded-xl p-3">
      <div className="w-12 h-12 bg-[#12151c] border border-emerald-900/30 rounded-full flex items-center justify-center text-emerald-400"><UserCheck className="w-6 h-6"/></div>
      <div className="flex-1">
       <span className="text-sm font-bold text-white block">Donovan Gaspar Ávila</span>
       <span className="text-[10px] font-mono text-[#666]">FED-8839201-A 4.9  38 viajes</span>
       <span className="text-[9px] font-mono text-emerald-400 font-bold">Sí INE y antecedentes validados</span>
      </div>
      <PremiumBadge variant="success">Auth</PremiumBadge>
     </div>
    </CyberCard>

    <CyberCard badgeText={`Evidencia fotográfica ${fotos}/3 mínimo`} variant="glass">
     <div className="grid grid-cols-3 gap-2">
      {[1,2,3].map(i=>(
       <button key={i} onClick={()=>setFotos(f=>Math.min(3,f+1))} className={`aspect-square border-2 border-dashed rounded-xl flex flex-col items-center justify-center gap-1 transition-colors ${fotos>=i?"bg-emerald-950/30 border-emerald-900/30 text-emerald-400":"bg-[#0a0a0a] border-[#222] text-[#555] hover:border-[#444] hover:text-white"}`}>
        {fotos>=i?<CheckCircle2 className="w-6 h-6"/>:<Camera className="w-6 h-6"/>}
        <span className="text-[9px] font-mono">{fotos>=i?"Foto OK":`Foto ${i}`}</span>
       </button>
      ))}
     </div>
     <p className="text-[10px] font-mono text-[#666] text-center mt-2">Fotos: carga, bodega, ticket báscula destino</p>
    </CyberCard>

    <CyberCard badgeText="Firma digital cliente" variant="default">
     <div className="space-y-2">
      <canvas ref={canvasRef} className="w-full h-32 bg-[#070709] border border-[#1e1e1e] rounded-xl cursor-crosshair" onClick={()=>setFirma(true)} />
      <div className="flex gap-2">
       <button onClick={()=>setFirma(!firma)} className={`flex-1 py-2 rounded-xl text-xs font-mono font-bold border ${firma?"bg-emerald-950/30 border-emerald-900/30 text-emerald-400":"bg-[#12151c] border-slate-800 text-white"}`}><PenTool className="w-3.5 h-3.5 inline mr-1"/>{firma?"Firma capturada ✓":"Tocar para firmar"}</button>
       <button onClick={()=>setFirma(false)} className="px-4 py-2 bg-[#1a1a1a] border border-[#222] rounded-xl text-xs font-mono text-[#666]">Limpiar</button>
      </div>
     </div>
    </CyberCard>

    <CyberCard badgeText="OTP cliente Verificación final">
     <div className="space-y-3">
      <p className="text-[11px] font-mono text-[#888]">Pide al cliente el código de 4 dígitos que le llegó por SMS para confirmar recepción conforme.</p>
      <input value={otp} onChange={e=>setOtp(e.target.value.slice(0,4))} placeholder="0 0 0 0" className="w-full bg-[#070709] border border-[#1e1e1e] focus:border-emerald-900/50 rounded-xl p-4 text-center text-2xl font-mono tracking-[0.5em] text-white outline-none" />
      <div className="flex justify-between text-[10px] font-mono text-[#666]"><span>Código expira en 10 min</span><span className="text-emerald-400">SMS enviado 10:42 AM</span></div>
     </div>
    </CyberCard>

    <CyberCard badgeText="Resumen entrega" variant="glass">
     <div className="space-y-2 text-xs font-mono">
      <div className="flex justify-between p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl"><span className="text-[#666] flex items-center gap-1"><MapPin className="w-3 h-3"/> Ubicación</span><span className="text-white">Culiacán Bodega 3</span></div>
      <div className="flex justify-between p-2.5 bg-[#070709] border border-[#1a1a1a] rounded-xl"><span className="text-[#666] flex items-center gap-1"><Clock className="w-3 h-3"/> Hora</span><span className="text-white">{new Date().toLocaleTimeString()}</span></div>
      <div className="flex justify-between p-2.5 bg-emerald-950/20 border border-emerald-900/20 rounded-xl"><span className="text-[#666]">Escrow a liberar</span><span className="text-emerald-400 font-black">$38,500 MXN</span></div>
     </div>
    </CyberCard>

    <PremiumButton onClick={handleEntrega} variant="success" size="lg" className="w-full"><CheckCircle2 className="w-5 h-5"/> Confirmar entrega y liberar pago</PremiumButton>
    <p className="text-[9px] font-mono text-center text-[#444]">Al confirmar declaras entrega completa y conforme Genera POD automáticamente</p>
   </div>
  </div>
 );
}
