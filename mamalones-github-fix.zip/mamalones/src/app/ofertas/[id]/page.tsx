import OfertasClient from "./client";

export function generateStaticParams() {
 return [{ id: "carga-9901-prod" }, { id: "carga-8802-prod" }, { id: "carga-7703-prod" }, { id: "demo" }];
}

export default function Page() {
 return <OfertasClient />;
}
