"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { useEffect, useState } from "react";

export default function OfertasPorCargaClient() {
 const params = useParams();
 const id = (params?.id as string) || "demo";
 const [ofertas, setOfertas] = useState<any[]>([]);

 useEffect(()=>{
  const stored = JSON.parse(localStorage.getItem("ofertas_para_cliente") || "[]");
  setOfertas(stored.filter((o:any)=>o.cargaId===id));
 },[id]);

 return (
  <div className="min-h-screen max-w-md mx-auto p-4 pb-28">
   <div className="flex items-center gap-3 mb-4">
    <Link href="/mis-cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4 text-white"/></Link>
    <div><h1 className="text-sm font-black text-white">OFERTAS {id.slice(-6).toUpperCase()}</h1><span className="text-[10px] font-mono text-[#666]">{ofertas.length} contraofertas transportistas Validación SCT</span></div>
   </div>
   <div className="space-y-3">
    {ofertas.map(o=>(
     <div key={o.id} className="bg-[#0a0a0a] border border-[#222] rounded-xl p-3">
      <div className="flex justify-between"><span className="text-xs font-bold text-white">{o.empresa}</span><span className="text-sm font-black text-white">${o.precio.toLocaleString()}</span></div>
      <span className="text-[10px] font-mono text-[#666]">{o.unidad} {o.chofer} ETA {o.etaRecogida} → {o.etaEntrega}</span>
      <div className="text-[11px] font-mono text-[#888] mt-1">{o.comentario}</div>
     </div>
    ))}
    {ofertas.length===0 && <div className="py-12 text-center border border-dashed border-[#222] rounded-xl"><p className="text-xs font-bold text-white">Sin ofertas aún</p><p className="text-[11px] font-mono text-[#666] mt-1">Comparte en bolsa de carga para recibir contraofertas con unidad/placas/chofer/ETA</p><Link href="/cargas" className="mt-3 inline-block px-4 py-2 bg-white text-black rounded-xl text-xs font-bold">Ver bolsa</Link></div>}
   </div>
  </div>
 );
}
