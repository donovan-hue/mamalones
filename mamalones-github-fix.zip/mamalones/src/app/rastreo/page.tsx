"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowLeft, Lock, EyeOff, MapPin, Fuel, Clock, AlertTriangle, Phone, MessageCircle, Share2, Maximize2, Pause, Play, Navigation } from "lucide-react";
import { CyberCard, PremiumBadge, PremiumStat } from "@/components/CyberCard";
import { PremiumButton } from "@/components/PremiumUI";

export default function RastreoPremium() {
 const [isLive, setIsLive] = useState(true);
 const [speed, setSpeed] = useState(86);
 const [progress, setProgress] = useState(38);
 const [eta, setEta] = useState("4h 12m");
 const [mode, setMode] = useState<"map" | "satelite">("map");

 useEffect(() => {
  if (!isLive) return;
  const iv = setInterval(() => {
   setSpeed(s => Math.max(20, Math.min(110, s + (Math.random()-0.5)*10)));
   setProgress(p => Math.min(95, p + Math.random()*0.3));
  }, 2000);
  return () => clearInterval(iv);
 }, [isLive]);

 const events = [
  { time: "08:15", title: "Salida Tlaquepaque", desc: "Carga verificada 9.5T", status: "done", km: 0 },
  { time: "08:42", title: "Caseta Arenal", desc: "Pago QR $195 Automatico", status: "done", km: 28 },
  { time: "10:18", title: "Báscula SCT La Barca", desc: "Peso: 9,420kg  Aprobado", status: "done", km: 92 },
  { time: "11:05", title: "Parada Diesel", desc: "Repsol KM 142 340L 42 min", status: "current", km: 142 },
  { time: "~13:30", title: "Caseta Ruiz", desc: "Estimado $620", status: "pending", km: 380 },
  { time: "~15:45", title: "Entrega Culiacán", desc: "Bodega Cliente Escrow release", status: "pending", km: 720 },
 ];

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4 space-y-3">
    <div className="flex items-center gap-3">
     <Link href="/cargas" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl hover:text-white"><ArrowLeft className="w-4 h-4" /></Link>
     <div className="flex-1">
      <div className="flex items-center gap-2">
       <h1 className="text-sm font-black text-white">RASTREO GPS LIVE</h1>
       <PremiumBadge variant="live"> EN VIVO</PremiumBadge>
       <button onClick={()=>setIsLive(!isLive)} className={`ml-auto p-1.5 rounded-lg border ${isLive?"bg-emerald-950/30 border-emerald-900/30 text-emerald-400":"bg-[#1a1a1a] border-[#333] text-[#666]"}`}>
        {isLive?<Pause className="w-3.5 h-3.5"/>:<Play className="w-3.5 h-3.5"/>}
       </button>
      </div>
      <span className="text-[10px] font-mono text-emerald-400 uppercase flex items-center gap-1"><Lock className="w-3 h-3"/> Canal privado encriptado AES-256 Solo tú y cliente</span>
     </div>
    </div>

    <div className="bg-[#12151c] border border-emerald-900/20 rounded-xl p-3 flex gap-2.5">
     <EyeOff className="w-5 h-5 text-emerald-400 shrink-0" />
     <div className="text-[11px] font-mono text-[#aaa] leading-relaxed">
      <span className="font-bold text-white block">Acceso restringido</span>
      Este mapa no es público. Solo chofer y solicitante tienen acceso. Si compartes link, expira en 24h.
     </div>
    </div>

    <div className="grid grid-cols-3 gap-2">
     <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-2.5 text-center">
      <span className="text-[9px] font-mono text-[#666] uppercase block">Velocidad</span>
      <span className="text-xl font-black font-mono text-white">{Math.round(speed)}<span className="text-xs font-normal text-[#666]"> km/h</span></span>
      <span className="text-[10px] font-mono text-emerald-400 block">Cuota GDL-TEP</span>
     </div>
     <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-2.5 text-center">
      <span className="text-[9px] font-mono text-[#666] uppercase block">Progreso</span>
      <span className="text-xl font-black font-mono text-white">{Math.round(progress)}<span className="text-xs font-normal text-[#666]">%</span></span>
      <span className="text-[10px] font-mono text-[#888] block">{Math.round(720*progress/100)}/720 km</span>
     </div>
     <div className="bg-[#0a0a0a] border border-emerald-900/30 rounded-xl p-2.5 text-center">
      <span className="text-[9px] font-mono text-emerald-400 uppercase block">ETA</span>
      <span className="text-lg font-black font-mono text-emerald-400">{eta}</span>
      <span className="text-[10px] font-mono text-[#666] block">Culiacán</span>
     </div>
    </div>
   </div>

   <div className="p-4 space-y-4">
    <CyberCard badgeText={`Mapa ${mode} Telemetría privada`} variant="glass" padding="none" className="overflow-hidden">
     <div className="relative w-full h-[280px] bg-[#07080a] overflow-hidden">
      <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(white_1px,transparent_1px)] [background-size:12px_12px]" />
      
      {/* Map Grid */}
      <div className="absolute inset-0">
       <svg className="w-full h-full" viewBox="0 0 300 280">
        <defs>
         <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke="#1a1a1a" strokeWidth="0.5"/></pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
        {/* Route */}
        <path d={`M 30 220 Q 80 180 ${80+progress*1.5} ${220-progress*1.2} T 260 40`} stroke="#333" strokeWidth="3" fill="none" strokeDasharray="6 6" />
        <path d={`M 30 220 Q 80 180 ${80+progress*1.5} ${220-progress*1.2} T 260 40`} stroke="#10b981" strokeWidth="3" fill="none" strokeLinecap="round" className="drop-shadow-[0_0_6px_rgba(16,185,129,0.5)]" strokeDasharray={`${progress*3} 1000`} />
        
        {/* Points */}
        <circle cx="30" cy="220" r="6" fill="white" stroke="black" strokeWidth="2" />
        <circle cx={80+progress*0.5} cy={220-progress*0.4} r="8" fill="#f59e0b" className="animate-ping opacity-60" />
        <circle cx={80+progress*0.5} cy={220-progress*0.4} r="5" fill="#f59e0b" stroke="white" strokeWidth="2" />
        <circle cx="260" cy="40" r="6" fill="#10b981" stroke="white" strokeWidth="2" />
       </svg>
      </div>

      {/* Labels */}
      <div className="absolute top-3 left-3 bg-black/80 backdrop-blur border border-[#222] px-2.5 py-1 rounded-full text-[10px] font-mono text-white flex items-center gap-1.5"><MapPin className="w-3 h-3" /> ORIGEN: TLAQUEPAQUE</div>
      <div className="absolute top-3 right-3 bg-emerald-950/80 backdrop-blur border border-emerald-900/30 px-2.5 py-1 rounded-full text-[10px] font-mono text-emerald-400 font-bold">DESTINO: CULIACÁN {Math.round(720-progress/100*720)}km</div>
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-amber-950/90 backdrop-blur border border-amber-900/30 px-3 py-1.5 rounded-full text-[11px] font-mono text-amber-300 flex items-center gap-1.5"><Fuel className="w-3 h-3" /> Parada Diesel 42m KM 142</div>

      <div className="absolute bottom-3 right-3 flex gap-1.5">
       <button onClick={()=>setMode(mode==="map"?"satelite":"map")} className="p-2 bg-black/80 backdrop-blur border border-[#333] rounded-xl text-white hover:bg-[#1a1a1a]">{mode==="map"?"🛰️":"🗺️"}</button>
       <button className="p-2 bg-black/80 backdrop-blur border border-[#333] rounded-xl text-white"><Maximize2 className="w-4 h-4" /></button>
      </div>

      <div className="absolute top-1/2 left-3 -translate-y-1/2 bg-black/70 backdrop-blur border border-[#222] rounded-xl p-2 space-y-1">
       <div className="w-6 h-6 bg-white rounded-lg flex items-center justify-center text-black font-black text-xs">▲</div>
       <div className="w-px h-8 bg-[#222] mx-auto" />
       <Navigation className="w-4 h-4 text-emerald-400 mx-auto animate-spin-slow" />
      </div>
     </div>
     <div className="p-3 flex items-center justify-between bg-[#0a0a0a] border-t border-[#1a1a1a]">
      <div className="flex items-center gap-2">
       <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
       <span className="text-[11px] font-mono text-white">Transmisión encriptada Actualiza cada 8s</span>
      </div>
      <span className="text-[10px] font-mono text-[#555]">ID: FLT-9901</span>
     </div>
    </CyberCard>

    <div className="grid grid-cols-2 gap-3">
     <CyberCard badgeText="Combustible" variant="default">
      <div className="flex items-center justify-between">
       <div>
        <span className="text-2xl font-black font-mono text-white">68<span className="text-sm text-[#666]">%</span></span>
        <span className="text-[10px] font-mono text-[#666] block">Diesel 420km autonomía</span>
       </div>
       <Fuel className="w-8 h-8 text-amber-400" />
      </div>
      <div className="w-full bg-[#1a1a1a] h-1.5 rounded-full mt-2 overflow-hidden"><div className="h-full bg-amber-400" style={{width:"68%"}} /></div>
     </CyberCard>
     <CyberCard badgeText="Conductor" variant="emerald">
      <div className="flex items-center gap-2.5">
       <div className="w-10 h-10 bg-[#1a1a1a] border border-emerald-900/30 rounded-xl flex items-center justify-center text-white font-black">DG</div>
       <div>
        <span className="text-xs font-bold text-white block">Donovan Ávila</span>
        <span className="text-[10px] font-mono text-emerald-400"> En ruta 4.9 </span>
       </div>
      </div>
      <div className="flex gap-1.5 mt-2">
       <button className="flex-1 py-1.5 bg-emerald-600 rounded-lg text-[10px] font-bold text-white flex items-center justify-center gap-1"><Phone className="w-3 h-3"/> Llamar</button>
       <button className="flex-1 py-1.5 bg-[#1a1a1a] border border-[#222] rounded-lg text-[10px] font-mono text-white flex items-center justify-center gap-1"><MessageCircle className="w-3 h-3"/> Chat</button>
      </div>
     </CyberCard>
    </div>

    <CyberCard badgeText="Timeline de ruta 6 eventos" variant="default">
     <div className="relative space-y-0">
      <div className="absolute left-[19px] top-2 bottom-2 w-px bg-[#222]" />
      {events.map((ev,i)=>(
       <div key={i} className="relative flex gap-3 pb-4 last:pb-0 group">
        <div className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 z-10 transition-all ${
         ev.status==="done"?"bg-emerald-950/50 border-emerald-900/30 text-emerald-400":
         ev.status==="current"?"bg-amber-950/50 border-amber-900/30 text-amber-400 animate-pulse":
         "bg-[#0a0a0a] border-[#1e1e1e] text-[#444]"
        }`}>
         {ev.status==="done"?"✓":ev.status==="current"?"◉":"○"}
        </div>
        <div className="flex-1 min-w-0 pb-1">
         <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-white">{ev.title}</span>
          <span className="text-[10px] font-mono text-[#666]">{ev.km}km {ev.time}</span>
         </div>
         <span className="text-[11px] font-mono text-[#888] block leading-relaxed">{ev.desc}</span>
         {ev.status==="current" && <div className="mt-1.5 flex gap-1.5"><PremiumBadge variant="warning">En progreso</PremiumBadge><span className="text-[10px] font-mono text-amber-400">42 min parada</span></div>}
        </div>
       </div>
      ))}
     </div>
    </CyberCard>

    <div className="grid grid-cols-2 gap-2">
     <button className="py-3 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white flex items-center justify-center gap-2"><Share2 className="w-4 h-4"/> Compartir link privado</button>
     <button className="py-3 bg-red-950/20 border border-red-900/30 rounded-xl text-xs font-mono text-red-400 flex items-center justify-center gap-2"><AlertTriangle className="w-4 h-4"/> Reportar incidente</button>
    </div>
   </div>
  </div>
 );
}
