"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, Camera, CheckCircle2, MapPin, Clock, Upload, Navigation } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton } from "@/components/PremiumUI";
import { EscrowFlow } from "@/components/Security";

export default function CheckInPage() {
 const [step, setStep] = useState(1);
 const [fotoBascula, setFotoBascula] = useState(false);
 const [fotoCarga, setFotoCarga] = useState(false);
 const [ubicacion, setUbicacion] = useState(false);

 const handleCheckIn = () => {
  if (fotoBascula && fotoCarga && ubicacion) {
   setStep(2);
  } else {
   alert("Completa: foto ticket báscula, foto carga, y ubicación GPS");
  }
 };

 if (step===2) {
  return (
   <div className="min-h-screen max-w-md mx-auto p-4 flex flex-col justify-center pb-20">
    <CyberCard variant="emerald" badgeText="Check-in digital completado GPS activado">
     <div className="text-center py-8 space-y-4">
      <div className="w-20 h-20 bg-emerald-500 rounded-full mx-auto flex items-center justify-center animate-pulse"><CheckCircle2 className="w-10 h-10 text-black"/></div>
      <h2 className="text-xl font-black text-white">¡Rastreo satelital activo!</h2>
      <p className="text-xs font-mono text-[#aaa]">Ticket báscula verificado, fotos subidas, GPS encendido. Cliente notificado que iniciaste ruta.</p>
      <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-3 text-left text-xs font-mono space-y-1">
       <div className="flex justify-between"><span className="text-[#666]">Peso inicial</span><span className="text-white font-bold">9,420 kg Ticket #B-8832</span></div>
       <div className="flex justify-between"><span className="text-[#666]">Ubicación check-in</span><span className="text-emerald-400">Bodega GDL 20.60,-103.31</span></div>
       <div className="flex justify-between"><span className="text-[#666]">GPS</span><span className="text-emerald-400"> En vivo cada 8s AES-256</span></div>
      </div>
      <div className="grid grid-cols-2 gap-2">
       <Link href="/rastreo" className="py-3 bg-emerald-600 text-white font-black rounded-xl text-xs text-center">Ver rastreo en vivo</Link>
       <Link href="/mis-viajes" className="py-3 bg-[#12151c] border border-slate-800 text-white font-bold rounded-xl text-xs text-center">Mis viajes</Link>
      </div>
     </div>
    </CyberCard>
   </div>
  );
 }

 return (
  <div className="min-h-screen max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4">
    <div className="flex items-center gap-3">
     <Link href="/mis-viajes" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4 text-white"/></Link>
     <div><h1 className="text-sm font-black text-white">CHECK-IN DIGITAL</h1><span className="text-[10px] font-mono text-[#666]">Foto ticket báscula → Activa GPS tracking</span></div>
     <PremiumBadge variant="warning">Paso 1/2</PremiumBadge>
    </div>
   </div>

   <div className="p-4 space-y-4">
    <div className="bg-[#12151c] border border-[#222] rounded-xl p-3 flex gap-2.5">
     <Navigation className="w-5 h-5 text-emerald-400 shrink-0" />
     <span className="text-[11px] font-mono text-[#ccc]">Al subir ticket báscula inicial, se activa rastreo satelital y se notifica al cliente que ruta comenzó. Requerido para liberar escrow.</span>
    </div>

    <CyberCard badgeText="Foto ticket báscula inicial *" variant="glass">
     <div className="space-y-3">
      <button onClick={()=>setFotoBascula(!fotoBascula)} className={`w-full aspect-[4/3] border-2 border-dashed rounded-xl flex flex-col items-center justify-center gap-2 transition-all ${fotoBascula?"bg-emerald-950/30 border-emerald-900/30 text-emerald-400":"bg-[#0a0a0a] border-[#333] text-[#666] hover:border-[#555] hover:text-white"}`}>
       {fotoBascula ? <CheckCircle2 className="w-12 h-12" /> : <Camera className="w-12 h-12" />}
       <span className="text-xs font-bold">{fotoBascula?"Ticket verificado ✓ 9,420kg":"Tocar para foto ticket báscula"}</span>
       <span className="text-[10px] font-mono">{fotoBascula?"OCR detectó peso automático":"Debe verse peso, folio, fecha"}</span>
      </button>
      <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
       <div className="bg-[#070709] border border-[#1a1a1a] rounded-lg p-2"><span className="text-[#666] block uppercase text-[9px]">Peso detectado OCR</span><span className="text-white font-bold">9,420 kg</span></div>
       <div className="bg-[#070709] border border-[#1a1a1a] rounded-lg p-2"><span className="text-[#666] block uppercase text-[9px]">Folio ticket</span><span className="text-white font-bold">B-8832 10:42 AM</span></div>
      </div>
     </div>
    </CyberCard>

    <CyberCard badgeText="Foto carga en unidad *" variant="default">
     <button onClick={()=>setFotoCarga(!fotoCarga)} className={`w-full h-32 border-2 border-dashed rounded-xl flex flex-col items-center justify-center gap-2 ${fotoCarga?"bg-emerald-950/30 border-emerald-900/30 text-emerald-400":"bg-[#0a0a0a] border-[#333] text-[#666]"}`}>
      {fotoCarga ? <CheckCircle2 className="w-8 h-8" /> : <Upload className="w-8 h-8" />}
      <span className="text-xs font-bold">{fotoCarga?"Foto carga OK ✓":"Foto carga en caja"}</span>
     </button>
    </CyberCard>

    <CyberCard badgeText="Ubicación GPS check-in *" variant="default">
     <button onClick={()=>setUbicacion(true)} className={`w-full p-4 rounded-xl border flex items-center justify-between ${ubicacion?"bg-emerald-950/30 border-emerald-900/30":"bg-[#0a0a0a] border-[#222] hover:border-[#444]"}`}>
      <div className="flex items-center gap-2.5"><div className={`p-2 rounded-xl ${ubicacion?"bg-emerald-500 text-black":"bg-[#1a1a1a] text-[#666]"}`}><MapPin className="w-5 h-5"/></div><div className="text-left"><p className="text-xs font-bold text-white">{ubicacion?"Ubicación capturada ✓":"Capturar ubicación GPS"}</p><p className="text-[10px] font-mono text-[#666]">{ubicacion?"20.60°N, -103.31°W Bodega GDL +12m precisión":"Requerido para validar punto exacto carga"}</p></div></div>
      {ubicacion && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
     </button>
     <div className="mt-3 grid grid-cols-2 gap-2 text-[10px] font-mono">
      <div className="bg-[#070709] border border-[#1a1a1a] rounded-lg p-2 flex items-center gap-1.5"><Clock className="w-3 h-3 text-[#666]"/> <span className="text-[#888]">Hora check-in {new Date().toLocaleTimeString()}</span></div>
      <div className="bg-[#070709] border border-[#1a1a1a] rounded-lg p-2"><span className="text-[#666]">Distancia a origen</span><span className="text-emerald-400 font-bold ml-1">0.2km Sí</span></div>
     </div>
    </CyberCard>

    <EscrowFlow amount={38500} status="retenido" />

    <PremiumButton onClick={handleCheckIn} variant="success" size="lg" className="w-full" disabled={!fotoBascula || !fotoCarga || !ubicacion}><Upload className="w-5 h-5"/> Confirmar check-in y activar rastreo GPS</PremiumButton>
    <p className="text-[9px] font-mono text-center text-[#444]">Al confirmar validas peso inicial, fotos y ubicación Cliente recibe notificación push + tracking en vivo inicia</p>
   </div>
  </div>
 );
}
