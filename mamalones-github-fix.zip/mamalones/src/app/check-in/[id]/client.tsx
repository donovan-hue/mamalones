"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Camera, CheckCircle2, MapPin, Upload } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton } from "@/components/PremiumUI";
import { EscrowFlow } from "@/components/Security";

export default function CheckInDynamicClient() {
 const params = useParams();
 const id = (params?.id as string) || "demo";
 const [step, setStep] = useState(1);
 const [fotoBascula, setFotoBascula] = useState(false);
 const [fotoCarga, setFotoCarga] = useState(false);
 const [ubicacion, setUbicacion] = useState(false);

 if (step===2) {
  return (
   <div className="min-h-screen max-w-md mx-auto p-4 flex flex-col justify-center pb-20">
    <CyberCard variant="emerald" badgeText={`Check-in ${id} GPS activado`}>
     <div className="text-center py-8 space-y-4">
      <div className="w-20 h-20 bg-emerald-500 rounded-full mx-auto flex items-center justify-center animate-pulse"><CheckCircle2 className="w-10 h-10 text-black"/></div>
      <h2 className="text-xl font-black text-white">¡Rastreo activo!</h2>
      <p className="text-xs font-mono text-[#aaa]">Ticket {id} verificado Cliente notificado Tracking cada 8s</p>
      <div className="grid grid-cols-2 gap-2">
       <Link href="/rastreo" className="py-3 bg-emerald-600 text-white font-black rounded-xl text-xs text-center">Ver rastreo en vivo</Link>
       <Link href="/mis-viajes" className="py-3 bg-[#12151c] border border-slate-800 text-white font-bold rounded-xl text-xs text-center">Mis viajes</Link>
      </div>
     </div>
    </CyberCard>
   </div>
  );
 }

 return (
  <div className="min-h-screen max-w-md mx-auto pb-28">
   <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-[#1a1a1a] p-4">
    <div className="flex items-center gap-3">
     <Link href="/mis-viajes" className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl"><ArrowLeft className="w-4 h-4 text-white"/></Link>
     <div><h1 className="text-sm font-black text-white">CHECK-IN {id.slice(-6).toUpperCase()}</h1><span className="text-[10px] font-mono text-[#666]">Foto ticket báscula → Activa GPS</span></div>
     <PremiumBadge variant="warning">Pre-ruta</PremiumBadge>
    </div>
   </div>

   <div className="p-4 space-y-4">
    <CyberCard badgeText="Foto ticket báscula inicial * (OCR)" variant="glass">
     <button onClick={()=>setFotoBascula(!fotoBascula)} className={`w-full aspect-[4/3] border-2 border-dashed rounded-xl flex flex-col items-center justify-center gap-2 ${fotoBascula?"bg-emerald-950/30 border-emerald-900/30 text-emerald-400":"bg-[#0a0a0a] border-[#333] text-[#666]"}`}>
      {fotoBascula ? <CheckCircle2 className="w-12 h-12" /> : <Camera className="w-12 h-12" />}
      <span className="text-xs font-bold">{fotoBascula?"9,420kg verificado ✓ OCR":"Tocar para foto ticket báscula"}</span>
     </button>
    </CyberCard>

    <CyberCard badgeText="Foto carga + ubicación" variant="default">
     <div className="grid grid-cols-2 gap-2">
      <button onClick={()=>setFotoCarga(!fotoCarga)} className={`h-24 border-2 border-dashed rounded-xl flex flex-col items-center justify-center gap-1 ${fotoCarga?"bg-emerald-950/30 border-emerald-900/30 text-emerald-400":"bg-[#0a0a0a] border-[#333] text-[#666]"}`}><Upload className="w-6 h-6"/>{fotoCarga?"Carga OK":"Foto carga"}</button>
      <button onClick={()=>setUbicacion(true)} className={`h-24 border-2 border-dashed rounded-xl flex flex-col items-center justify-center gap-1 ${ubicacion?"bg-emerald-950/30 border-emerald-900/30 text-emerald-400":"bg-[#0a0a0a] border-[#333] text-[#666]"}`}><MapPin className="w-6 h-6"/>{ubicacion?"GPS OK":"Ubicación GPS"}</button>
     </div>
    </CyberCard>

    <EscrowFlow amount={38500} status="retenido" />
    <PremiumButton onClick={()=> fotoBascula && fotoCarga && ubicacion ? setStep(2) : alert("Completa: ticket, carga y ubicación")} variant="success" size="lg" className="w-full" disabled={!fotoBascula || !fotoCarga || !ubicacion}>Confirmar check-in y activar GPS {id.slice(-6)}</PremiumButton>
    <p className="text-[9px] font-mono text-center text-[#444]">Cliente recibe push Tracking en vivo cada 8s AES-256 encriptado</p>
   </div>
  </div>
 );
}
