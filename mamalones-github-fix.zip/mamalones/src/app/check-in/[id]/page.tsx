import CheckInDynamicClient from "./client";

export function generateStaticParams() {
 return [{ id: "demo" }, { id: "carga-9901-prod" }, { id: "carga-8802-prod" }, { id: "carga-7703-prod" }];
}

export default function Page() {
 return <CheckInDynamicClient />;
}
