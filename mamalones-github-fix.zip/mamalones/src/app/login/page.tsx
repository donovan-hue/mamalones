"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Lock, Mail, ArrowRight, ShieldCheck, Cpu, Eye, EyeOff } from "lucide-react";
import { CyberCard, PremiumBadge } from "@/components/CyberCard";
import { PremiumButton, PremiumInput } from "@/components/PremiumUI";

export default function LoginPremium() {
 const router = useRouter();
 const [email, setEmail] = useState("");
 const [password, setPassword] = useState("");
 const [showPass, setShowPass] = useState(false);
 const [loading, setLoading] = useState(false);
 const [error, setError] = useState("");

 const handleLogin = (e: React.FormEvent) => {
  e.preventDefault();
  setLoading(true);
  setError("");
  setTimeout(() => {
   if (!email || !password) {
    setError("Ingresa correo y contraseña");
    setLoading(false);
    return;
   }
   localStorage.setItem("mamalones_user", JSON.stringify({ email, name: email.split("@")[0] }));
   router.push("/dashboard");
  }, 900);
 };

 return (
  <div className="min-h-screen text-slate-100 max-w-md mx-auto flex flex-col p-4 pb-20">
   <div className="pt-6 text-center space-y-3">
    <div className="inline-flex p-4 bg-white text-black rounded-2xl shadow-[0_0_30px_rgba(255,255,255,0.2)]">
     <Cpu className="w-8 h-8" />
    </div>
    <div>
     <h1 className="text-2xl font-black tracking-tighter text-white">MAMALONES</h1>
     <div className="flex items-center justify-center gap-2 mt-1">
      <PremiumBadge variant="success">KRONOS FLEET</PremiumBadge>
      <span className="text-[10px] font-mono text-[#666]">v2.4 Jalisco</span>
     </div>
    </div>
   </div>

   <div className="my-auto space-y-4 pt-8">
    <CyberCard badgeText="Acceso operadores verificados" variant="glow">
     <form onSubmit={handleLogin} className="space-y-4">
      <PremiumInput label="Correo electrónico" icon={<Mail className="w-4 h-4"/>} type="email" required placeholder="operador@kronos.space" value={email} onChange={e=>setEmail(e.target.value)} />

      <div className="space-y-1.5">
       <label className="text-[10px] font-mono font-bold text-[#666] uppercase tracking-widest">Contraseña</label>
       <div className="relative group">
        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#555] group-focus-within:text-white" />
        <input type={showPass?"text":"password"} required placeholder="" value={password} onChange={e=>setPassword(e.target.value)} className="w-full bg-[#0a0b0d] border border-slate-800 focus:border-[#444] rounded-xl p-2.5 pl-10 pr-10 text-xs font-mono text-white outline-none" />
        <button type="button" onClick={()=>setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#555] hover:text-white"><Eye className={`w-4 h-4 ${showPass?"hidden":"block"}`} /><EyeOff className={`w-4 h-4 ${showPass?"block":"hidden"}`} /></button>
       </div>
      </div>

      {error && <div className="p-2.5 bg-red-950/30 border border-red-900/30 rounded-xl text-[11px] font-mono text-red-400">{error}</div>}

      <PremiumButton type="submit" disabled={loading} variant="primary" size="lg" className="w-full">
       {loading ? "Verificando..." : <><span>Ingresar a plataforma</span><ArrowRight className="w-4 h-4" /></>}
      </PremiumButton>

      <div className="flex justify-between text-[11px] font-mono">
       <Link href="/registro" className="text-[#888] hover:text-white">¿Sin cuenta? <span className="text-white font-bold underline">Registrar unidad</span></Link>
       <button type="button" className="text-[#555] hover:text-[#888]">¿Olvidaste pass?</button>
      </div>
     </form>
    </CyberCard>

    <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-3 space-y-2">
     <p className="text-[10px] font-mono font-bold text-[#666] uppercase tracking-widest">Acceso demo rápido</p>
     <div className="grid grid-cols-2 gap-2">
      <button onClick={()=>{setEmail("demo@mamalones.mx"); setPassword("demo123");}} className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white text-left"><span className="block font-bold">Chofer Demo</span><span className="text-[10px] text-[#666]">demo@mamalones.mx</span></button>
      <button onClick={()=>{setEmail("cliente@granos.com"); setPassword("cliente123");}} className="p-2.5 bg-[#12151c] border border-slate-800 rounded-xl text-xs font-mono text-white text-left"><span className="block font-bold">Cliente Demo</span><span className="text-[10px] text-[#666]">cliente@granos.com</span></button>
     </div>
    </div>

    <div className="grid grid-cols-3 gap-2 text-center">
     <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-xl p-2.5"><span className="text-lg font-black font-mono text-white block">34</span><span className="text-[9px] font-mono text-[#666] uppercase">Mamalones activos</span></div>
     <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-xl p-2.5"><span className="text-lg font-black font-mono text-emerald-400 block">$2.4M</span><span className="text-[9px] font-mono text-[#666] uppercase">Pagado escrow</span></div>
     <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-xl p-2.5"><span className="text-lg font-black font-mono text-white block">4.9 </span><span className="text-[9px] font-mono text-[#666] uppercase">Rating</span></div>
    </div>
   </div>

   <div className="pt-6 text-center border-t border-[#111] space-y-2">
    <div className="flex items-center justify-center gap-1.5 text-[10px] font-mono text-[#555]"><ShieldCheck className="w-3.5 h-3.5"/><span>AES-256 SCT/SAT verificado Hecho en Tlaquepaque</span></div>
   </div>
  </div>
 );
}
