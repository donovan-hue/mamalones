# 🚀 Guía de Lanzamiento - MAMALONES / Kronos Fleet

Ya arreglé el build. Aquí los pasos exactos para lanzarlo HOY.

## ✅ Lo que ya se arregló
- Build roto por Supabase en `/registro` -> FIXED (ahora usa modo demo si no hay ENV)
- `/cargas` ahora tiene fallback demo + indicador MODO DEMO
- `next.config.ts` limpio para Vercel
- SEO: metadata OpenGraph, Twitter, keywords Jalisco
- Landing renovada: hero mamalon, features, social proof
- `manifest.json` para PWA instalable
- `supabase-schema.sql` listo para crear tablas en 1 click

## 1) Deploy en Vercel (5 minutos, gratis)

### Opción A: Desde GitHub (recomendado)
1. Haz push de estos cambios a tu repo:
```bash
git add .
git commit -m "feat: producción lista para lanzamiento"
git push origin main
```
2. Ve a https://vercel.com/new
3. Importa `donovan-hue/mamalones`
4. Framework: Next.js (detectado auto)
5. En Environment Variables agrega (opcional para MVP):
```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
```
Si los dejas vacíos, la app funciona en MODO DEMO con datos fake de GDL->Culiacán. Perfecto para empezar propaganda sin backend.

6. Click Deploy -> tendrás URL tipo `mamalones.vercel.app`

### Opción B: Vercel CLI
```bash
npm i -g vercel
vercel --prod
```

## 2) Configurar Supabase (cuando quieras dejar el demo)

1. Crea proyecto en https://supabase.com (gratis)
2. Ve a SQL Editor, pega el contenido de `supabase-schema.sql` y Run
3. Ve a Project Settings > API y copia URL y anon key
4. En Vercel Dashboard > Settings > Environment Variables, agrégalas y Redeploy
5. ¡Listo! Ya guarda cargas reales.

## 3) Dominio propio (opcional)

Vercel > Settings > Domains > Agrega `mamalones.mx` o `kronosfleet.com`
Sigue las instrucciones DNS (es 1 CNAME).

## 4) Checklist final antes de propaganda

- [x] Build pasa con `npm run build`
- [ ] Probar en móvil (ya es responsive max-w-md, estilo app)
- [ ] Cambiar textos demo (Donovan Gaspar Ávila, placas 88-AA-3B) por genéricos en producción
- [ ] Agregar tu WhatsApp real en el landing (yo dejé estructura)
- [ ] Crear logo final (ahora usa ▲ blanco)
- [ ] Activar Vercel Analytics (gratis, 1 click)

## 5) Qué mejorar esta semana post-launch

Prioridad:
1. Auth real con Supabase Auth (ahora login es fake)
2. WhatsApp deep link en cada carga: `https://wa.me/5233XXXX?text=...`
3. Postulaciones reales guardadas en tabla `postulaciones`
4. Notificaciones por email cuando alguien se postula
5. Panel de cliente para ver tracking privado

Todo eso ya tiene tablas preparadas en el SQL.

## Estructura del proyecto final

```
src/
  app/
    page.tsx -> Landing nueva mamalona
    cargas/ -> Mercado con filtros escrow
    publicar/ -> Form + Supabase
    rastreo/ -> Mapa encriptado privado
    bascula/, caseta/, entrega/, fiscal/ -> Módulos valor agregado
    login/, registro/, configuracion/
  components/
    Navbar.tsx -> Buscador + menú 12 secciones
    CyberCard.tsx
  lib/
    supabase.ts -> Client seguro con demo fallback
```

Duda? Escríbeme y lo deployamos juntos.
