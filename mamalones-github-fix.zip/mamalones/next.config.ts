import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  output: 'export', // ✅ 100% compatible Cloudflare Pages static
  trailingSlash: true,
  images: {
    unoptimized: true,
  },
  experimental: {
    optimizePackageImports: ['lucide-react']
  },
  // Para Cloudflare - sin Image Optimization server
}

export default nextConfig
