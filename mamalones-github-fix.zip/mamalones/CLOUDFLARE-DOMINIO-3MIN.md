# CLOUDFLARE PAGES + DOMINIO - 3 MINUTOS - SERIO FINAL

Tu código ya está 100% serio, 29 rutas static OK, listo para dominio.

## Paso 1: Actualiza GitHub (1 minuto)

En tu compu local (donde descargaste mamalones-serio-final.zip):

```bash
cd mamalones
git status # debe mostrar todo limpio porque ya commiteaste aquí
git push origin main
```

Si te da error porque tu local no tiene los commits de aquí, haz:

```bash
# Fuerza push de esta versión seria (ya está commiteada como 391dec1)
git push origin main --force
# O mejor: copia manualmente los archivos de este ZIP encima de tu repo local y haz push
```

Verifica en https://github.com/donovan-hue/mamalones que el último commit sea:
`style: premium serio corporativo - sin brillos, sin emojis, paleta zinc, Inter, empresa seria`

## Paso 2: Cloudflare Pages Deploy (2 minutos)

1. Entra https://dash.cloudflare.com → **Pages** → **Create a project** → **Connect to Git**
2. Selecciona **donovan-hue/mamalones**
3. Build settings:
   - Framework preset: **Next.js (Static HTML Export)**
   - Build command: `npm run build`
   - Build output directory: `out`
   - Root directory: (vacío)
4. Environment variables → **Add variable**:
   - `NODE_VERSION` = `20`
   - (Opcional) `NEXT_PUBLIC_SUPABASE_URL` = tu url si quieres backend real, si no déjalo vacío funciona demo
   - `NEXT_PUBLIC_WHATSAPP` = `5233TU_NUMERO_REAL` (ej 523312345678)
5. **Save and Deploy** → espera 2-3 min → te da `https://mamalones.pages.dev` funcionando

## Paso 3: Dominio mamalones.mx (1 minuto si ya está en Cloudflare)

### Si NO tienes dominio aún (compra en Cloudflare, $160 MXN/año):
1. Cloudflare Dashboard → **Domain Registration** → **Register Domain** → busca `mamalones.mx` o `mamaloneslogistics.com`
2. Compra → Auto-configura DNS
3. Luego Pages → tu proyecto → **Custom domains** → **Set up a custom domain** → escribe `mamalones.mx` → Cloudflare lo conecta automático en 10 segundos

### Si YA tienes dominio en GoDaddy/Namecheap:
1. Cloudflare → **Add a site** → pon `mamalones.mx` → te da 2 nameservers tipo `josh.ns.cloudflare.com` y `linda.ns.cloudflare.com`
2. Ve a GoDaddy → My Products → DNS → cambia nameservers a los de Cloudflare
3. Espera 2-5 min (a veces 1h)
4. Luego Pages → Custom domains → `mamalones.mx` + `www.mamalones.mx` → **Activate**

### SSL:
Cloudflare → **SSL/TLS** → **Overview** → Modo **Full** → **Edge Certificates** → Activa **Always Use HTTPS** y **Automatic HTTPS Rewrites**

Listo: `https://mamalones.mx` con candado verde, CDN global, <1s carga.

## Verificación final (después de deploy)

Abre https://mamalones.mx y prueba:
- [ ] `/` landing seria sin emojis, sin brillos, con trust bar SCT/SAT/AES-256
- [ ] Switch Cliente/Transportista arriba
- [ ] `/cargas` bolsa filtrada, click Ver detalles + Ofertar → modal con unidad/placas/chofer/ETA
- [ ] `/publicar` wizard 5 pasos: material peso/volumen, ruta exacta lat/lng, unidad/EPP, tarifa, escrow+seguro
- [ ] `/mis-cargas` cliente con ofertas, `/mis-viajes` transportista con check-in
- [ ] `/check-in/demo` foto ticket báscula OCR → activa GPS
- [ ] `/rastreo` live telemetry, `/empresa` verificado, `/dashboard` KPIs

Todo esto ya está en `out/` generado.

## Post-deploy (cambiar datos demo)

Antes de mandar a clientes reales, busca en código y cambia:
- `523333333333` → tu WhatsApp real con 52 + lada
- `Donovan Ávila / FED-8839201 / 88-AA-3B` → deja genérico o tu empresa
- En `supabase-schema.sql` si usas Supabase, cambia RLS de `using true` a políticas reales (te puedo generar v2 segura)

## Costos

- Cloudflare Pages: **$0 gratis** (banda ilimitada, builds ilimitados)
- Dominio .mx en Cloudflare: **$10/año** (~$160 MXN)
- SSL: **$0 gratis**
- Total para empezar a cobrar comisión 3%: **$160 MXN/año**

¿Deploy hecho? Mándame la URL https://mamalones.mx y te hago auditoría final de seguridad + SEO.
