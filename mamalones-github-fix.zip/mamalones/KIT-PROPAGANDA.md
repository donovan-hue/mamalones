# 📣 KIT DE PROPAGANDA - MAMALONES

Este es tu arsenal para lanzar hoy. Copy paste directo a WhatsApp, Facebook, TikTok.

---

### 🎯 NOMBRE Y SLOGAN

**MAMALONES** by Kronos Fleet
- Principal: "Fletes que sí pagan. Unidades que sí llegan."
- Secundario: "La plataforma logística de Jalisco sin coyotes"
- Alternativo: "Directo, asegurado y con rastreo privado"

### 🖼️ BIO PARA REDES

**Instagram / Facebook / TikTok:**
```
🚛 MAMALONES | Kronos Fleet
Fletes verificados GDL ↔️ Sinaloa
✅ Pago en custodia (Escrow)
📍 Rastreo GPS privado encriptado
📄 Carta Porte SAT 3.1 automática
👇 Busca o publica carga gratis
```
Link: tu URL vercel.app

**WhatsApp Business:**
```
MAMALONES 🚛 - Plataforma de fletes Jalisco
Busca cargas, publica gratis, cobra seguro con Escrow.
Atención directa Tlaquepaque.
```

### 📝 POST 1 - Lanzamiento (Facebook Grupos de Trailers, Fletes Jalisco)

```
🚨 ATENCIÓN TRAILEROS Y FLETEROS DE JALISCO 🚨

Cansado de que no te paguen o de rogar por carga en grupos de WhatsApp?

Lancé MAMALONES - la plataforma donde:

✅ Ves solo cargas DISPONIBLES y reales (las que están en tránsito se ocultan por seguridad)
✅ Todo con PAGO EN CUSTODIA - tu dinero asegurado hasta entrega
✅ Rastreo GPS PRIVADO - solo tú y el cliente ven dónde vas, nadie más
✅ Carta Porte SAT 3.1 automática, báscula, tag QR casetas, todo en un lugar

Ya hay 3 cargas demo de Guadalajara a Culiacán / Mazatlán para que pruebes.

Es GRATIS publicar y postularte hoy.

👉 Entra: https://mamalones.vercel.app
👉 Busca: Tablero de Cargas
👉 Postula tu unidad en 1 click

Hecho en Tlaquepaque, para los que sí chambean.

¿Qué ruta te falta? Comenta y la subimos.

#FletesJalisco #Torton #Traileros #Cargas
```

### 📝 POST 2 - Para clientes que publican carga (Dueños de mercancía, granos)

```
¿Mueves trigo, maíz, soya de Jalisco a Sinaloa?

En MAMALONES publicas tu carga en 30 segundos y te llegan solo unidades VERIFICADAS (licencia, placas, seguro validados por SCT/SAT).

🔒 Tu carga no se publica en público una vez asignada. Solo tú y el chofer ven el rastreo.
💰 Puedes activar PAGO ESCROW - el chofer sabe que su pago está asegurado y tú que no te va a dejar tirado.
📄 Te genera la Carta Porte automáticamente.

Publicar es gratis esta semana de lanzamiento.

👉 https://mamalones.vercel.app/publicar

Dime qué ruta mueves seguido y te aviso cuando haya mamalón disponible.
```

### 🎥 GUIÓN TIKTOK / REEL (15-20 seg, graba en tu torton)

**Escena 1 (0-3s):** Tú frente al camión, con ruido de motor.
Texto en pantalla: "POV: eres trailero y te deben 2 fletes"

**Escena 2 (3-8s):** Muestra la pantalla de tu web /cargas en el cel.
Voz: "Por eso hice Mamalones. Aquí solo salen cargas que sí pagan porque el dinero se queda en custodia hasta que entregas."

**Escena 3 (8-14s):** Muestra rastreo privado, escrow verde.
Voz: "Y tu ubicación no la ve nadie más que el cliente. Nada de que te andan cazando en la carretera."

**Escena 4 (14-20s):** CTA
Voz: "Link en bio. Publicar es gratis. ¿Qué ruta jalas tú? Te subo una carga."

**Hashtags:** #trailero #torton #fletes #jalisco #transportista #mamalones #kronosfleet

### 💬 MENSAJE WHATSAPP PARA DIFUSIÓN (a tus contactos traileros)

```
Que onda carnal 🚛

Te comparto mi proyecto que acabo de lanzar: MAMALONES

Es una página para que ya no batalles buscando flete. Publico cargas de GDL a Sinaloa y tú te postulas en corto, sin intermediarios.

Todo con pago seguro y tu GPS privado, solo lo ve el cliente.

Échale un ojo, es gratis y ya puedes postularte:

👉 https://mamalones.vercel.app/cargas

Si te late, regístrate como unidad y te aviso en cuanto salga una pa tu ruta.

¿Jalas qué? ¿Torton, Rabón?
```

### 🎨 PALETA Y ESTILO VISUAL

Ya usas: negro #000, #0a0a0a cards, blanco, slate-400, emerald-400 para escrow.
Mantén eso. Se ve Vercel-like, pro y no ñero. Diferente a todos los grupos de fletes que se ven viejos.

Logo: por ahora ▲ blanco con texto KRONOS FLEET. Para logo final sugiere:
- Silueta de torton minimalista
- O letra M con llanta

Tip: Genera logo en https://www.logo.com con prompt "minimalist trucking logo black white"

### 📅 CALENDARIO PRIMERA SEMANA

- **Día 1 (Hoy):** Deploy + Post en 3 grupos FB: "Fletes Jalisco", "Traileros Unidos Mexico", "Bolsa de Trabajo Trailero"
- **Día 2:** 2 TikToks + mensaje a 20 contactos WhatsApp
- **Día 3:** Publica 5 cargas reales (pídele a algún conocido que publique aunque sea demo)
- **Día 4:** Historias IG con encuesta: "¿Qué te da más miedo? A) Que no paguen B) Que te roben carga"
- **Día 5:** Ofrece 1 mes escrow gratis a los primeros 10
- **Día 7:** Recolecta testimonios y ponlos en landing

### 💡 GANCHO PARA PAGAR

Cuando te pregunten "¿Cuánto cobras?", responde:

> "Publicar y postular es gratis. Solo cobro 3% cuando el flete se asegura con escrow y se entrega sin broncas. Si no hay escrow, no cobro. Yo gano si tú cobras."

Eso quita miedo.

¿Quieres que te haga las imágenes/flyers también? Puedo generarte 3 posts visuales con tu estilo.
