-- SCHEMA PARA MAMALONES / KRONOS FLEET
-- Ejecuta esto en el SQL Editor de Supabase

-- 1. Tabla de cargas (tablero público)
create table if not exists cargas (
  id uuid primary key default gen_random_uuid(),
  origen text not null,
  destino text not null,
  monto numeric not null,
  producto text not null,
  unidad_requerida text not null,
  escrow_activo boolean default false,
  estatus text default 'disponible' check (estatus in ('disponible','asignada','en_transito','entregada','cancelada')),
  created_at timestamp with time zone default now(),
  cliente_id uuid,
  chofer_asignado_id uuid
);

-- 2. Expedientes / unidades
create table if not exists expedientes (
  id uuid primary key default gen_random_uuid(),
  nombre_operador text not null,
  licencia_federal text not null,
  placas_unidad text not null,
  poliza_seguro text not null,
  estatus_verificacion text default 'pendiente' check (estatus_verificacion in ('pendiente','validado','rechazado')),
  created_at timestamp with time zone default now()
);

-- 3. Postulaciones (privadas)
create table if not exists postulaciones (
  id uuid primary key default gen_random_uuid(),
  carga_id uuid references cargas(id) on delete cascade,
  expediente_id uuid references expedientes(id) on delete cascade,
  monto_ofertado numeric,
  mensaje text,
  estatus text default 'pendiente' check (estatus in ('pendiente','aceptada','rechazada')),
  created_at timestamp with time zone default now()
);

-- 4. Rastreo (opcional, telemetría)
create table if not exists rastreos (
  id uuid primary key default gen_random_uuid(),
  carga_id uuid references cargas(id) on delete cascade,
  lat numeric,
  lng numeric,
  velocidad numeric,
  evento text,
  created_at timestamp with time zone default now()
);

-- Políticas RLS (desactívalas para MVP rápido, luego actívalas)
alter table cargas enable row level security;
alter table expedientes enable row level security;
alter table postulaciones enable row level security;
alter table rastreos enable row level security;

-- Políticas permisivas para demo (¡cámbialas en producción real!)
create policy "Lectura pública cargas disponibles" on cargas for select using (estatus = 'disponible');
create policy "Inserción pública" on cargas for insert with check (true);
create policy "Todo permitido expedientes demo" on expedientes for all using (true) with check (true);
create policy "Todo permitido postulaciones demo" on postulaciones for all using (true) with check (true);
create policy "Todo permitido rastreos demo" on rastreos for all using (true) with check (true);

-- Índices
create index idx_cargas_estatus on cargas(estatus);
create index idx_cargas_created on cargas(created_at desc);
create index idx_expedientes_placas on expedientes(placas_unidad);
