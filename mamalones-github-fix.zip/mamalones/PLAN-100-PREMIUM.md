# PLAN 100% PREMIUM - MAMALONES

## Dónde verificar los cambios que ya hice

Ejecuta en tu terminal o revisa aquí:

```bash
cd /home/user/mamalones
git diff --stat HEAD
git status
```

**Ya modificados (12 archivos) y listos para push:**
- `src/app/page.tsx` -> Landing nueva mamalona con hero, stats, features, testimonio
- `src/app/cargas/page.tsx` -> Modo demo + escrow filter + 3 cargas
- `src/app/publicar/page.tsx` -> Modo demo fix
- `src/app/registro/page.tsx` -> Fix build crash
- `src/lib/supabase.ts` -> Cliente seguro con demo fallback
- `src/app/layout.tsx` -> SEO OpenGraph + viewport premium
- `src/app/globals.css` -> Glow, scrollbar premium
- `next.config.ts` -> Fix build
- Nuevos: `supabase-schema.sql`, `.env.example`, `manifest.json`, `DEPLOYMENT.md`, `KIT-PROPAGANDA.md`, `og-image.png`

**Build ahora pasa:** `npm run build` -> 16 páginas OK (antes fallaba)

Para verlos físicamente:
- `/home/user/mamalones/` en tu workspace
- O haz `git diff` para ver línea por línea

---

## PLAN PARA APP PREMIUM COMPLETA (Sin pausas - Ejecución inmediata)

Voy a convertir cada página simple en una app premium de nivel SaaS tipo Linear/Vercel/Stripe Dashboard.

### FASE 1: FUNDACIÓN PREMIUM (ahora)
- [ ] 1.1 Rediseñar `CyberCard` a `PremiumCard` con variantes: glow, hover, status, glass
- [ ] 1.2 Nuevo `Navbar` premium: notificaciones live, balance escrow, perfil, búsqueda global con cmd+K
- [ ] 1.3 Componentes base: `PremiumButton`, `PremiumInput`, `StatCard`, `Timeline`, `MapLive`, `FileDropzone`, `SignaturePad`, `PremiumBadge`
- [ ] 1.4 Sistema de toasts/notificaciones, skeletons y empty states
- [ ] 1.5 Hooks: useLocalStorage, useLiveLocation (simulador), useEscrowCalc

### FASE 2: PÁGINAS CORE V2 (valle de la muerte - donde ganas dinero)

**/cargas - De lista simple a Marketplace PRO:**
- Búsqueda por origen/destino con autocomplete
- Filtros avanzados: precio slider, tipo unidad 8 opciones, escrow, verificación SCT, distancia
- Orden: más reciente, mejor pagado, más cerca
- Vista grid/list toggle
- Modal detalle completo: cliente verificado, historial, fotos carga, ruta mapa mini, cálculo flete por km, botón postular con oferta + WhatsApp + copiar link
- Favoritos con localStorage
- Auto-refresh cada 30s
- Stats header: cargas hoy, tarifa promedio JAL-SIN, mamalones activos

**/publicar - Wizard 4 pasos:**
- Step 1: Ruta (origen, destino, paradas intermedias dinámicas, fecha)
- Step 2: Mercancía (tipo, peso, dimensiones, fotos, valor)
- Step 3: Unidad y tarifa (tipo unidad 8 opciones, tarifa, calculadora sugerida $/km, escrow explicación con toggle premium, seguro)
- Step 4: Preview + confirmación + publicación animada
- Validación real, progreso, guardado local si se sale
- Estimador de tarifa automático

**/rastreo - De SVG estático a Live Telemetry SaaS:**
- Mapa con simulación movimiento real (setInterval mueve truck)
- Métricas live: velocidad, combustible, ETA, temperatura caja (si thermo), tiempo conduciendo
- Gráfica velocidad últimas 4h
- Timeline eventos completo: salida, casetas, báscula, paradas, entrega
- Botón pánico/incidente que guarda en local
- Compartir link privado con expiración
- Driver card con call/message
- Modo teatro fullscreen

**/dashboard - NUEVA - Centro de mando:**
- KPIs: ingresos mes, fletes completados, km recorridos, rating
- Gráfica ingresos 7 días
- Cargas activas y postulaciones
- Balance escrow
- Actividad reciente

### FASE 3: OPERACIONES PREMIUM

**/bascula - Báscula Pro:**
- Historial pesajes con fotos ticket
- OCR simulado, export PDF
- Gráfica peso bruto vs neto
- Alertas sobrepeso SCT
- Calculadora merma avanzada con diésel, km, rendimiento

**/caseta - Wallet Tag Pro:**
- Balance con add funds modal (Stripe/OXXO simulado)
- Gráfica gastos mes
- Transacciones con filtros, búsqueda, export CSV
- Tarjetas Tag múltiples, auto-recarga, límites
- Mapa casetas México, costo por ruta

**/entrega - Entrega con Evidencia Pro:**
- Checklist entrega: fotos, firma digital canvas, OTP cliente, geolocalización
- Escrow release flow con confirmación
- Generación POD (Proof of Delivery) PDF premium
- Rating mutuo chofer/cliente

**/fiscal - SAT Hub Pro:**
- Form wizard Carta Porte 3.1 completo con validación
- Preview UUID, QR, XML
- Historial timbrados, re timbrado, cancelación
- Integración PAC simulada, descarga masiva
- Validación RFC, CSD

**/incidentes - Centro de Incidentes Pro:**
- Categorías: robo, descompostura, accidente, extorsión, estadía, retén
- Form con fotos, video, audio, ubicación, offline queue localStorage
- Timeline incidentes, estatus
- Botón SOS que comparte ubicación WhatsApp

**/configuracion - ERP Completo con Tabs:**
- Tabs: Empresa, Flotilla (CRUD vehículos), Choferes (CRUD + docs), Rutas Favoritas, Documentos (drag drop manager), Pagos y Facturación, Notificaciones, Integraciones API
- Todo con edición inline, guardar real en Supabase o localStorage demo

### FASE 4: AUTH Y POLISH FINAL

**/login /registro - Auth Premium:**
- UI tipo Linear, validación zod, mostrar password, recordar
- Supabase Auth real + demo
- Onboarding 3 pasos después de registro: empresa, unidad, docs
- Recuperar password

**/sushi -> /servicios - Marketplace Paradas:**
- Convertir broma en feature real: servicios en ruta - comida, talleres, vulcanizadoras, hoteles con descuento, mapa
- Pedido express con tracking

**General Polish:**
- Skeletons en todas las cargas
- Empty states ilustrados
- Toasts premium
- Animaciones framer-motion style con CSS
- Responsive 100% tablet/desktop (ahora solo max-w-md)
- PWA install prompt, offline cache
- Footer PRO con links, social, legal

---

## EJECUCIÓN

No hay pausa. Voy a empezar YA con FASE 1 y seguir hasta que todas las páginas estén premium. Cada archivo reescrito será producción lista.

Orden: CyberCard -> Navbar -> cargas -> publicar -> rastreo -> dashboard -> resto.

Tiempo estimado real: 45-60 min de trabajo continuo.
