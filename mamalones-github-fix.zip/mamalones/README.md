# MAMALONES - Kronos Fleet 🚛

> **Fletes que sí pagan. Unidades que sí llegan.**
> Plataforma logística de Jalisco sin coyotes.

🔗 **Demo:** https://mamalones.vercel.app  
📍 Hecho en Tlaquepaque, Jalisco

---

## ¿Qué es?

MAMALONES es un market place de fletes estilo **Vercel dark-minimalist**, optimizado para móvil (app-like) que conecta:

- **Dueños de carga** (comercializadoras de granos, productores) que publican origen/destino, toneladas y tarifa
- **Trailero / Mamalones verificadas** (Torton, Rabón, Thermo) que se postulan en privado

Valor agregado que nadie más tiene junto:
- 🔒 **Rastreo GPS privado** encriptado AES-256 - solo chofer y cliente ven el mapa
- 🛡️ **Pago en custodia Escrow** - 100% activo, sin estafas
- 📄 **Carta Porte SAT 3.1** timbrado automático con QR
- ⚖️ **Báscula + Diésel** calculadora merma 0.835kg/L
- 🎫 **Tag QR Casetas** pago exprés
- 🚛 **Verificación unidad** SCT/SAT, INE, antecedentes

## Stack

- Next.js 16.3 (App Router) + Turbopack
- Tailwind CSS 3.4 + lucide-react
- Supabase (Postgres + Auth + Realtime) - con fallback demo
- TypeScript

## 🚀 Deploy en 3 minutos

### 1. Clonar
```bash
git clone https://github.com/donovan-hue/mamalones.git
cd mamalones
npm install
```

### 2. Env (opcional - funciona sin esto en modo demo)
```bash
cp .env.example .env.local
# edita con tus keys de Supabase
```

### 3. Dev
```bash
npm run dev
# http://localhost:3000
```

### 4. Build
```bash
npm run build
```

### 5. Deploy Vercel
- Conecta repo en vercel.com/new
- Agrega ENV si quieres backend real, si no déjalo vacío (modo demo)
- Deploy -> listo

Ver `DEPLOYMENT.md` para guía completa y SQL schema.

## 📂 Estructura

```
src/app/
  page.tsx           # Landing nueva mamalona
  cargas/            # Tablero mercado + filtros
  publicar/          # Form publicar + supabase
  rastreo/           # Mapa GPS privado encriptado
  bascula/           # Calc peso + diésel
  caseta/            # QR Tag + saldo
  entrega/           # Verificación identidad unidad
  fiscal/            # Carta Porte SAT 3.1
  incidentes/        # Modo offline estadías
  login/ registro/ configuracion/ sushi/
```

## 🎨 Kit Propaganda

¿Listo para vender? Lee `KIT-PROPAGANDA.md` - tiene:
- Copy paste para grupos FB de traileros
- Guión TikTok 20s
- Mensaje WhatsApp difusión
- Calendario primera semana

## 🔧 Próximos pasos

- [ ] Auth real Supabase
- [ ] WhatsApp deep link por carga
- [ ] Notificaciones email postulación
- [ ] Panel admin

## Licencia

MIT - Hecho por Donovan para Jalisco.

---
**MAMALONES by Kronos Fleet - 2026**
